# MSc DFT Assistant — Agents #4–#7

四个可运行 agent,覆盖 MVP scope 第 4–7 项,属 NUS MSc DFT 助手项目的一部分。

| # | Agent | 功能 | 入口意图 |
|---|-------|------|---------|
| 4 | `agents/checklist` | 个性化申请材料清单 + 缺失项 | `generate_application_checklist` |
| 5 | `agents/tracker` | 申请状态翻译 + 截止提醒 | `get_application_status` |
| 6 | `agents/comparator` | 项目客观对比 + 目标匹配叙述 | `compare_programs` |
| 7 | `agents/navigator` | 岗位导向选课 + 技能差距 | `recommend_courses` |

## 设计要点
- **裁决归规则,叙述归 LLM**:资格/缺失/状态/推荐结论由纯 Python 规则引擎确定性产出;DeepSeek 只负责把结果写成人话,不做判断。
- **统一数据契约**:所有 agent 只吃 `UserProfile`([schema](docs/01-user-profile-schema.md)),输出统一信封([contracts](docs/02-interface-contracts.md))。
- **外部系统全 mock**:招生/CRM 接口用本地 mock,形状对齐真实 API,后期可替换。
- **离线可跑**:未配 DeepSeek key 时 LLM 层降级为确定性模板,agent 与测试均不依赖网络。

详见 [技术设计文档](docs/03-technical-design.md)。

## 一键启动(Windows)
双击 `start.bat`,菜单选择:装依赖 / agent 演示 / 学生端 Web / 管理员改数据(CLI 或 Web)/ 跑测试。需 key 的选项会提示输入。

## 学生端 Web(申请人输入页)
```bash
python -m student.webapp        # 浏览器打开 http://127.0.0.1:5001
```
申请人**用自然语言描述自己,或上传简历(Word/PDF)** → DeepSeek 提取信息回填到可编辑的确认表单 → 检查/修改后一次性获得 **申请清单(#4)+ 项目对比(#6)+ 选课/职业建议(#7)** 三块个性化结果。

- 入口(`/extract`,自然语言/上传)**需要 DeepSeek key**;提取后的 `/advise` 离线可跑。
- 文件解析:`.docx`(python-docx)/ `.pdf`(pdfplumber),上限 5MB。
- 提取值受约束在合法 enum 内,非法值丢弃;学生在确认表单可改正——LLM 抽取 + 人工确认。
- 与管理员端完全隔离,学生看不到任何录入工具。
- 注:开启 key 后,清单会为每项材料各调一次 LLM 生成解释,`/advise` 响应较慢(离线模板则瞬时)——见 future work。

## 安装
```bash
pip install -r requirements.txt
```

## 运行(虚拟数据演示)
```bash
python run.py --list-profiles          # 查看内置虚拟用户
python run.py checklist --profile 1    # #4
python run.py status    --profile 3    # #5
python run.py compare   --profile 1    # #6
python run.py courses   --profile 1    # #7
```

## 接入 DeepSeek(启用真实 LLM 叙述与提取)
两种方式,**任选其一**:

1. **网页设置页(推荐,无需碰命令行)**:打开任一 Web 应用的 `/settings`(管理员 http://127.0.0.1:5000/settings 或学生 http://127.0.0.1:5001/settings),填入 API key + 模型 `deepseek-v4-pro`,点「测试连接」验证后保存。key 存于本机 `data/.deepseek.json`(已 gitignore)。
2. **环境变量**(优先级更高):
   ```bash
   set DEEPSEEK_API_KEY=sk-...
   set DEEPSEEK_MODEL=deepseek-v4-pro
   ```
凭据统一由 `common/config.py` 读取(环境变量 > 本地文件 > 默认),网页保存后**即时生效无需重启**。无 key 时 agent 自动走降级模板。

## 管理员录入工具(自然语言改数据)

管理员可用自然语言维护数据文件,而非手写 JSON。**运行时引擎不变**:LLM 只在录入时把人话编译成 JSON,经校验 + 人工确认后才生效,旧版本归档、操作记入审计日志。详见 [设计文档](docs/04-admin-authoring-design.md)。

```bash
python -m admin.author --list                 # 列出可编辑数据
# 需要 DeepSeek key:
set DEEPSEEK_API_KEY=sk-...
set DEEPSEEK_MODEL=deepseek-v4-pro
python -m admin.author status_translations --admin alice ^
  --instruction "把 UNDER_REVIEW 的下一步改成'预计3周内出结果'"
```
流程:DeepSeek 生成草案 → pydantic 校验(不合法直接打回)→ 显示 diff → 确认 `y/n` → 写入 + 归档 `data/_versions/` + 记 `data/_audit_log.jsonl`。
已支持的数据:`status_translations`(低风险)、`admissions_rules`(**高风险**,界面标红;额外校验 `applies_when` 只能用引擎支持的条件)。扩展新数据类型:在 `admin/schemas.py` 加模型 + `admin/registry.py` 注册一项即可。

### Web 界面(供非技术管理员使用)
```bash
set DEEPSEEK_API_KEY=sk-...
set DEEPSEEK_MODEL=deepseek-v4-pro
python -m admin.webapp        # 浏览器打开 http://127.0.0.1:5000
```
表单选数据 → 输自然语言 → 看 diff 审核页 → 点「确认写入」。与 CLI 共用同一管线(校验/归档/审计),`/apply` 会重新校验、不盲信前端。仅绑本机;真实登录鉴权为 future work。

**历史 / 回滚页**(`/history`):查看审计日志,并从 `data/_versions/` 一键回滚到任意旧版本(单步、防路径穿越、还原前校验、记审计)。

## 分级数据刷新管线(`refresh/`)
让"对外展示的真实数据"(先做课程目录 `module_catalog`)可由抓取 + 模型整理自动更新,用**分级 + 例外审核**控制风险:大部分自动放行,人只看例外。详见 [设计文档](docs/05-refresh-pipeline-design.md)。

```bash
python -m refresh.run module_catalog     # 抓取(样例)→ 决策(自动发布 / 入待审)
python -m refresh.run --list-pending     # 查看需人工审核的项
python -m refresh.run --approve <file> --admin alice   # 批准一项
```
**放行策略**:可信源 + schema 通过 + 无异常 → 自动发布(仅记审计);首次接入 / 来源不可信 / 有异常(课程消失、改名、学分突变)→ 入人工队列。扩到新专业:首次审一次建基线,之后只在有变化/异常时报人——人工随风险与变化增长,不随专业数线性增长。

**两个已接入的源**:
- `module_catalog`(#7 课程,`trusted=true`):来自 NUSMods,可自动放行。
- `programs_dataset`(#6 竞品对比,`trusted=false`):**永不自动发布,每次强制人工审核**;数据经联网研究从各校官方页整理,每个项目**必须带 `source_url` + `fetched_at`**(schema 强制),对比表与学生页都显示来源链接与抓取日期。当前已是 NUS / SMU / NTU 的真实公开数据。

抓取是**可插拔接口**(`Fetcher`):`SampleFetcher` 读本地样例(离线可测);`NusmodsFetcher` 是**真实抓取器**,从公开 [NUSMods API](https://api.nusmods.com) 拉取真实 NUS 模块(标题/学分/描述)。每条数据带 `source_url` + `fetched_at`。运行时引擎仍只读确定 JSON。

```bash
python -m refresh.run module_catalog --live   # 从 NUSMods 抓真实课程数据
```
`data/module_catalog.json` 当前已是**真实 NUS 数据**(经 NUSMods 抓取 + 人工批准)。

**Navigator(#7)已接入目录**:选课推荐的课程名/学分/描述/课程链接均来自 `module_catalog`(真实 NUSMods 数据),每条标 `verified`;目录缺失的 code 回退到映射表名字。`data/role_module_map.json` 的模块代码已对齐到真实 NUS 模块(如 BMS5312 Fintech Management、DBA5109 Quantitative Risk Management)。

## 测试
```bash
python -m pytest tests/ -q
```
所有规则引擎测试均为确定性,不依赖 LLM。admin 管线(校验/diff/版本/审计)同样以临时文件测试,不触碰真实数据;仅 `extract` 这步需 DeepSeek key,需实测。

## 目录
```
common/      共享底座: profile / envelope / llm / mock_data
agents/      四个 agent (checklist / tracker / comparator / navigator)
data/        静态知识: 招生规则 / 状态翻译 / 竞品数据集 / 岗位-模块映射
supervisor.py  intent -> agent 路由 (模拟队友对话模块)
run.py       CLI 演示
tests/       确定性测试
docs/        schema / 接口契约 / 技术设计
```

## 给队友的对接点
- **上游**:对话/意图模块按 [contracts §1.2](docs/02-interface-contracts.md) 的 7 个 intent 调 `supervisor.route(intent, profile, slots)`。
- **下游**:escalation 模块消费 `AgentResponse.escalation`(见 contracts §2)。
- **RAG**:#4/#6 的知识检索点已预留,接入队友 retriever 即可替换降级模板。
