"""#7 Navigator Agent entry point.

Recommends modules for a target role and surfaces skill gaps. The rule engine
decides modules and gaps; the LLM only writes the `explanation` of why.
"""
from __future__ import annotations

from common import llm
from common.envelope import AgentResponse
from common.profile import UserProfile

from .engine import guide_for_role, pick_primary_role
from .planner import graduation_progress, prereq_warnings, what_if_pathways

_SYSTEM = (
    "You advise a Master's student on module choices for a target job role. "
    "Given their target role, the recommended modules, the skills they already "
    "have and the gaps, write 2-3 short sentences explaining why these modules "
    "fit and which gap to prioritise. Do not invent modules. Plain language."
)


def handle(profile: UserProfile, slots: dict | None = None) -> AgentResponse:
    slots = slots or {}
    role = pick_primary_role(profile, slots)
    if role is None:
        return AgentResponse.needs(
            ["target_roles"],
            "请告诉我你的目标岗位(例如金融科技产品经理、量化风险等),我才能推荐合适的模块。",
        )

    g = guide_for_role(profile, role)

    module_names = "、".join(m["name"] for m in g.recommended_modules)
    gap_text = "、".join(g.skill_gap_labels) if g.skill_gap_labels else "无明显技能缺口"
    fallback = (
        f"针对「{g.title}」,建议优先选修:{module_names}。"
        f"你当前需要补强的方向:{gap_text}。"
    )
    user_msg = (
        f"Target role: {g.title}\n"
        f"Recommended modules: {module_names}\n"
        f"Skills you have: {', '.join(g.matched_skills) or 'few'}\n"
        f"Skill gaps: {', '.join(g.skill_gap_labels) or 'none'}"
    )
    explanation = llm.explain(_SYSTEM, user_msg, fallback)
    speakable = explanation

    # v2: study-path planning (deterministic, from enriched catalog).
    codes = [m["code"] for m in g.recommended_modules]
    warnings = [
        {"code": w.code, "missing": w.missing}
        for w in prereq_warnings(codes, profile.completed_modules)
        if not w.satisfied
    ]
    progress = graduation_progress(profile.completed_modules, codes)
    plans = what_if_pathways(codes)

    if warnings:
        speakable += f" 注意:有 {len(warnings)} 门模块的先修课你尚未修读。"

    return AgentResponse(
        status="ok",
        answer_type="recommendation",  # personalised inference
        speakable=speakable,
        data={
            "target_role": g.role,
            "recommended_modules": g.recommended_modules,
            "skill_gaps": g.skill_gap_labels,
            "explanation": explanation,
            "prereq_warnings": warnings,
            "graduation_progress": progress,
            "study_plans": plans,  # full_time + part_time (what-if)
        },
        sources=["role_module_map", "module_catalog"],
    )
