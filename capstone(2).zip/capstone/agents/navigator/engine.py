"""#7 Navigator engine: role -> modules + deterministic skill-gap.

The user's current skills are derived deterministically from profile fields
(technical proficiency, finance knowledge, work domain). Skill gap = a role's
required skills minus what the user already has.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from common.profile import Proficiency, TargetRole, UserProfile, WorkDomain

_DATA_DIR = Path(__file__).resolve().parents[2] / "data"
_MAP_PATH = _DATA_DIR / "role_module_map.json"
_CATALOG_PATH = _DATA_DIR / "module_catalog.json"


def _load() -> dict:
    return json.loads(_MAP_PATH.read_text(encoding="utf-8"))


def _load_catalog() -> dict[str, dict]:
    """Return code -> authoritative module detail from the (refreshed) catalog.

    Empty if the catalog is missing, so recommendations still work (degraded to
    the role-map names).
    """
    if not _CATALOG_PATH.exists():
        return {}
    data = json.loads(_CATALOG_PATH.read_text(encoding="utf-8"))
    return {m["code"]: m for m in data.get("modules", [])}


def _enrich_modules(modules: list[dict]) -> list[dict]:
    """Overlay authoritative name/credits/description from the catalog.

    Falls back to the role-map name when a code isn't in the catalog, and marks
    each entry `verified` so the UI can distinguish sourced data.
    """
    catalog = _load_catalog()
    out = []
    for m in modules:
        cat = catalog.get(m["code"])
        if cat:
            out.append({
                "code": m["code"],
                "name": cat.get("name") or m.get("name"),
                "credits": cat.get("credits"),
                "description": cat.get("description"),
                "source_url": cat.get("source_url"),
                "verified": True,
            })
        else:
            out.append({
                "code": m["code"],
                "name": m.get("name"),
                "credits": None,
                "description": None,
                "source_url": None,
                "verified": False,
            })
    return out


def derive_user_skills(profile: UserProfile) -> set[str]:
    """Map profile fields to a set of skill tags (deterministic, explainable)."""
    skills: set[str] = set()
    tech = profile.technical_proficiency
    if tech in (Proficiency.intermediate, Proficiency.advanced):
        skills.add("programming")
        skills.add("data_analytics")
    if tech == Proficiency.advanced:
        skills.add("risk_modeling")
        skills.add("ai_ml")
        skills.add("security")
    fin = profile.finance_knowledge
    if fin in (Proficiency.intermediate, Proficiency.advanced):
        skills.add("finance")
    if fin == Proficiency.advanced:
        skills.add("regulation")
    if profile.work_domain in (WorkDomain.banking, WorkDomain.fintech):
        skills.add("finance")
    if profile.work_domain == WorkDomain.fintech:
        skills.add("payments_systems")
        skills.add("product")
    return skills


@dataclass
class RoleGuidance:
    role: str
    title: str
    recommended_modules: list[dict]
    skill_gaps: list[str]  # skill tags the user lacks
    skill_gap_labels: list[str]
    matched_skills: list[str] = field(default_factory=list)


def guide_for_role(profile: UserProfile, role: TargetRole) -> RoleGuidance:
    data = _load()
    labels = data["skill_labels"]
    role_def = data["roles"][role.value]
    required = role_def["required_skills"]
    have = derive_user_skills(profile)
    gaps = [s for s in required if s not in have]
    matched = [s for s in required if s in have]
    return RoleGuidance(
        role=role.value,
        title=role_def["title"],
        recommended_modules=_enrich_modules(role_def["recommended_modules"]),
        skill_gaps=gaps,
        skill_gap_labels=[labels.get(s, s) for s in gaps],
        matched_skills=matched,
    )


def pick_primary_role(profile: UserProfile, slots: dict) -> TargetRole | None:
    """Choose which role to advise on: slot override, else first target role."""
    if slots.get("target_role"):
        try:
            return TargetRole(slots["target_role"])
        except ValueError:
            return None
    return profile.target_roles[0] if profile.target_roles else None
