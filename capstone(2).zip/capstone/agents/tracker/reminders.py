"""#5 Reminder logic: milestone nudges with consent, prefs, and frequency control.

Deterministic. Reminders are milestone-driven: each deadline maps to a milestone
that only fires in the relevant application status (status gating), within a lead
window. Respects notification preferences (channels + off switch) and consent,
and de-duplicates already-sent reminders.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from common.profile import NotificationFrequency, StatusCode, UserProfile


@dataclass
class Reminder:
    key: str
    name: str
    date: str  # ISO
    message: str
    urgency: str  # "info" | "soon" | "urgent"
    channels: list[str] = field(default_factory=list)


# Per milestone: lead window (days), the status it applies to (None = any while
# the application is active), and a label.
_MILESTONES = {
    "application_deadline": {"lead": 21, "status": None, "label": "提交申请材料"},
    "document_deadline": {"lead": 21, "status": StatusCode.DOCS_REQUIRED, "label": "补交申请材料"},
    "offer_acceptance": {"lead": 14, "status": StatusCode.OFFER, "label": "确认接受录取"},
    "registration": {"lead": 14, "status": StatusCode.ACCEPTED, "label": "完成入学注册"},
}


def _urgency(days_left: int) -> str:
    if days_left <= 3:
        return "urgent"
    if days_left <= 7:
        return "soon"
    return "info"


def build_reminders(
    profile: UserProfile,
    today: date | None = None,
    already_sent: set[str] | None = None,
) -> list[Reminder]:
    """Return reminders to show now (milestone + status gated, prefs honoured)."""
    if not profile.consent_flags.reminders:
        return []
    if profile.notification_prefs.frequency == NotificationFrequency.off:
        return []  # user turned notifications off
    if profile.application is None:
        return []

    today = today or date.today()
    already_sent = already_sent or set()
    channels = [c.value for c in profile.notification_prefs.channels]
    status = profile.application.status_code
    reminders: list[Reminder] = []

    for name, iso in profile.application.deadlines.items():
        ms = _MILESTONES.get(name, {"lead": 14, "status": None, "label": name})
        if ms["status"] is not None and ms["status"] != status:
            continue  # milestone not active in the current status
        try:
            days_left = (date.fromisoformat(iso) - today).days
        except ValueError:
            continue
        if days_left < 0 or days_left > ms["lead"]:
            continue  # outside the nudging window
        key = f"{name}:{iso}"
        if key in already_sent:
            continue  # frequency control
        reminders.append(
            Reminder(
                key=key,
                name=name,
                date=iso,
                message=_message_for(name, ms["label"], days_left, status),
                urgency=_urgency(days_left),
                channels=channels,
            )
        )
    return reminders


def _message_for(name: str, label: str, days_left: int, status: StatusCode) -> str:
    if name in ("document_deadline", "application_deadline") and status == StatusCode.DOCS_REQUIRED:
        return f"你的申请因缺少材料被暂停,请在 {days_left} 天内{label}。"
    return f"距离「{label}」截止还有 {days_left} 天,请及时处理。"
