"""#6 Comparator engine v2.

- Derives each programme's role strengths from its curriculum_focus text via an
  explainable keyword rubric (no hand-assigned strengths).
- Scores programmes on deterministic criteria (role_fit / cost / duration) and
  combines them with user-supplied priority weights.

This is a personalised *fit* signal, NOT a quality ranking of programmes.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from common.profile import TargetRole

_DATA_PATH = Path(__file__).resolve().parents[2] / "data" / "programs_dataset.json"

# HKD -> SGD approximate rate (for rough cost comparability only).
_HKD_TO_SGD = 0.17

# Role -> curriculum keywords (zh/en). Matching is substring, case-insensitive.
_ROLE_KEYWORDS: dict[str, list[str]] = {
    "fintech_pm": ["金融科技", "fintech", "产品", "创业", "venture", "洞察"],
    "quant_risk": ["风险", "量化", "risk", "quantitative", "建模", "金融工程"],
    "digital_banking": ["银行", "banking", "数字金融"],
    "payments": ["支付", "payment", "区块链", "blockchain", "交易"],
    "compliance_regtech": ["合规", "监管", "compliance", "regulation", "反洗钱", "风险管理"],
    "data_analytics": ["数据", "分析", "analytics", "机器学习", "machine learning", "数据科学", "智能", "ai"],
}

_CRITERIA = ("role_fit", "cost", "duration")


def _load() -> dict:
    return json.loads(_DATA_PATH.read_text(encoding="utf-8"))


# ---------- role derivation (explainable) ----------
def derive_role_strengths(curriculum_focus: str) -> tuple[list[str], dict[str, list[str]]]:
    """Return (roles, reasons) where reasons[role] = matched keywords."""
    text = (curriculum_focus or "").lower()
    roles: list[str] = []
    reasons: dict[str, list[str]] = {}
    for role, kws in _ROLE_KEYWORDS.items():
        hits = [kw for kw in kws if kw.lower() in text]
        if hits:
            roles.append(role)
            reasons[role] = hits
    return roles, reasons


# ---------- deterministic scoring helpers ----------
def parse_fee_sgd(fees_text: str) -> float | None:
    """Extract an approximate SGD fee magnitude from a free-text fees field."""
    m = re.search(r"(HK\$|HKD|S\$|SGD)\s?([\d,]+)", fees_text or "", re.IGNORECASE)
    if not m:
        return None
    amount = float(m.group(2).replace(",", ""))
    cur = m.group(1).upper()
    if cur in ("HK$", "HKD"):
        amount *= _HKD_TO_SGD
    return amount


def parse_min_months(duration_text: str) -> int | None:
    """Smallest plausible duration in months from a free-text duration field.

    Supports Chinese and English phrases such as "18 个月", "1.5 years",
    "12 to 24 months", and "1 year full-time; 2 years part-time".
    """
    text = duration_text or ""
    months: list[int] = []
    # English ranges: 12 to 24 months / 1-2 years -> lower bound.
    for a, _b, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(?:-|to)\s*(\d+(?:\.\d+)?)\s*(months?|years?)", text, re.IGNORECASE):
        val = float(a)
        months.append(round(val * 12) if unit.lower().startswith("year") else round(val))
    # Chinese ranges: 1-2 年.
    for a, _b in re.findall(r"(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*年", text):
        months.append(round(float(a) * 12))
    # Standalone English years/months.
    for y in re.findall(r"(?<![-\d.])(\d+(?:\.\d+)?)\s*years?", text, re.IGNORECASE):
        months.append(round(float(y) * 12))
    for mth in re.findall(r"(?<![-\d.])(\d+(?:\.\d+)?)\s*months?", text, re.IGNORECASE):
        months.append(round(float(mth)))
    # Standalone Chinese years/months.
    for y in re.findall(r"(?<![-\d.])(\d+(?:\.\d+)?)\s*年", text):
        months.append(round(float(y) * 12))
    for mth in re.findall(r"(\d+(?:\.\d+)?)\s*个月", text):
        months.append(round(float(mth)))
    return min(months) if months else None


def _inverse_minmax(values: dict[str, float | None]) -> dict[str, float]:
    """Lower raw value -> higher score (0..1). Unknown (None) -> neutral 0.5."""
    known = [v for v in values.values() if v is not None]
    out = {k: 0.5 for k in values}
    if len(known) < 2:
        return out  # not enough spread to rank; all neutral
    lo, hi = min(known), max(known)
    if hi == lo:
        return out
    for k, v in values.items():
        if v is not None:
            out[k] = (hi - v) / (hi - lo)
    return out


def _normalise_weights(priorities: dict[str, float] | None) -> dict[str, float]:
    p = {k: float(v) for k, v in (priorities or {}).items()
         if k in _CRITERIA and float(v) > 0}
    if not p:
        p = {"role_fit": 1.0}
    total = sum(p.values())
    return {k: v / total for k, v in p.items()}


# ---------- comparison ----------
@dataclass
class ComparisonRow:
    program: str
    is_target: bool
    values: dict[str, str]
    fit_score: int
    matched_roles: list[str]
    role_reasons: dict[str, list[str]]
    weighted_score: float
    score_breakdown: dict[str, float]
    source_url: str | None = None
    fetched_at: str | None = None


@dataclass
class Comparison:
    dimensions: list[str]
    rows: list[ComparisonRow]
    disclaimer: str
    best_for_you: str | None
    weights: dict[str, float] = field(default_factory=dict)


def compare(target_roles: list[TargetRole],
            priorities: dict[str, float] | None = None) -> Comparison:
    data = _load()
    role_values = {r.value for r in target_roles}
    weights = _normalise_weights(priorities)
    progs = data["programs"]

    # Pre-parse per-criterion raw values for normalisation.
    fee_raw = {p["program"]: parse_fee_sgd(p["values"].get("fees", "")) for p in progs}
    dur_raw = {p["program"]: parse_min_months(p["values"].get("duration", "")) for p in progs}
    cost_score = _inverse_minmax(fee_raw)
    dur_score = _inverse_minmax(dur_raw)

    rows: list[ComparisonRow] = []
    for p in progs:
        roles, reasons = derive_role_strengths(p["values"].get("curriculum_focus", ""))
        matched = sorted(role_values & set(roles))
        role_fit = (len(matched) / len(role_values)) if role_values else 0.0
        breakdown = {
            "role_fit": role_fit,
            "cost": cost_score[p["program"]],
            "duration": dur_score[p["program"]],
        }
        weighted = sum(weights[k] * breakdown[k] for k in weights)
        rows.append(ComparisonRow(
            program=p["program"], is_target=p.get("is_target", False),
            values=p["values"], fit_score=len(matched), matched_roles=matched,
            role_reasons={r: reasons[r] for r in matched},
            weighted_score=round(weighted, 4), score_breakdown=breakdown,
            source_url=p.get("source_url"), fetched_at=p.get("fetched_at"),
        ))

    best = None
    if rows:
        best_row = max(rows, key=lambda r: (r.weighted_score, r.is_target))
        if best_row.weighted_score > 0:
            best = best_row.program

    return Comparison(
        dimensions=data["dimensions"], rows=rows, disclaimer=data["disclaimer"],
        best_for_you=best, weights=weights,
    )
