"""#6 Comparator Agent entry point.

Produces an objective comparison table plus a goal-tied narrative. Compliance
hard constraints (contract §4 #6):
  - rows come ONLY from the curated dataset
  - the LLM narrative must not produce rankings or "X is better than Y"
  - a disclaimer is always attached
"""
from __future__ import annotations

from common import llm
from common.envelope import AgentResponse
from common.profile import UserProfile

from .engine import compare

_SYSTEM = (
    "You write a brief, balanced 'fit' summary comparing graduate programmes "
    "for one applicant. STRICT RULES: only use the facts provided; never rank "
    "programmes or say one is better than another; frame everything as fit to "
    "the applicant's stated goals; 2-3 sentences; no new facts."
)


def _narrative(comp, target_roles) -> str:
    target_row = next((r for r in comp.rows if r.is_target), None)
    role_text = "、".join(r.value for r in target_roles) if target_roles else "你的目标"
    fallback = (
        f"结合你的目标({role_text}),"
        + (f"{comp.best_for_you} 在相关方向的契合度较高。" if comp.best_for_you else "各项目各有侧重,建议按你的具体目标权衡。")
        + " 以下对比仅供参考。"
    )
    if not llm.available():
        return fallback
    facts = "\n".join(
        f"- {r.program}: " + "; ".join(f"{k}={v}" for k, v in r.values.items())
        + f" (matches your goals on: {', '.join(r.matched_roles) or 'none'})"
        for r in comp.rows
    )
    user = (
        f"Applicant goals: {role_text}\n"
        f"Best fit by overlap: {comp.best_for_you or 'n/a'}\n"
        f"Programmes:\n{facts}"
    )
    return llm.explain(_SYSTEM, user, fallback)


def handle(profile: UserProfile, slots: dict | None = None) -> AgentResponse:
    slots = slots or {}
    # User priorities (weights over criteria) can be supplied by the dialogue/
    # student layer, e.g. {"cost": 0.6, "role_fit": 0.4}.
    priorities = slots.get("priorities")
    comp = compare(profile.target_roles, priorities)

    rows_data = [
        {
            "program": r.program,
            "is_target": r.is_target,
            "values": r.values,
            "fit_score": r.fit_score,
            "matched_roles": r.matched_roles,
            "role_reasons": r.role_reasons,
            "weighted_score": r.weighted_score,
            "score_breakdown": r.score_breakdown,
            "source_url": r.source_url,
            "fetched_at": r.fetched_at,
        }
        for r in comp.rows
    ]

    narrative = _narrative(comp, profile.target_roles)
    speakable = narrative
    if not profile.target_roles:
        speakable = "你还没有设定目标岗位,以下是各项目的客观对比,设定目标后我可以给出更贴合你的建议。"

    return AgentResponse(
        status="ok",
        answer_type="advisory",  # synthesis, not official policy
        speakable=speakable,
        data={
            "dimensions": comp.dimensions,
            "rows": rows_data,
            "narrative": narrative,
            "best_for_you": comp.best_for_you,
            "weights": comp.weights,
            "disclaimer": comp.disclaimer,  # always present (compliance)
        },
        sources=["programs_dataset"],
    )
