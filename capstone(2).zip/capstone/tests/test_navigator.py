"""Deterministic tests for #7 navigator (skill derivation + gaps + modules)."""
from agents.navigator.agent import handle
from agents.navigator.engine import derive_user_skills, guide_for_role, pick_primary_role
from common import mock_data
from common.profile import TargetRole


def test_skill_derivation_from_profile():
    p = mock_data.get_profile("1")  # tech=intermediate, fin=basic, banking
    skills = derive_user_skills(p)
    assert "programming" in skills and "data_analytics" in skills
    assert "finance" in skills  # from banking work domain
    assert "risk_modeling" not in skills  # tech not advanced


def test_gap_for_fintech_pm():
    p = mock_data.get_profile("1")
    g = guide_for_role(p, TargetRole.fintech_pm)  # needs product, programming, finance
    assert "product" in g.skill_gaps  # user lacks product
    assert "programming" not in g.skill_gaps  # user has it


def test_modules_come_from_map():
    p = mock_data.get_profile("1")
    g = guide_for_role(p, TargetRole.quant_risk)
    codes = {m["code"] for m in g.recommended_modules}
    assert "DBA5109" in codes  # real NUS module for quant risk


def test_recommended_modules_enriched_from_catalog():
    # Codes referenced by the map are present in the refreshed catalog, so each
    # recommended module should carry authoritative credits + a source link.
    p = mock_data.get_profile("1")
    g = guide_for_role(p, TargetRole.quant_risk)
    for m in g.recommended_modules:
        assert m["verified"] is True
        assert m["credits"] is not None
        assert m["source_url"] and "nusmods.com" in m["source_url"]


def test_pick_role_slot_override():
    p = mock_data.get_profile("1")
    role = pick_primary_role(p, {"target_role": "payments"})
    assert role == TargetRole.payments


def test_pick_role_defaults_to_first_target():
    p = mock_data.get_profile("1")
    assert pick_primary_role(p, {}) == TargetRole.fintech_pm


def test_handle_needs_role_when_none():
    p = mock_data.get_profile("1")
    p.target_roles = []
    resp = handle(p, {})
    assert resp.status == "need_clarification"
    assert "target_roles" in resp.missing_fields


def test_handle_envelope():
    p = mock_data.get_profile("1")
    resp = handle(p, {})
    assert resp.status == "ok"
    assert resp.answer_type == "recommendation"
    assert resp.data["recommended_modules"]
