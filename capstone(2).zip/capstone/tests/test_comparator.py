"""Deterministic tests for #6 comparator v2 (derivation + scoring + weighting)."""
from agents.comparator.agent import handle
from agents.comparator.engine import (
    compare,
    derive_role_strengths,
    parse_fee_sgd,
    parse_min_months,
)
from common import mock_data
from common.profile import TargetRole

PROGRAMS = {
    "NUS MSc in Digital Financial Technology",
    "SMU MSc in Applied Finance (FinTech track)",
    "NTU MSc in Financial Technology",
    "SMU MITB (Financial Technology & Analytics)",
    "HKUST MSc in Financial Technology",
}


# ---------- dataset shape ----------
def test_five_real_programs_seven_dimensions():
    comp = compare([TargetRole.fintech_pm])
    assert {r.program for r in comp.rows} == PROGRAMS
    assert len(comp.dimensions) == 7
    assert {"intake", "scholarship", "gmat_gre"} <= set(comp.dimensions)


def test_rows_carry_provenance():
    for r in compare([TargetRole.fintech_pm]).rows:
        assert r.source_url and r.fetched_at


# ---------- role derivation (explainable) ----------
def test_derivation_finds_roles_with_reasons():
    roles, reasons = derive_role_strengths("金融自动化、区块链、数据科学、机器学习、数字金融服务")
    assert "payments" in roles and "区块链" in reasons["payments"]
    assert "data_analytics" in roles  # 数据/机器学习


def test_derivation_empty_text():
    roles, reasons = derive_role_strengths("")
    assert roles == [] and reasons == {}


def test_matched_roles_intersect_target_with_reasons():
    comp = compare([TargetRole.quant_risk])
    nus = next(r for r in comp.rows if r.program.startswith("NUS"))
    assert "quant_risk" in nus.matched_roles
    assert nus.role_reasons["quant_risk"]  # keyword evidence present


# ---------- scoring helpers ----------
def test_parse_fee_sgd_currencies():
    assert parse_fee_sgd("S$63,220(含 GST)") == 63220
    assert parse_fee_sgd("HK$395,000") == 395000 * 0.17
    assert parse_fee_sgd("官方未公开") is None


def test_parse_min_months():
    assert parse_min_months("18 个月") == 18
    assert parse_min_months("1 年(全日制)/ 2 年(兼读)") == 12
    assert parse_min_months("1-2 年(全日制)") == 12
    assert parse_min_months("未明确公布") is None


# ---------- weighting ----------
def test_default_weight_is_role_fit():
    comp = compare([TargetRole.fintech_pm])
    assert comp.weights == {"role_fit": 1.0}


def test_weights_normalised():
    comp = compare([TargetRole.fintech_pm], {"cost": 3, "role_fit": 1})
    assert abs(sum(comp.weights.values()) - 1.0) < 1e-9
    assert abs(comp.weights["cost"] - 0.75) < 1e-9


def test_cost_priority_changes_best_fit():
    # Heavy cost weight should favour a cheaper programme over the pricier ones.
    comp = compare([TargetRole.fintech_pm], {"cost": 0.9, "role_fit": 0.1})
    best = max(comp.rows, key=lambda r: r.weighted_score)
    assert best.weighted_score == comp.rows[0].weighted_score or best.program == comp.best_for_you
    # cheapest known-fee programme scores highest on cost
    cheapest = min((r for r in comp.rows if r.score_breakdown["cost"] is not None),
                   key=lambda r: parse_fee_sgd(r.values["fees"]) or 1e9)
    assert cheapest.score_breakdown["cost"] == 1.0


def test_target_wins_ties():
    comp = compare([TargetRole.fintech_pm, TargetRole.quant_risk])
    assert "Digital Financial Technology" in comp.best_for_you  # NUS via target tiebreak


# ---------- compliance + envelope ----------
def test_disclaimer_and_provenance_in_handle():
    resp = handle(mock_data.get_profile("1"))
    assert "排名" in resp.data["disclaimer"]
    assert all(row["source_url"] for row in resp.data["rows"])
    assert "weights" in resp.data
    assert all({"weighted_score", "score_breakdown", "role_reasons"} <= set(row)
               for row in resp.data["rows"])


def test_priorities_via_slots():
    resp = handle(mock_data.get_profile("1"), {"priorities": {"cost": 1.0}})
    assert resp.data["weights"] == {"cost": 1.0}


def test_narrative_offline_deterministic():
    p = mock_data.get_profile("1")
    assert handle(p).data["narrative"] == handle(p).data["narrative"]
