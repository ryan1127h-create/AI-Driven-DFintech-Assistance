"""Deterministic tests for #5 tracker (status translation + reminders)."""
from datetime import date

from agents.tracker.agent import handle
from agents.tracker.reminders import build_reminders
from agents.tracker.statemachine import (
    build_timeline,
    estimated_next_date,
    latest_status_date,
    next_states,
    translate,
)
from common import mock_data
from common.profile import NotificationChannel, NotificationFrequency, StatusCode


def test_translate_known_status():
    t = translate(StatusCode.UNDER_REVIEW)
    assert t["human_status"] and t["next_step"]


def test_next_states_terminal():
    assert next_states(StatusCode.REJECTED) == []
    assert "ACCEPTED" in next_states(StatusCode.OFFER)


def test_reminder_within_window_for_docs_required():
    p = mock_data.get_profile("3")  # document_deadline 2026-06-10, DOCS_REQUIRED
    rs = build_reminders(p, today=date(2026, 5, 30))
    assert len(rs) == 1
    assert rs[0].name == "document_deadline"
    assert "材料" in rs[0].message


def test_reminder_outside_window_suppressed():
    p = mock_data.get_profile("1")  # offer_acceptance 2026-07-15, 46 days out
    rs = build_reminders(p, today=date(2026, 5, 30))
    assert rs == []


def test_reminder_requires_consent():
    p = mock_data.get_profile("3")
    p.consent_flags.reminders = False
    assert build_reminders(p, today=date(2026, 5, 30)) == []


def test_frequency_control_dedup():
    p = mock_data.get_profile("3")
    key = "document_deadline:2026-06-10"
    assert build_reminders(p, today=date(2026, 5, 30), already_sent={key}) == []


def test_urgency_escalates_near_deadline():
    p = mock_data.get_profile("3")
    rs = build_reminders(p, today=date(2026, 6, 8))  # 2 days left
    assert rs[0].urgency == "urgent"


def test_handle_envelope():
    p = mock_data.get_profile("3")
    resp = handle(p, {"today": "2026-05-30"})
    assert resp.status == "ok"
    assert resp.data["status_code"] == "DOCS_REQUIRED"
    assert resp.data["reminders"]


# ---------- v2: timeline + estimated date ----------
def test_timeline_is_translated_and_sorted():
    p = mock_data.get_profile("4")
    tl = build_timeline(p.application)
    assert [e["status_code"] for e in tl] == ["SUBMITTED", "UNDER_REVIEW", "DOCS_REQUIRED"]
    assert tl[-1]["human_status"] and tl[-1]["note"]  # translated + note carried


def test_estimated_next_date_uses_eta_days():
    # DOCS_REQUIRED reached 2026-05-25, eta_days=7 -> 2026-06-01.
    p = mock_data.get_profile("4")
    since = latest_status_date(p.application)
    assert estimated_next_date(StatusCode.DOCS_REQUIRED, since) == "2026-06-01"


def test_estimated_next_date_none_without_eta():
    assert estimated_next_date(StatusCode.WAITLIST, "2026-05-01") is None


# ---------- v2: #4 linkage ----------
def test_docs_required_lists_outstanding_documents():
    p = mock_data.get_profile("4")
    resp = handle(p, {"today": "2026-05-31"})
    keys = {d["key"] for d in resp.data["outstanding_documents"]}
    assert "transcript" in keys  # rejected -> outstanding
    # the rejected transcript is reported with its status
    transcript = next(d for d in resp.data["outstanding_documents"] if d["key"] == "transcript")
    assert transcript["status"] == "rejected"


# ---------- v2: notification preferences ----------
def test_frequency_off_suppresses_reminders():
    p = mock_data.get_profile("4")
    p.notification_prefs.frequency = NotificationFrequency.off
    assert build_reminders(p, today=date(2026, 5, 31)) == []


def test_reminders_carry_channels():
    p = mock_data.get_profile("4")
    rs = build_reminders(p, today=date(2026, 5, 31))
    assert rs and rs[0].channels == ["in_app", "email"]


# ---------- v2: milestone status gating ----------
def test_offer_acceptance_only_reminds_when_offer():
    p = mock_data.get_profile("1")  # UNDER_REVIEW, has offer_acceptance deadline
    # within window but wrong status -> no reminder
    assert build_reminders(p, today=date(2026, 7, 5)) == []
    # flip to OFFER -> reminder fires
    p.application.status_code = StatusCode.OFFER
    rs = build_reminders(p, today=date(2026, 7, 5))
    assert rs and rs[0].name == "offer_acceptance"
