"""CLI demo entry point.

Examples:
    python run.py checklist --profile 1
    python run.py status --profile 1
    python run.py compare --profile 2
    python run.py courses --profile 1
    python run.py --list-profiles
"""
from __future__ import annotations

import argparse
import json
import sys

from common import mock_data

# command -> intent (contract §1.2)
_COMMANDS = {
    "checklist": "generate_application_checklist",
    "status": "get_application_status",
    "reminders": "configure_reminders",
    "compare": "compare_programs",
    "courses": "recommend_courses",
    "career": "recommend_career_path",
}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="MSc DFT assistant — agent demo")
    parser.add_argument("command", nargs="?", choices=_COMMANDS, help="which agent to run")
    parser.add_argument("--profile", default="1", help="mock profile id (see --list-profiles)")
    parser.add_argument("--list-profiles", action="store_true")
    args = parser.parse_args(argv)

    if args.list_profiles or not args.command:
        print("Available mock profiles:")
        for pid in mock_data.all_profile_ids():
            p = mock_data.get_profile(pid)
            roles = ", ".join(r.value for r in p.target_roles)
            print(f"  {pid}: {p.lifecycle_stage.value:10s} roles=[{roles}]")
        if not args.command:
            print("\nUsage: python run.py <command> --profile <id>")
            print("commands:", ", ".join(_COMMANDS))
        return 0

    from supervisor import route

    profile = mock_data.get_profile(args.profile)
    resp = route(_COMMANDS[args.command], profile)

    print(f"\n=== {args.command} | profile {args.profile} ===")
    print("speakable:", resp.speakable)
    print("status:", resp.status, "| answer_type:", resp.answer_type)
    print("data:", json.dumps(resp.data, ensure_ascii=False, indent=2))
    if resp.escalation:
        print("escalation:", resp.escalation.model_dump_json(indent=2))
    if resp.missing_fields:
        print("missing_fields:", resp.missing_fields)
    return 0


if __name__ == "__main__":
    sys.exit(main())
