"""Single source of truth for DeepSeek credentials.

Lookup priority (highest first):
  1. environment variables (DEEPSEEK_API_KEY / DEEPSEEK_MODEL / DEEPSEEK_BASE_URL)
  2. local file data/.deepseek.json  (written by the /settings page)
  3. built-in defaults

All LLM-calling code reads through here dynamically, so saving a key in the
web UI takes effect immediately without a restart. The key is never logged and
never echoed back in full (see status()).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

_SECRET_FILE = Path(__file__).resolve().parents[1] / "data" / ".deepseek.json"
_DEFAULT_MODEL = "deepseek-v4-pro"
_DEFAULT_BASE_URL = "https://api.deepseek.com"


def _read_file() -> dict:
    if not _SECRET_FILE.exists():
        return {}
    try:
        return json.loads(_SECRET_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def get_api_key() -> str | None:
    return os.getenv("DEEPSEEK_API_KEY") or _read_file().get("api_key") or None


def get_model() -> str:
    return os.getenv("DEEPSEEK_MODEL") or _read_file().get("model") or _DEFAULT_MODEL


def get_base_url() -> str:
    return os.getenv("DEEPSEEK_BASE_URL") or _read_file().get("base_url") or _DEFAULT_BASE_URL


def is_configured() -> bool:
    return bool(get_api_key())


def set_credentials(api_key: str | None = None, model: str | None = None,
                    base_url: str | None = None) -> None:
    """Persist credentials to the local secret file (0600 where supported)."""
    data = _read_file()
    if api_key:
        data["api_key"] = api_key.strip()
    if model:
        data["model"] = model.strip()
    if base_url:
        data["base_url"] = base_url.strip()
    _SECRET_FILE.parent.mkdir(parents=True, exist_ok=True)
    _SECRET_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        os.chmod(_SECRET_FILE, 0o600)
    except OSError:
        pass  # best effort on Windows


def _mask(key: str) -> str:
    return f"…{key[-4:]}" if len(key) >= 4 else "…"


def status() -> dict:
    """Safe-to-display status. Never includes the full key."""
    key = get_api_key()
    source = "none"
    if os.getenv("DEEPSEEK_API_KEY"):
        source = "environment"
    elif _read_file().get("api_key"):
        source = "local file"
    return {
        "configured": bool(key),
        "key_hint": _mask(key) if key else None,
        "model": get_model(),
        "source": source,
    }


def test_connection() -> tuple[bool, str]:
    """Make a minimal API call to verify the key works. Returns (ok, message)."""
    key = get_api_key()
    if not key:
        return False, "未配置 API key"
    try:
        from openai import OpenAI

        client = OpenAI(api_key=key, base_url=get_base_url())
        client.models.list()  # cheap auth check
        return True, "连接成功,key 有效"
    except Exception as e:
        return False, f"连接失败: {e}"
