import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './hooks/useTheme.jsx';
import { ChatProvider } from './context/ChatContext.jsx';
import { ProgramsProvider } from "./context/ProgramsContext";
import { CoursesProvider } from "./context/CoursesContext";

import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import ChatBot from './components/ChatBot.jsx';
import Shell  from "./components/Shell.jsx";

import { RoleSwitcher, accessConfig } from './components/AccessGuard.jsx';

// Dashboard pages (overview only)
import ProspectiveStudentDashboard from './pages/ProspectiveStudentDashboard.jsx';
import ApplicantDashboard from './pages/ApplicantDashboard.jsx';
import AdmittedStudentDashboard from './pages/AdmittedStudentDashboard.jsx';
import EnrolledStudentDashboard from './pages/EnrolledStudentDashboard.jsx';
import GraduatingStudentDashboard from './pages/GraduatingStudentDashboard.jsx';
import AlumniDashboard from './pages/AlumniDashboard.jsx';
import StaffDashboard from './pages/StaffDashboard.jsx';

// Detail pages
import ProgramsPage from './pages/detail/ProgramsPage.jsx';
import DocumentsPage from './pages/detail/DocumentsPage.jsx';
import TasksPage from './pages/detail/TasksPage.jsx';
import EnrollmentPage from './pages/detail/EnrollmentPage.jsx';
import CoursesPage from './pages/detail/CoursesPage.jsx';
import ProgressPage from './pages/detail/ProgressPage.jsx';
import GraduationPage from './pages/detail/GraduationPage.jsx';
import CareerPage from './pages/detail/CareerPage.jsx';
import NetworkPage from './pages/detail/NetworkPage.jsx';
import InquiriesPage from './pages/detail/InquiriesPage.jsx';
import ApplicationsPage from './pages/detail/ApplicationsPage.jsx';
import StudentsPage from './pages/detail/StudentsPage.jsx';
import KnowledgePage from './pages/detail/KnowledgePage.jsx';
import InquiryPage from './pages/detail/InquiryPage.jsx';
import ApplicationTrackerPage from './pages/detail/ApplicationTrackerPage.jsx';
import HousingPage from './pages/detail/HousingPage.jsx';
import OrientationPage from './pages/detail/OrientationPage.jsx';
import FinancialAidPage from './pages/detail/FinancialAidPage.jsx';
import ResourcesPage from './pages/detail/ResourcesPage.jsx';
import TranscriptsPage from './pages/detail/TranscriptsPage.jsx';
import AlumniPreviewPage from './pages/detail/AlumniPreviewPage.jsx';
import MentoringPage from './pages/detail/MentoringPage.jsx';
import EventsPage from './pages/detail/EventsPage.jsx';
import AnalyticsPage from './pages/detail/AnalyticsPage.jsx';
import ActivityLogPage from './pages/detail/ActivityLogPage.jsx';
import SettingsPage from './pages/detail/SettingsPage.jsx';
import ProfilePage from './pages/detail/ProfilePage.jsx';

import  StudentLanding from "./pages/detail/StudentLanding.jsx";
import  StudentForm from "./pages/detail/StudentForm.jsx";
import  StudentResults from "./pages/detail/StudentResults.jsx";
import { AdminDashboard, AdminHistory } from "./pages/detail/AdminPages.jsx";
import Settings from "./pages/detail/Settings.jsx";
import { extractProfile, generateAdvice } from "./api.js";

import './index.css';

function emptyResult(profileType = "applicant") {
  return {
    profileType,
    materialSummary: { submittedRequired: 0, requiredTotal: 0, missingRequired: 0, rejectedRequired: 0, isComplete: false },
    materials: [],
    checklist: [],
    timeline: [],
    comparison: [],
    recommended: [],
    completedCodes: [],
    skillGaps: [],
    progress: { completed: 0, planned: 0, required: 52, remaining: 52 },
  };
}

function AppContent() {
  const { currentUser, isAuthenticated, loginAsRole } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [pageData, setPageData] = useState(null);
  const [profileType, setProfileType] = useState("applicant");
  const [prefill, setPrefill] = useState({});
  const [resultsData, setResultsData] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!isAuthenticated) {
      loginAsRole('prospective');
    }
  }, [isAuthenticated, loginAsRole]);

  useEffect(() => {
    setCurrentPage('dashboard');
  }, [currentUser?.role]);

  useEffect(() => {
    const handler = (e) => {
      const { page, data } = e.detail;

      setPageData(page);

      if (data?.prefill) setPrefill(data.prefill);
      if (data?.selected_stage) setProfileType(data.selected_stage);
      if (data) setResultsData(data);
    };

    window.addEventListener("navigate", handler);

    return () => window.removeEventListener("navigate", handler);
  }, []);


  useEffect(() => {
    const handleNavigate = (event) => {
      if (typeof event.detail === "string") {
        setCurrentPage(event.detail);
        setPageData(null);
      } else {
        setCurrentPage(event.detail.page);
        setPageData(event.detail.data);
      }
    };

    window.addEventListener("navigate", handleNavigate);
    return () => window.removeEventListener("navigate", handleNavigate);
  }, []);

  const handleNavigate = (page) => {
    setCurrentPage(page);
  };

  const handleMenuClick = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const renderPage = () => {
    if (!currentUser) return null;

    // Map pages to their components
    const pageComponents = {
      // Prospective
      programs: ProgramsPage,
      inquiry: InquiryPage,
      // Applicant
      documents: DocumentsPage,
      tasks: TasksPage,
      application: ApplicationTrackerPage,
      // Admitted
      enrollment: EnrollmentPage,
      housing: HousingPage,
      orientation: OrientationPage,
      // Enrolled
      courses: CoursesPage,
      progress: ProgressPage,
      financial: FinancialAidPage,
      resources: ResourcesPage,
      // Graduating
      graduation: GraduationPage,
      career: CareerPage,
      transcripts: TranscriptsPage,
      'alumni-preview': AlumniPreviewPage,
      // Alumni
      network: NetworkPage,
      mentoring: MentoringPage,
      events: EventsPage,
      // Staff
      inquiries: InquiriesPage,
      applications: ApplicationsPage,
      students: StudentsPage,
      knowledge: KnowledgePage,
      analytics: AnalyticsPage,
      'activity-log': ActivityLogPage,
      settings: SettingsPage,
      // Shared
      profile: ProfilePage,
      landing: () => (
        <StudentLanding
          onNext={async (formData) => {
            setBusy(true);
            setError("");

            try {
              // ✅ extract from FormData
              const nextType = formData.get("lifecycle_stage");
              const text = formData.get("text");

              // console.log("✅ FormData values:", {
              //   lifecycle_stage: nextType,
              //   text,
              //   file: formData.get("cv")
              // });

              // ✅ send FormData directly
              const payload = await extractProfile(formData);

              const newPrefill = payload.prefill || {
                lifecycle_stage: nextType,
              };

              setProfileType(nextType);
              setPrefill(newPrefill);

              window.dispatchEvent(
                new CustomEvent("navigate", {
                  detail: {
                    page: "form",
                    data: {
                      prefill: newPrefill,
                      selected_stage: nextType,
                    },
                  },
                })
              );

            } catch (err) {
              setError(err.message || "Profile extraction failed.");
            } finally {
              setBusy(false);
            }
          }}
          disabled={busy}
        />
      ),
      form: () => (
        <StudentForm
          profileType={profileType}
          prefill={prefill}
          onSubmit={async (formElement) => {
            setBusy(true);
            setError("");

            try {
              const formData = new FormData(formElement);

              // ✅ call backend
              const payload = await generateAdvice(formData);

              const data = payload.data || emptyResult(profileType);

              setResultsData(data);

              window.dispatchEvent(
                new CustomEvent("navigate", {
                  detail: {
                    page: "results",
                    data,
                  },
                })
              );
            } catch (err) {
              setError(err.message || "Analysis generation failed.");
            } finally {
              setBusy(false);
            }
          }} 
          disabled={busy}
        />
      ),

      results: () => (
        <StudentResults
          data={resultsData || emptyResult(profileType)}
          onEdit={() => {
            window.dispatchEvent(
              new CustomEvent("navigate", {
                detail: { page: "form" },
              })
            );
          }}
        />
      ),

    };

    // If it's a detail page, render it
    if (pageComponents[currentPage]) {
      const PageComponent = pageComponents[currentPage];
      return <PageComponent {...(pageData || {})}/>;
    }

    // Otherwise render the dashboard based on role
    switch (currentUser.role) {
      case 'prospective':
        return <ProspectiveStudentDashboard />;
      case 'applicant':
        return <ApplicantDashboard />;
      case 'admitted':
        return <AdmittedStudentDashboard />;
      case 'enrolled':
        return <EnrolledStudentDashboard />;
      case 'graduating':
        return <GraduatingStudentDashboard />;
      case 'alumni':
        return <AlumniDashboard />;
      case 'staff':
        return <StaffDashboard />;
      default:
        return <ProspectiveStudentDashboard />;
    }
  };

  const checkAccess = (page) => {
    const currentRole = isAuthenticated ? currentUser?.role : 'unauthenticated';
    const access = accessConfig[currentRole] || accessConfig.unauthenticated;
    return access.allowedPages.includes(page);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {isAuthenticated && (
        <>
          <Header onMenuClick={handleMenuClick} sidebarOpen={sidebarOpen} />
          <Sidebar
            isOpen={sidebarOpen}
            currentPage={currentPage}
            onNavigate={handleNavigate}
          />
          <main
            className={`pt-16 min-h-screen transition-all duration-300 ${
              sidebarOpen ? 'ml-64' : 'ml-0'
            }`}
          >
            <div className="p-6">
              {checkAccess(currentPage) ? (
                renderPage()
              ) : (
                <div className="flex items-center justify-center min-h-[60vh]">
                  <div className="text-center">
                    <p className="text-gray-600">Access Denied</p>
                    <button
                      onClick={() => setCurrentPage('dashboard')}
                      className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg"
                    >
                      Go to Dashboard
                    </button>
                  </div>
                </div>
              )}
            </div>
          </main>
          <ChatBot />
          <RoleSwitcher />
        </>
      )}
    </div>
  );
}


function App() {
  return (
    <AuthProvider>
      <ProgramsProvider>
        <CoursesProvider>
          <ChatProvider>
            <AppContent />
          </ChatProvider>
        </CoursesProvider>
      </ProgramsProvider>
    </AuthProvider>
  );
}

export default App;
