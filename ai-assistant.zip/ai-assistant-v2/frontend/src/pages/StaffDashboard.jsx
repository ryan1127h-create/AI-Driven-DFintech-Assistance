import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import KPICard from '../components/KPICard.jsx';
import { BarChartComponent, PieChartComponent, MultiLineChart } from '../components/Charts.jsx';
import { analyticsData } from '../data/mockData.js';
import { BarChart3, TrendingUp, AlertTriangle, BookOpen, Users, Clock, FileText, Shield, Activity, ArrowRight } from 'lucide-react';

export default function StaffDashboard() {
  const { currentUser } = useAuth();

  const stats = {
    inquiries: 156,
    escalated: 12,
    applications: 340,
    students: 2450,
    knowledgeArticles: 45,
    automationRate: 79.4,
  };

  const { inquiryAnalytics, automationRate } = analyticsData;

  const recentInquiries = [
    { id: 1, student: 'John Smith', category: 'admissions', status: 'open' },
    { id: 2, student: 'Sarah Johnson', category: 'application', status: 'escalated' },
    { id: 3, student: 'Emily Davis', category: 'registration', status: 'pending' },
  ];

  const recentApplications = [
    { id: 1, student: 'Michael Chen', program: 'Data Science', status: 'admitted' },
    { id: 2, student: 'Alex Turner', program: 'Computer Science', status: 'under_review' },
  ];

  const knowledgeGaps = [
    { topic: 'International visa processes', occurrences: 234 },
    { topic: 'Transfer credit evaluation', occurrences: 189 },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Analytics Dashboard</h1>
            <p className="text-slate-300 text-lg">Real-time insights into student lifecycle management</p>
          </div>
          <div className="flex items-center gap-2">
            <Shield size={16} />
            <span className="text-sm">Admin Access</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        <KPICard title="Total Inquiries" value={stats.inquiries} icon={FileText} color="blue" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'inquiries' }))} />
        <KPICard title="Automation Rate" value={`${stats.automationRate}%`} icon={TrendingUp} color="green" />
        <KPICard title="Escalations" value={stats.escalated} icon={AlertTriangle} color="red" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'inquiries' }))} />
        <KPICard title="Applications" value={stats.applications} icon={FileText} color="purple" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'applications' }))} />
        <KPICard title="Students" value={stats.students.toLocaleString()} icon={Users} color="yellow" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'students' }))} />
        <KPICard title="Knowledge Base" value={stats.knowledgeArticles} icon={BookOpen} color="indigo" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'knowledge' }))} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <MultiLineChart
            data={inquiryAnalytics.monthlyTrend}
            lines={[
              { dataKey: 'total', name: 'Total' },
              { dataKey: 'aiResolved', name: 'AI Resolved' },
              { dataKey: 'escalated', name: 'Escalated' },
            ]}
            xAxisKey="month"
            title="Inquiry Analytics Trend"
            height={250}
          />
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <PieChartComponent
            data={inquiryAnalytics.byCategory}
            dataKey="value"
            nameKey="name"
            title="Inquiries by Category"
            height={250}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Inquiries</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'inquiries' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {recentInquiries.map((inquiry) => (
              <div key={inquiry.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{inquiry.student}</p>
                  <p className="text-sm text-gray-500">{inquiry.category}</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs ${
                  inquiry.status === 'escalated' ? 'bg-red-100 text-red-700' :
                  inquiry.status === 'open' ? 'bg-blue-100 text-blue-700' :
                  'bg-yellow-100 text-yellow-700'
                }`}>
                  {inquiry.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Applications</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'applications' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {recentApplications.map((app) => (
              <div key={app.id} className="p-3 bg-gray-50 rounded-lg">
                <p className="font-medium text-gray-900">{app.student}</p>
                <p className="text-sm text-gray-500">{app.program}</p>
                <span className={`inline-block mt-1 px-2 py-1 rounded-full text-xs ${
                  app.status === 'admitted' ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700'
                }`}>
                  {app.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Knowledge Gaps</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'knowledge' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              Manage <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {knowledgeGaps.map((gap, idx) => (
              <div key={idx} className="p-3 bg-red-50 rounded-lg">
                <p className="font-medium text-gray-900">{gap.topic}</p>
                <p className="text-sm text-red-600">{gap.occurrences} occurrences</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'inquiries' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <FileText size={24} className="text-blue-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Manage Inquiries</h3>
          <p className="text-sm text-gray-500">Review and respond to student inquiries</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'applications' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <FileText size={24} className="text-purple-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Review Applications</h3>
          <p className="text-sm text-gray-500">Process and update application statuses</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'students' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <Users size={24} className="text-green-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Student Management</h3>
          <p className="text-sm text-gray-500">View and manage student records</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'knowledge' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <BookOpen size={24} className="text-orange-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Knowledge Base</h3>
          <p className="text-sm text-gray-500">Add and manage knowledge articles</p>
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'activity-log' }))}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
          >
            View full log <ArrowRight size={14} />
          </button>
        </div>
        <div className="space-y-2">
          {[
            { action: 'Application Updated', time: '2 min ago', user: 'Admin' },
            { action: 'Inquiry Resolved', time: '5 min ago', user: 'AI Agent' },
            { action: 'Student Added', time: '10 min ago', user: 'Admin' },
          ].map((log, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg text-sm">
              <span className="font-medium text-gray-900">{log.action}</span>
              <div className="text-gray-500">
                <span>{log.user}</span>
                <span className="mx-2">•</span>
                <span>{log.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
