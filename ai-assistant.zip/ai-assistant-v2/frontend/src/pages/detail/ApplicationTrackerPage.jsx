import { useState } from 'react';
import { FileText, CheckCircle, Clock, AlertCircle, Upload, Calendar, MapPin } from 'lucide-react';

export default function ApplicationTrackerPage() {
  const [application] = useState({
    id: 'APP-2024-1234',
    program: 'Data Science',
    degree: 'Bachelor of Science',
    status: 'under_review',
    submittedDate: 'February 20, 2024',
    expectedDecision: 'April 15, 2024',
    admissionCounselor: 'Dr. Rebecca Johnson',
    counselorEmail: 'r.johnson@university.edu',
  });

  const [timeline, setTimeline] = useState([
    { id: 1, step: 'Application Submitted', date: 'Feb 20, 2024', status: 'completed', description: 'Your application has been received' },
    { id: 2, step: 'Application Fee Paid', date: 'Feb 20, 2024', status: 'completed', description: '$65 application fee confirmed' },
    { id: 3, step: 'Documents Verification', date: 'In Progress', status: 'active', description: 'Admissions team is reviewing your documents' },
    { id: 4, step: 'Academic Review', date: 'Pending', status: 'pending', description: 'Faculty committee will review your application' },
    { id: 5, step: 'Interview', date: 'TBD', status: 'pending', description: 'Schedule your interview with admissions' },
    { id: 6, step: 'Decision', date: 'Apr 15, 2024', status: 'pending', description: 'Admission decision will be communicated' },
  ]);

  const [documents] = useState([
    { id: 1, name: 'Personal Statement', status: 'received', date: 'Feb 18, 2024', reviewer: 'Admissions Office' },
    { id: 2, name: 'Official Transcripts', status: 'received', date: 'Feb 20, 2024', reviewer: 'Records Office' },
    { id: 3, name: 'SAT/ACT Scores', status: 'received', date: 'Feb 15, 2024', reviewer: 'Testing Center' },
    { id: 4, name: 'Recommendation Letters', status: 'missing', date: '-', reviewer: '-' },
    { id: 5, name: 'Resume/CV', status: 'received', date: 'Feb 18, 2024', reviewer: 'Career Services' },
  ]);

  const getStatusColor = (status) => {
    const colors = {
      completed: 'bg-green-100 text-green-700',
      active: 'bg-blue-100 text-blue-700',
      pending: 'bg-gray-100 text-gray-600',
    };
    return colors[status] || colors.pending;
  };

  const getDocStatusIcon = (status) => {
    if (status === 'received') return <CheckCircle size={18} className="text-green-500" />;
    if (status === 'missing') return <AlertCircle size={18} className="text-red-500" />;
    return <Clock size={18} className="text-yellow-500" />;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-blue-200 text-sm mb-1">Application #{application.id}</p>
            <h1 className="text-3xl font-bold mb-2">{application.program}</h1>
            <p className="text-blue-100">{application.degree}</p>
          </div>
          <div className="text-right">
            <p className="text-blue-200 text-sm">Expected Decision</p>
            <p className="text-2xl font-bold">{application.expectedDecision}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <Clock size={20} className="text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Status</p>
              <p className="font-semibold text-gray-900 capitalize">{application.status.replace('_', ' ')}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
              <Calendar size={20} className="text-green-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Submitted</p>
              <p className="font-semibold text-gray-900">{application.submittedDate}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
              <MapPin size={20} className="text-purple-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Counselor</p>
              <p className="font-semibold text-gray-900">{application.admissionCounselor}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Application Timeline</h2>
          <div className="space-y-0">
            {timeline.map((item, index) => (
              <div key={item.id} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    item.status === 'completed' ? 'bg-green-500' :
                    item.status === 'active' ? 'bg-blue-500' : 'bg-gray-300'
                  }`}>
                    {item.status === 'completed' ? (
                      <CheckCircle size={18} className="text-white" />
                    ) : item.status === 'active' ? (
                      <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                    ) : (
                      <div className="w-2 h-2 bg-white rounded-full" />
                    )}
                  </div>
                  {index < timeline.length - 1 && (
                    <div className={`w-0.5 h-16 ${item.status === 'completed' ? 'bg-green-200' : 'bg-gray-200'}`} />
                  )}
                </div>
                <div className="pb-8">
                  <p className="font-medium text-gray-900">{item.step}</p>
                  <p className="text-sm text-gray-500">{item.description}</p>
                  <p className="text-xs text-gray-400 mt-1">{item.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Documents Status</h2>
          <div className="space-y-3">
            {documents.map((doc) => (
              <div
                key={doc.id}
                className={`flex items-center justify-between p-4 rounded-lg ${
                  doc.status === 'missing' ? 'bg-red-50 border border-red-200' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  {getDocStatusIcon(doc.status)}
                  <div>
                    <p className="font-medium text-gray-900">{doc.name}</p>
                    <p className="text-xs text-gray-500">
                      {doc.status === 'received' ? `Reviewed by ${doc.reviewer}` : 'Missing'}
                    </p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">{doc.date}</span>
              </div>
            ))}
          </div>
          {documents.some(d => d.status === 'missing') && (
            <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertCircle size={20} className="text-yellow-600" />
                <div>
                  <p className="font-medium text-yellow-800">Action Required</p>
                  <p className="text-sm text-yellow-700">Please upload the missing document to complete your application.</p>
                  <button className="mt-2 px-4 py-2 bg-yellow-600 text-white rounded-lg text-sm hover:bg-yellow-700 flex items-center gap-2">
                    <Upload size={16} />
                    Upload Document
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h3 className="font-semibold text-gray-900 mb-2">Need Help?</h3>
        <p className="text-sm text-gray-600 mb-3">
          Contact your admission counselor for questions about your application.
        </p>
        <div className="flex items-center gap-4">
          <div>
            <p className="text-sm font-medium text-gray-900">{application.admissionCounselor}</p>
            <p className="text-xs text-gray-500">{application.counselorEmail}</p>
          </div>
          <button className="ml-auto px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
            Send Message
          </button>
        </div>
      </div>
    </div>
  );
}
