import { useState } from 'react';
import { BookOpen, Plus, Trash2, Check, Users, Clock, Calendar } from 'lucide-react';
import Modal from '../../components/Modal';
import { useCourses } from "../../context/CoursesContext";

export default function CoursesPage() {

  const { courses, setCourses } = useCourses();
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCourse, setNewCourse] = useState({ code: '', name: '', credits: 3, instructor: '', schedule: '' });
  const [expandedCourses, setExpandedCourses] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  
  // CRUD: Add course
  const addCourse = () => {
    if (newCourse.code.trim() && newCourse.name.trim()) {
      setCourses([...courses, {
        id: `c${Date.now()}`,
        ...newCourse,
        enrolled: false,
        capacity: 50,
        seats: 50
      }]);
      setNewCourse({ code: '', name: '', credits: 3, instructor: '', schedule: '' });
      setShowAddModal(false);
    }
  };

  // CRUD: Delete course
  const deleteCourse = (courseId) => {
    setCourses(courses.filter(c => c.id !== courseId));
  };

  // Toggle enrollment
  const toggleEnrollment = (id) => {
    setCourses(prev =>
      prev.map(c =>
        c.id === id
          ? { ...c, enrolled: !c.enrolled }
          : c
      )
    );
  };

  const toggleDescription = (id) => {
    setExpandedCourses((prev) =>
      prev.includes(id)
        ? prev.filter((i) => i !== id)
        : [...prev, id]
    );
  };

  const enrolledCourses = courses.filter(c => c.enrolled);
  const totalCredits = enrolledCourses.reduce((sum, c) => sum + c.credits, 0);
  const maxCredits = 20;

  const filteredCourses = courses.filter((course) => {
    const term = searchTerm.toLowerCase();

    return (
      course.name.toLowerCase().includes(term) ||
      course.code.toLowerCase().includes(term) ||
      course.description?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Course Planning</h1>
            <p className="text-indigo-100">Plan and register for courses</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-indigo-200">Selected Credits</p>
            <p className="text-3xl font-bold">{totalCredits}/{maxCredits}</p>
          </div>
        </div>
      </div>

      <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-indigo-800">Credit Progress</span>
          <span className="text-sm text-indigo-600">{totalCredits}/{maxCredits}</span>
        </div>
        <div className="w-full h-3 bg-white rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${
              totalCredits > maxCredits ? 'bg-red-500' : totalCredits >= 12 ? 'bg-green-500' : 'bg-indigo-500'
            }`}
            style={{ width: `${Math.min((totalCredits / maxCredits) * 100, 100)}%` }}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Available Courses</h2>
        </div>

        <div className="mb-4">
          <input
            type="text"
            placeholder="Search courses (e.g. ACC3706, Risk Management)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          
          {filteredCourses.length === 0 && (
            <p className="text-sm text-gray-500">
              No courses found.
            </p>
          )}

          {filteredCourses.map((course) => (
            <div
              key={course.code}
              className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                course.enrolled
                  ? "border-indigo-500 bg-indigo-50"
                  : "border-gray-200 bg-white hover:shadow-md"
              }`}
            >

              {/* Header */}
              <div className="flex justify-between items-start mb-2">
                <div>
                  <span className="text-xs font-mono text-gray-500">{course.code}</span>
                  <h3 className="font-semibold text-gray-900 leading-snug">
                    {course.name}
                  </h3>
                </div>

                {course.enrolled && (
                  <div className="w-6 h-6 rounded-full bg-indigo-600 flex items-center justify-center">
                    <Check size={14} className="text-white" />
                  </div>
                )}
              </div>
               
              {/* Info */}
              <div className="text-sm text-gray-600 space-y-1">
                <div className="flex justify-between">
                  <span>Credits</span>
                  <span className="font-medium">{course.credits}</span>
                </div>

                <div className="flex justify-between">
                  <span>Semesters</span>
                  <span>
                    {course.semester?.length
                      ? `Sem ${course.semester.join(", ")}`
                      : "N/A"}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span>Workload</span>
                  <span>{course.workload} hrs</span>
                </div>
              </div>
              
              {/* Description (short) */}
              <div className="text-sm text-gray-600 mt-2">
                <p
                  className={
                    expandedCourses.includes(course.id)
                      ? ""
                      : "line-clamp-2"
                  }
                >
                  {course.description}
                </p>

                {course.description && course.description.length > 120 && (
                  <button
                    onClick={() => toggleDescription(course.id)}
                    className="text-blue-600 text-xs mt-1 hover:underline"
                  >
                    {expandedCourses.includes(course.id)
                      ? "Show less"
                      : "Show more"}
                  </button>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2 mt-3">

                {/* Enroll */}
                <button
                  onClick={() => toggleEnrollment(course.id)}
                  className={`flex-1 py-2 rounded text-sm font-medium ${
                    course.enrolled
                      ? "bg-red-100 text-red-700"
                      : "bg-indigo-100 text-indigo-700"
                  }`}
                >
                  {course.enrolled ? "Drop" : "Enroll"}
                </button>

                {/* View Details */}
                <a
                  href={course.source_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2 border border-gray-200 rounded text-sm font-medium text-center hover:bg-gray-50 transition"
                >
                  Details
                </a>
              </div>

            </div>
          ))}
        </div>
      </div>

      {enrolledCourses.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">My Schedule</h2>
          <div className="space-y-2">
            {enrolledCourses.map((course) => (
              <div key={course.id} className="flex items-center justify-between p-3 bg-indigo-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{course.code} - {course.name}</p>
                  <p className="text-sm text-gray-600">{course.schedule}</p>
                </div>
                <span className="text-sm font-medium text-indigo-600">{course.credits} credits</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Course Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add Course"
        size="md"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Course Code</label>
              <input
                type="text"
                value={newCourse.code}
                onChange={(e) => setNewCourse({ ...newCourse, code: e.target.value })}
                placeholder="e.g., CS501"
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Credits</label>
              <input
                type="number"
                value={newCourse.credits}
                onChange={(e) => setNewCourse({ ...newCourse, credits: parseInt(e.target.value) || 3 })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Course Name</label>
            <input
              type="text"
              value={newCourse.name}
              onChange={(e) => setNewCourse({ ...newCourse, name: e.target.value })}
              placeholder="e.g., Advanced Algorithms"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Instructor</label>
            <input
              type="text"
              value={newCourse.instructor}
              onChange={(e) => setNewCourse({ ...newCourse, instructor: e.target.value })}
              placeholder="e.g., Dr. Smith"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Schedule</label>
            <input
              type="text"
              value={newCourse.schedule}
              onChange={(e) => setNewCourse({ ...newCourse, schedule: e.target.value })}
              placeholder="e.g., Mon/Wed 10:00 AM"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div className="flex justify-end gap-3">
            <button
              onClick={() => setShowAddModal(false)}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={addCourse}
              disabled={!newCourse.code.trim() || !newCourse.name.trim()}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
            >
              Add Course
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}