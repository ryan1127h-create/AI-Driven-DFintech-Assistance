import { useState } from 'react';
import { Briefcase, Plus, Trash2, Building, MapPin, DollarSign, Send, Calendar, ExternalLink } from 'lucide-react';
import Modal from '../../components/Modal';

export default function CareerPage() {
  const [applications, setApplications] = useState([
    { id: 1, company: 'Tech Innovations Inc', role: 'Software Engineer', location: 'San Francisco, CA', salary: '$120K - $140K', status: 'applied', appliedDate: 'Mar 1, 2024', match: 92 },
    { id: 2, company: 'Data Driven Corp', role: 'Data Analyst', location: 'New York, NY', salary: '$90K - $110K', status: 'interview', appliedDate: 'Feb 20, 2024', match: 85 },
    { id: 3, company: 'Cloud Solutions LLC', role: 'Cloud Engineer', location: 'Seattle, WA', salary: '$115K - $135K', status: 'offer', appliedDate: 'Feb 10, 2024', match: 78 },
    { id: 4, company: 'StartupXYZ', role: 'Full Stack Developer', location: 'Austin, TX', salary: '$100K - $120K', status: 'rejected', appliedDate: 'Jan 15, 2024', match: 70 },
  ]);

  const [jobMatches, setJobMatches] = useState([
    { id: 1, company: 'AI Innovations', role: 'ML Engineer', location: 'San Francisco, CA', match: 95, salary: '$130K - $160K' },
    { id: 2, company: 'BigTech Corp', role: 'Senior Software Engineer', location: 'Seattle, WA', match: 89, salary: '$140K - $180K' },
    { id: 3, company: 'FinTech Solutions', role: 'Backend Developer', location: 'New York, NY', match: 82, salary: '$110K - $140K' },
  ]);

  const [showAddAppModal, setShowAddAppModal] = useState(false);
  const [newApp, setNewApp] = useState({ company: '', role: '', location: '', salary: '' });

  // CRUD: Add application
  const addApplication = () => {
    if (newApp.company.trim() && newApp.role.trim()) {
      setApplications([...applications, {
        id: Date.now(),
        ...newApp,
        status: 'applied',
        appliedDate: new Date().toLocaleDateString(),
        match: Math.floor(Math.random() * 30) + 70
      }]);
      setNewApp({ company: '', role: '', location: '', salary: '' });
      setShowAddAppModal(false);
    }
  };

  // CRUD: Update application status
  const updateStatus = (appId, status) => {
    setApplications(applications.map(app =>
      app.id === appId ? { ...app, status } : app
    ));
  };

  // CRUD: Delete application
  const deleteApplication = (appId) => {
    setApplications(applications.filter(app => app.id !== appId));
  };

  // CRUD: Apply to job match
  const applyToMatch = (matchId) => {
    const match = jobMatches.find(m => m.id === matchId);
    if (match) {
      setApplications([...applications, {
        id: Date.now(),
        company: match.company,
        role: match.role,
        location: match.location,
        salary: match.salary,
        status: 'applied',
        appliedDate: new Date().toLocaleDateString(),
        match: match.match
      }]);
      setJobMatches(jobMatches.filter(m => m.id !== matchId));
    }
  };

  // CRUD: Remove match
  const removeMatch = (matchId) => {
    setJobMatches(jobMatches.filter(m => m.id !== matchId));
  };

  const getStatusBadge = (status) => {
    const badges = {
      applied: { color: 'bg-blue-100 text-blue-700', text: 'Applied' },
      interview: { color: 'bg-yellow-100 text-yellow-700', text: 'Interview' },
      offer: { color: 'bg-green-100 text-green-700', text: 'Offer' },
      rejected: { color: 'bg-red-100 text-red-700', text: 'Rejected' },
    };
    return badges[status] || badges.applied;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Career Services</h1>
            <p className="text-emerald-100">Manage your job applications</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-emerald-200">Applications</p>
            <p className="text-3xl font-bold">{applications.length}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{applications.filter(a => a.status === 'applied').length}</p>
          <p className="text-sm text-blue-600">Applied</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-yellow-700">{applications.filter(a => a.status === 'interview').length}</p>
          <p className="text-sm text-yellow-600">Interviews</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{applications.filter(a => a.status === 'offer').length}</p>
          <p className="text-sm text-green-600">Offers</p>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-gray-700">{applications.find(a => a.status === 'offer')?.salary || 'No offers yet'}</p>
          <p className="text-sm text-gray-600">Highest Offer</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Job Matches</h2>
        </div>
        <div className="space-y-3">
          {jobMatches.map((match) => (
            <div key={match.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <Building size={18} className="text-emerald-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">{match.role}</p>
                  <p className="text-sm text-gray-500">{match.company} • {match.location}</p>
                  <p className="text-xs text-gray-400">{match.salary}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`px-3 py-1.5 rounded-full text-sm font-medium ${
                  match.match >= 90 ? 'bg-green-100 text-green-700' :
                  match.match >= 80 ? 'bg-blue-100 text-blue-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {match.match}% match
                </span>
                <button onClick={() => applyToMatch(match.id)} className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 text-sm">
                  Apply
                </button>
                <button onClick={() => removeMatch(match.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-lg">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">My Applications</h2>
          {/* <button onClick={() => setShowAddAppModal(true)} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 text-sm">
            <Plus size={16} />
            Add Application
          </button> */}
        </div>
        <div className="space-y-3">
          {applications.map((app) => {
            const badge = getStatusBadge(app.status);
            return (
              <div key={app.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                      <Building size={18} className="text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{app.role}</p>
                      <p className="text-sm text-gray-500">{app.company}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
                        <MapPin size={12} />
                        <span>{app.location}</span>
                        <span>•</span>
                        <span>{app.salary}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-3 py-1.5 rounded-lg text-sm font-medium border-0 cursor-pointer ${badge.color}`}> {app.status}</span>
                  </div>
                </div>
                <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                  <span className="flex items-center gap-1"><Calendar size={12} /> Applied {app.appliedDate}</span>
                  <span className={`px-2 py-0.5 rounded ${app.match >= 90 ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-600'}`}>
                    {app.match}% match
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Application Modal */}
      <Modal isOpen={showAddAppModal} onClose={() => setShowAddAppModal(false)} title="Add Job Application" size="md">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Company</label>
            <input type="text" value={newApp.company} onChange={(e) => setNewApp({ ...newApp, company: e.target.value })} placeholder="e.g., Google" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
            <input type="text" value={newApp.role} onChange={(e) => setNewApp({ ...newApp, role: e.target.value })} placeholder="e.g., Software Engineer" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
            <input type="text" value={newApp.location} onChange={(e) => setNewApp({ ...newApp, location: e.target.value })} placeholder="e.g., San Francisco, CA" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Salary Range</label>
            <input type="text" value={newApp.salary} onChange={(e) => setNewApp({ ...newApp, salary: e.target.value })} placeholder="e.g., $120K - $150K" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowAddAppModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={addApplication} disabled={!newApp.company.trim() || !newApp.role.trim()} className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50">Add</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
