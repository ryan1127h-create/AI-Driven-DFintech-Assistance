import { useState } from 'react';
import { BookOpen, Users, Heart, MapPin, Phone, Mail, ExternalLink, Search } from 'lucide-react';

export default function ResourcesPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  const [resources] = useState([
    { id: 1, name: 'Academic Advising', category: 'academic', description: 'Meet with advisors to plan your academic path', location: 'Academic Building, Room 105', contact: 'advising@university.edu', hours: 'Mon-Fri 9AM-5PM', phone: '(555) 123-4001' },
    { id: 2, name: 'Tutoring Center', category: 'academic', description: 'Free peer tutoring for all subjects', location: 'Library, 2nd Floor', contact: 'tutoring@university.edu', hours: 'Mon-Thu 10AM-8PM', phone: '(555) 123-4002' },
    { id: 3, name: 'Writing Center', category: 'academic', description: 'Help with essays, research papers, and dissertations', location: 'Liberal Arts Building, Room 210', contact: 'writing@university.edu', hours: 'Mon-Fri 10AM-6PM', phone: '(555) 123-4003' },
    { id: 4, name: 'Health Services', category: 'health', description: 'Medical care, vaccinations, and wellness programs', location: 'Health Center, Building C', contact: 'health@university.edu', hours: 'Mon-Fri 8AM-6PM, Sat 9AM-1PM', phone: '(555) 123-4004' },
    { id: 5, name: 'Counseling Services', category: 'health', description: 'Mental health support and counseling sessions', location: 'Student Wellness Center, Room 301A', contact: 'counseling@university.edu', hours: '24/7 Emergency Line', phone: '(555) 123-4005' },
    { id: 6, name: 'Career Services', category: 'career', description: 'Resume reviews, interviews, job placements', location: 'Student Center, 3rd Floor', contact: 'career@university.edu', hours: 'Mon-Fri 9AM-5PM', phone: '(555) 123-4006' },
    { id: 7, name: 'Disability Services', category: 'support', description: 'Accommodations and accessibility support', location: 'Student Affairs, Room 200', contact: 'disability@university.edu', hours: 'Mon-Fri 8AM-5PM', phone: '(555) 123-4007' },
    { id: 8, name: 'International Student Office', category: 'support', description: 'Visa support, cultural programs, ESL resources', location: 'Global Education Center, Room 101', contact: 'international@university.edu', hours: 'Mon-Fri 9AM-5PM', phone: '(555) 123-4008' },
    { id: 9, name: 'Library', category: 'academic', description: 'Books, databases, study rooms, and research help', location: 'Main Library', contact: 'library@university.edu', hours: '24/7 during finals', phone: '(555) 123-4009' },
    { id: 10, name: 'Gym & Recreation', category: 'health', description: 'Fitness center, sports facilities, and classes', location: 'Recreation Center', contact: 'recreation@university.edu', hours: 'Mon-Sun 6AM-11PM', phone: '(555) 123-4010' },
    { id: 11, name: 'Financial Aid Office', category: 'financial', description: 'Scholarships, grants, loans, and payment plans', location: 'Administration Building, Room 110', contact: 'finaid@university.edu', hours: 'Mon-Fri 9AM-5PM', phone: '(555) 123-4011' },
    { id: 12, name: 'Student Housing', category: 'housing', description: 'Dormitory assignments, maintenance, residence life', location: 'Housing Office, Maple Hall', contact: 'housing@university.edu', hours: '24/7 Emergency', phone: '(555) 123-4012' },
  ]);

  const categories = ['all', 'academic', 'health', 'career', 'support', 'financial', 'housing'];

  const filteredResources = resources.filter((r) => {
    const matchesSearch = r.name.toLowerCase().includes(searchTerm.toLowerCase()) || r.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'all' || r.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category) => {
    const icons = {
      academic: BookOpen,
      health: Heart,
      career: Users,
      support: Users,
      financial: BookOpen,
      housing: MapPin,
    };
    return icons[category] || BookOpen;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Student Resources</h1>
        <p className="text-indigo-100">Access all campus support services and facilities</p>
      </div>

            
      <div className="w-full flex flex-row items-center gap-4">

        <div className="relative flex-1 min-w-0">

          {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
          <input
            type="text"
            placeholder="Search resources..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"/>
        </div>
        <select
          value={activeCategory}
          onChange={(e) => setActiveCategory(e.target.value)}
          className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm"
        >
          {categories.map(cat => (
            <option key={cat} value={cat}>
              {cat === 'all' ? 'All Categories' : cat.charAt(0).toUpperCase() + cat.slice(1)}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map((resource) => {
          const Icon = getCategoryIcon(resource.category);
          return (
            <div
              key={resource.id}
              className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-lg bg-indigo-100 flex items-center justify-center shrink-0">
                  <Icon size={24} className="text-indigo-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{resource.name}</h3>
                  <span className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full capitalize">
                    {resource.category}
                  </span>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-4">{resource.description}</p>
              <div className="space-y-2 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <MapPin size={14} />
                  <span>{resource.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone size={14} />
                  <span>{resource.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail size={14} />
                  <span>{resource.contact}</span>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-3">{resource.hours}</p>
              <button className="w-full mt-4 py-2 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 text-sm font-medium flex items-center justify-center gap-2">
                <ExternalLink size={14} />
                Visit Page
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
