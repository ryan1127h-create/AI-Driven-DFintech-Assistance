import { useState } from 'react';
import { MessageCircle, Send, Bot, Clock, CheckCircle, AlertCircle, Plus, Trash2, Search } from 'lucide-react';
import Modal from '../../components/Modal';
import { faqData } from '../../data/faq';


export default function InquiryPage() {

  const [searchTerm, setSearchTerm] = useState('');
  const [openId, setOpenId] = useState(null);

  // ✅ Group by section
  const groupedFaq = faqData.reduce((acc, item) => {
    if (!acc[item.section]) {
      acc[item.section] = [];
    }
    acc[item.section].push(item);
    return acc;
  }, {});

  const toggleOpen = (id) => {
    setOpenId(prev => (prev === id ? null : id));
  };

  return (
    <div className="space-y-6 animate-fade-in">

      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-6 text-white">
        <h1 className="text-2xl font-bold">FAQ</h1>
        <p className="text-blue-100">Browse frequently asked questions by category</p>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="relative">
          {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
          <input
            type="text"
            placeholder="Search FAQ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Sections */}
      {Object.entries(groupedFaq).map(([section, faqs]) => {

        // ✅ filter per section
        const filteredFaqs = faqs.filter(item =>
          item.question.toLowerCase().includes(searchTerm.toLowerCase())
        );

        if (filteredFaqs.length === 0) return null;

        return (
          <div key={section} className="space-y-3">

            {/* Section Title */}
            <h2 className="text-lg font-semibold text-gray-800 border-l-4 border-blue-500 pl-3">
              {section}
            </h2>

            {/* FAQ Items */}
            {filteredFaqs.map((faq, index) => {
              const id = `${section}-${index}`;

              return (
                <div
                  key={id}
                  className="bg-white border border-gray-200 rounded-xl shadow-sm"
                >
                  {/* Question */}
                  <div
                    onClick={() => toggleOpen(id)}
                    className="cursor-pointer p-4 flex justify-between items-center"
                  >
                    <p className="font-medium text-gray-900">
                      Q: {faq.question}
                    </p>
                    <span className="text-blue-500">
                      {openId === id ? "-" : "+"}
                    </span>
                  </div>

                  {/* Answer */}
                  {openId === id && (
                    <div className="px-4 pb-4">
                      <div className="bg-green-50 border-l-4 border-green-400 p-3 rounded text-sm text-gray-700">
                        <span className="font-semibold text-green-700">A: </span>
                        {faq.answer}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        );
      })}

      {/* Empty state */}
      {faqData.length === 0 && (
        <div className="text-center text-gray-500 py-10">
          No FAQ available
        </div>
      )}

    </div>
  );
}