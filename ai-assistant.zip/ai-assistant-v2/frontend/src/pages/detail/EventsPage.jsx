import { useState } from 'react';
import { Calendar, MapPin, Plus, Trash2, Users, Clock, Check, Star, Search } from 'lucide-react';
import Modal from '../../components/Modal';

export default function EventsPage() {
  const [events, setEvents] = useState([
    { id: 1, title: 'Annual Alumni Gala', date: 'April 15, 2024', time: '6:00 PM - 10:00 PM', location: 'Grand Ballroom', type: 'networking', joined: false, attendees: 145, capacity: 200 },
    { id: 2, title: 'Tech Industry Panel', date: 'April 22, 2024', time: '2:00 PM - 5:00 PM', location: 'Virtual', type: 'career', joined: true, attendees: 89, capacity: 100 },
    { id: 3, title: 'Homecoming Weekend', date: 'May 10, 2024', time: 'All Day', location: 'Campus Wide', type: 'social', joined: false, attendees: 312, capacity: 500 },
    { id: 4, title: 'Alumni Golf Tournament', date: 'June 5, 2024', time: '8:00 AM - 4:00 PM', location: 'University Golf Course', type: 'sports', joined: false, attendees: 64, capacity: 80 },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newEvent, setNewEvent] = useState({ title: '', date: '', time: '', location: '', type: 'networking' });
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  const types = ['all', 'networking', 'career', 'social', 'sports', 'academic'];

  const filteredEvents = events.filter(e => {
    const matchesSearch = e.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || e.type === filterType;
    return matchesSearch && matchesType;
  });

  // CRUD: Toggle join
  const toggleJoin = (id) => {
    setEvents(events.map(e => e.id === id ? { ...e, joined: !e.joined, attendees: e.joined ? e.attendees - 1 : e.attendees + 1 } : e));
  };

  // CRUD: Add event
  const addEvent = () => {
    if (newEvent.title.trim() && newEvent.date.trim()) {
      setEvents([...events, { id: Date.now(), ...newEvent, joined: false, attendees: 0, capacity: 50 }]);
      setNewEvent({ title: '', date: '', time: '', location: '', type: 'networking' });
      setShowAddModal(false);
    }
  };

  // CRUD: Delete event
  const deleteEvent = (id) => {
    setEvents(events.filter(e => e.id !== id));
  };

  const getTypeColor = (type) => {
    const colors = { networking: 'bg-blue-100 text-blue-700', career: 'bg-purple-100 text-purple-700', social: 'bg-green-100 text-green-700', sports: 'bg-orange-100 text-orange-700', academic: 'bg-indigo-100 text-indigo-700' };
    return colors[type] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Alumni Events</h1>
            <p className="text-orange-100">Discover and join alumni gatherings</p>
          </div>
          <button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 px-4 py-2 bg-white text-orange-700 rounded-lg hover:bg-orange-50">
            <Plus size={18} />
            Add Event
          </button>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
          <input type="text" placeholder="Search events..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-orange-500" />
        </div>
        <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
          {types.map(t => <option key={t} value={t}>{t === 'all' ? 'All Types' : t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEvents.map((event) => (
          <div key={event.id} className={`bg-white rounded-xl border ${event.joined ? 'border-green-200' : 'border-gray-200'} p-6 hover:shadow-lg transition-shadow`}>
            <div className="flex items-center justify-between mb-3">
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${getTypeColor(event.type)}`}>{event.type}</span>
              <button onClick={() => deleteEvent(event.id)} className="p-1 text-red-500 hover:bg-red-50 rounded"><Trash2 size={14} /></button>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">{event.title}</h3>
            <div className="space-y-2 text-sm text-gray-500 mb-4">
              <div className="flex items-center gap-2"><Calendar size={14} /><span>{event.date}</span></div>
              <div className="flex items-center gap-2"><Clock size={14} /><span>{event.time}</span></div>
              <div className="flex items-center gap-2"><MapPin size={14} /><span>{event.location}</span></div>
              <div className="flex items-center gap-2"><Users size={14} /><span>{event.attendees}/{event.capacity} attending</span></div>
            </div>
            <button onClick={() => toggleJoin(event.id)} className={`w-full py-2 rounded-lg text-sm font-medium ${event.joined ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
              {event.joined ? 'Joined' : 'Join Event'}
            </button>
          </div>
        ))}
      </div>

      <Modal isOpen={showAddModal} onClose={() => setShowAddModal(false)} title="Add Event" size="sm">
        <div className="space-y-4">
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Title</label><input type="text" value={newEvent.title} onChange={(e) => setNewEvent({...newEvent, title: e.target.value})} className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Date</label><input type="text" value={newEvent.date} onChange={(e) => setNewEvent({...newEvent, date: e.target.value})} className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Time</label><input type="text" value={newEvent.time} onChange={(e) => setNewEvent({...newEvent, time: e.target.value})} className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Location</label><input type="text" value={newEvent.location} onChange={(e) => setNewEvent({...newEvent, location: e.target.value})} className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Type</label><select value={newEvent.type} onChange={(e) => setNewEvent({...newEvent, type: e.target.value})} className="w-full px-4 py-2 border rounded-lg"><option value="networking">Networking</option><option value="career">Career</option><option value="social">Social</option><option value="sports">Sports</option></select></div>
          <div className="flex justify-end gap-3"><button onClick={() => setShowAddModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button><button onClick={addEvent} className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700">Add</button></div>
        </div>
      </Modal>
    </div>
  );
}
