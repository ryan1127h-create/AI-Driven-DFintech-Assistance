import { useState } from 'react';
import { GraduationCap, CheckCircle, Plus, Trash2, Calendar, AlertTriangle, Clock } from 'lucide-react';
import Modal from '../../components/Modal';

export default function GraduationPage() {
  const [requirements, setRequirements] = useState([
    { id: 1, title: 'Complete 120 credit hours', status: 'completed', progress: 100, notes: '84/120 credits completed' },
    { id: 2, title: 'Maintain minimum 2.0 GPA', status: 'completed', progress: 100, notes: 'Current GPA: 3.72' },
    { id: 3, title: 'Complete major requirements', status: 'completed', progress: 100, notes: 'All major courses passed' },
    { id: 4, title: 'Clear all financial holds', status: 'pending', progress: 0, notes: 'Outstanding balance: $500' },
    { id: 5, title: 'Submit graduation application', status: 'completed', progress: 100, notes: 'Submitted Feb 15, 2024' },
    { id: 6, title: 'Complete exit survey', status: 'pending', progress: 0, notes: 'Due May 1, 2024' },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newReq, setNewReq] = useState({ title: '', notes: '' });

  // CRUD: Toggle status
  const toggleStatus = (reqId) => {
    setRequirements(requirements.map(r =>
      r.id === reqId
        ? { ...r, status: r.status === 'completed' ? 'pending' : 'completed', progress: r.status === 'completed' ? 0 : 100 }
        : r
    ));
  };

  // CRUD: Add requirement
  const addRequirement = () => {
    if (newReq.title.trim()) {
      setRequirements([...requirements, {
        id: Date.now(),
        title: newReq.title.trim(),
        status: 'pending',
        progress: 0,
        notes: newReq.notes.trim()
      }]);
      setNewReq({ title: '', notes: '' });
      setShowAddModal(false);
    }
  };

  // CRUD: Delete requirement
  const deleteRequirement = (reqId) => {
    setRequirements(requirements.filter(r => r.id !== reqId));
  };

  const completedCount = requirements.filter(r => r.status === 'completed').length;
  const totalCount = requirements.length;
  const progressPercentage = (completedCount / totalCount) * 100;

  const getStatusColor = (status) => {
    const colors = {
      completed: 'bg-green-50 border-green-200',
      pending: 'bg-yellow-50 border-yellow-200',
      in_progress: 'bg-blue-50 border-blue-200',
    };
    return colors[status] || colors.pending;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Graduation Requirements</h1>
            <p className="text-emerald-100">Track your path to graduation</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-emerald-200">Expected</p>
            <p className="text-3xl font-bold">May 2025</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{completedCount}</p>
          <p className="text-sm text-green-600">Completed</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-yellow-700">{totalCount - completedCount}</p>
          <p className="text-sm text-yellow-600">Pending</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{Math.round(progressPercentage)}%</p>
          <p className="text-sm text-blue-600">Progress</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Requirements Checklist</h2>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 text-sm"
          >
            <Plus size={16} />
            Add Requirement
          </button>
        </div>

        <div className="space-y-3">
          {requirements.map((req) => (
            <div
              key={req.id}
              className={`p-4 rounded-lg border ${getStatusColor(req.status)}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => toggleStatus(req.id)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      req.status === 'completed' ? 'bg-green-500' : 'bg-gray-300'
                    }`}
                  >
                    {req.status === 'completed' && <CheckCircle size={18} className="text-white" />}
                    {req.status === 'pending' && <Clock size={18} className="text-white" />}
                  </button>
                  <div>
                    <p className={`font-medium ${req.status === 'completed' ? 'text-green-900' : 'text-gray-900'}`}>
                      {req.title}
                    </p>
                    <p className="text-sm text-gray-500">{req.notes}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    req.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {req.status}
                  </span>
                  <button
                    onClick={() => deleteRequirement(req.id)}
                    className="p-2 text-red-500 hover:bg-red-100 rounded-lg"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Requirement Modal */}
      <Modal isOpen={showAddModal} onClose={() => { setShowAddModal(false); setNewReq({ title: '', notes: '' }); }} title="Add Requirement" size="sm">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Requirement Title</label>
            <input type="text" value={newReq.title} onChange={(e) => setNewReq({ ...newReq, title: e.target.value })} placeholder="e.g., Complete capstone project" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
            <input type="text" value={newReq.notes} onChange={(e) => setNewReq({ ...newReq, notes: e.target.value })} placeholder="Additional details" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => { setShowAddModal(false); setNewReq({ title: '', notes: '' }); }} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={addRequirement} disabled={!newReq.title.trim()} className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50">Add</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
