import { useState } from 'react';
import { BarChart3, TrendingUp, Users, FileText, AlertTriangle, Clock, CheckCircle, Activity } from 'lucide-react';
import { PieChartComponent, BarChartComponent, MultiLineChart, AreaChartComponent } from '../../components/Charts';

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState('month');

  const analyticsData = {
    inquiryStats: { total: 2456, aiResolved: 1946, human: 310, escalated: 200 },
    automationRate: 79.4,
    responseTime: { avg: 1.2, target: 1.5 },
    satisfaction: 4.6,
    activeUsers: { students: 4500, alumni: 890, staff: 145 },
  };

  const monthlyTrend = [
    { month: 'Sep', inquiries: 200, aiResolved: 150, escalated: 20 },
    { month: 'Oct', inquiries: 280, aiResolved: 220, escalated: 25 },
    { month: 'Nov', inquiries: 240, aiResolved: 195, escalated: 22 },
    { month: 'Dec', inquiries: 180, aiResolved: 145, escalated: 18 },
    { month: 'Jan', inquiries: 320, aiResolved: 260, escalated: 30 },
    { month: 'Feb', inquiries: 280, aiResolved: 225, escalated: 28 },
  ];

  const categoryData = [
    { name: 'Admissions', value: 456 },
    { name: 'Financial', value: 312 },
    { name: 'Registration', value: 278 },
    { name: 'Career', value: 198 },
    { name: 'Housing', value: 145 },
  ];

  const performanceMetrics = [
    { name: 'AI Accuracy', value: 94 },
    { name: 'Resolution Rate', value: 79 },
    { name: 'Satisfaction', value: 92 },
    { name: 'Speed', value: 88 },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">System Analytics</h1>
            <p className="text-slate-300">Comprehensive performance metrics and insights</p>
          </div>
          <select value={timeRange} onChange={(e) => setTimeRange(e.target.value)} className="w-48 px-4 py-2 bg-white/10 rounded-lg text-white">
            <option value="week" className="text-black">Last Week</option>
            <option value="month" className="text-black">Last Month</option>
            <option value="quarter" className="text-black">Last Quarter</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center"><FileText size={24} className="text-blue-600" /></div>
          <div><p className="text-2xl font-bold text-blue-700">{analyticsData.inquiryStats.total.toLocaleString()}</p><p className="text-sm text-blue-600">Total Inquiries</p></div>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center"><CheckCircle size={24} className="text-green-600" /></div>
          <div><p className="text-2xl font-bold text-green-700">{analyticsData.automationRate}%</p><p className="text-sm text-green-600">Automation Rate</p></div>
        </div>
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center"><Clock size={24} className="text-purple-600" /></div>
          <div><p className="text-2xl font-bold text-purple-700">{analyticsData.responseTime.avg}s</p><p className="text-sm text-purple-600">Avg Response</p></div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-yellow-100 flex items-center justify-center"><TrendingUp size={24} className="text-yellow-600" /></div>
          <div><p className="text-2xl font-bold text-yellow-700">{analyticsData.satisfaction}/5</p><p className="text-sm text-yellow-600">Satisfaction</p></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Inquiry Trend</h2>
          <MultiLineChart data={monthlyTrend} lines={[{ dataKey: 'inquiries', name: 'Total Inquiries' }, { dataKey: 'aiResolved', name: 'AI Resolved' }, { dataKey: 'escalated', name: 'Escalated' }]} xAxisKey="month" height={250} />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Categories Distribution</h2>
          <PieChartComponent data={categoryData} dataKey="value" nameKey="name" height={250} />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Performance Metrics</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {performanceMetrics.map((metric) => (
            <div key={metric.name} className="text-center">
              <p className="text-3xl font-bold text-gray-900">{metric.value}%</p>
              <p className="text-sm text-gray-500">{metric.name}</p>
              <div className="w-full h-2 bg-gray-200 rounded-full mt-2"><div className="h-full bg-blue-600 rounded-full" style={{ width: `${metric.value}%` }} /></div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Active Users</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(analyticsData.activeUsers).map(([role, count]) => (
            <div key={role} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <span className="font-medium text-gray-700 capitalize">{role}</span>
              <span className="text-2xl font-bold text-gray-900">{count.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
