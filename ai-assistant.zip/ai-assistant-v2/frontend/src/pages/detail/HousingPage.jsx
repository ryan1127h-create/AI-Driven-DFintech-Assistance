import { useState } from 'react';
import { Home, MapPin, DollarSign, Users, Calendar, Check, Star, Plus, Trash2 } from 'lucide-react';
import Modal from '../../components/Modal';

export default function HousingPage() {
  const [applications, setApplications] = useState([]);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [selectedHousing, setSelectedHousing] = useState(null);
  const [preferences, setPreferences] = useState({
    roomType: 'double',
    floor: 'no_preference',
    bathroom: 'shared',
    quiet: false,
    smoke: false,
  });

  const [housingOptions] = useState([
    {
      id: 1,
      name: 'Maple Hall',
      type: 'Traditional Residence',
      image: 'https://images.unsplash.com/photo-1555854877-abc12fde052b?w=400&h=300&fit=crop',
      amenities: ['Laundry', 'Study Rooms', 'Common Kitchen', 'Gym'],
      roomTypes: [
        { type: 'Double Room', price: '$8,500/year', available: 12 },
        { type: 'Single Room', price: '$12,000/year', available: 5 },
      ],
      rating: 4.5,
      distance: '5 min walk',
      description: 'Traditional residence hall with a vibrant community atmosphere.',
    },
    {
      id: 2,
      name: 'Oak Apartments',
      type: 'Apartment Style',
      image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14ca?w=400&h=300&fit=crop',
      amenities: ['Private Kitchen', 'Full Bath', 'Laundry', 'AC', 'Parking'],
      roomTypes: [
        { type: 'Single Bedroom', price: '$14,000/year', available: 8 },
        { type: 'Double Bedroom', price: '$10,500/year', available: 15 },
      ],
      rating: 4.8,
      distance: '8 min walk',
      description: 'Apartment-style living with kitchen and private facilities.',
    },
    {
      id: 3,
      name: 'Pine Suites',
      type: 'Suite Style',
      image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d12e?w=400&h=300&fit=crop',
      amenities: ['Shared Living Room', 'Semi-Private Bath', 'AC', 'Study Lounge'],
      roomTypes: [
        { type: 'Single in Suite', price: '$13,000/year', available: 3 },
        { type: 'Double in Suite', price: '$9,500/year', available: 10 },
      ],
      rating: 4.6,
      distance: '6 min walk',
      description: 'Suite-style living with shared common areas and bathrooms.',
    },
  ]);

  // CRUD: Apply for housing
  const applyForHousing = (housingId, roomType) => {
    setApplications([...applications, {
      id: Date.now(),
      housingId,
      roomType,
      status: 'pending',
      appliedDate: new Date().toLocaleDateString(),
    }]);
    setShowApplyModal(false);
    setSelectedHousing(null);
  };

  // CRUD: Cancel application
  const cancelApplication = (appId) => {
    setApplications(applications.filter(a => a.id !== appId));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Housing Application</h1>
            <p className="text-green-100">Apply for on-campus housing for the upcoming academic year</p>
          </div>
          <div className="text-right">
            <p className="text-green-200 text-sm">Application Deadline</p>
            <p className="text-2xl font-bold">June 1, 2024</p>
          </div>
        </div>
      </div>

      {applications.length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Applications</h2>
          <div className="space-y-3">
            {applications.map((app) => {
              const housing = housingOptions.find(h => h.id === app.housingId);
              const room = housing?.roomTypes.find(r => r.type === app.roomType);
              return (
                <div key={app.id} className="flex items-center justify-between p-4 bg-white rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{housing?.name}</p>
                    <p className="text-sm text-gray-500">{app.roomType} - {room?.price}</p>
                    <p className="text-xs text-gray-400">Applied: {app.appliedDate}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm">
                      {app.status}
                    </span>
                    <button
                      onClick={() => cancelApplication(app.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Housing Preferences</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Room Type</label>
            <select
              value={preferences.roomType}
              onChange={(e) => setPreferences({ ...preferences, roomType: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg"
            >
              <option value="single">Single Room</option>
              <option value="double">Double Room</option>
              <option value="suite">Suite</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Floor</label>
            <select
              value={preferences.floor}
              onChange={(e) => setPreferences({ ...preferences, floor: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg"
            >
              <option value="no_preference">No Preference</option>
              <option value="ground">Ground Floor</option>
              <option value="upper">Upper Floor</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Bathroom</label>
            <select
              value={preferences.bathroom}
              onChange={(e) => setPreferences({ ...preferences, bathroom: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg"
            >
              <option value="private">Private</option>
              <option value="semi_private">Semi-Private</option>
              <option value="shared">Shared</option>
            </select>
          </div>
          <div className="flex items-center gap-4 pt-6">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={preferences.quiet}
                onChange={(e) => setPreferences({ ...preferences, quiet: e.target.checked })}
                className="rounded"
              />
              <span className="text-sm text-gray-700">Quiet Floor</span>
            </label>
          </div>
        </div>
      </div>

      <h2 className="text-xl font-semibold text-gray-900">Available Housing</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {housingOptions.map((housing) => (
          <div key={housing.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
            <img src={housing.image} alt={housing.name} className="w-full h-40 object-cover" />
            <div className="p-5">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-xs text-gray-500">{housing.type}</p>
                  <h3 className="text-lg font-semibold text-gray-900">{housing.name}</h3>
                </div>
                <div className="flex items-center gap-1 text-yellow-600">
                  <Star size={14} fill="currentColor" />
                  <span className="text-sm">{housing.rating}</span>
                </div>
              </div>
              <p className="text-sm text-gray-500 mb-3">{housing.description}</p>
              <div className="flex items-center gap-2 text-xs text-gray-400 mb-3">
                <MapPin size={12} />
                <span>{housing.distance} to campus</span>
              </div>
              <div className="flex flex-wrap gap-1 mb-4">
                {housing.amenities.map((amenity) => (
                  <span key={amenity} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                    {amenity}
                  </span>
                ))}
              </div>
              <div className="space-y-2 border-t border-gray-100 pt-4">
                {housing.roomTypes.map((room) => (
                  <div key={room.type} className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{room.type}</p>
                      <p className="text-xs text-gray-500">{room.available} available</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-gray-900">{room.price}</p>
                      <button
                        onClick={() => {
                          setSelectedHousing({ ...housing, selectedRoom: room.type });
                          setShowApplyModal(true);
                        }}
                        className="text-xs text-blue-600 hover:text-blue-700"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Apply Modal */}
      <Modal
        isOpen={showApplyModal}
        onClose={() => { setShowApplyModal(false); setSelectedHousing(null); }}
        title="Apply for Housing"
        size="sm"
      >
        {selectedHousing && (
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="font-medium text-gray-900">{selectedHousing.name}</p>
              <p className="text-sm text-gray-600">{selectedHousing.selectedRoom}</p>
              <p className="text-lg font-bold text-gray-900 mt-2">
                {selectedHousing.roomTypes.find(r => r.type === selectedHousing.selectedRoom)?.price}
              </p>
            </div>
            <p className="text-sm text-gray-600">
              By submitting this application, you agree to the housing contract terms and payment schedule.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => { setShowApplyModal(false); setSelectedHousing(null); }}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => applyForHousing(selectedHousing.id, selectedHousing.selectedRoom)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Submit Application
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
