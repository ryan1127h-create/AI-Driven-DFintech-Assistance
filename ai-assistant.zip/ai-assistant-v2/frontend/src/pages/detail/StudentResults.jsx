import { Steps } from "../../components/Shell.jsx";

export default function StudentResults({ data, onEdit }) {
   const p = data.progress || { completed: 0, planned: 0, required: 52, remaining: 52 };
  const required = p.required || 52;
  const completedPct = Math.min(100, Math.round(((p.completed || 0) / required) * 100));
  const totalPct = Math.min(100, Math.round((((p.completed || 0) + (p.planned || 0)) / required) * 100));
  const plannedPct = Math.max(0, totalPct - completedPct);
  const isStudent = data.profileType === "current";
  const agentStatus = data.agentStatus || {};

  return (
    <>
    <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Select your profile type and get tailored guidance</h1>
            <p className="text-blue-100">This MVP supports applicant and current-student flows. Applicants get material checks, status, programme comparison, and course/career advice. Current students get course planning, skill-gap, and career-path advice only.</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-200"></p>
          </div>
        </div>
      </div>

      <br />
      <Steps current={3} />
      <div className="page-head reveal"><h1>{isStudent ? "Current student analysis results" : "Applicant analysis results"}</h1><p>The React frontend generated this page from the Flask JSON API response.</p></div>
      <button type="button" className="backlink" onClick={onEdit}>← Edit information and regenerate</button>
      <div className="results-layout">
        <nav className="anchor-nav" aria-label="Result sections">
          {!isStudent && <a href="#materials">📎 Material analysis</a>}
          {!isStudent && <a href="#checklist">📋 Application checklist</a>}
          {!isStudent && <a href="#compare">⚖️ Programme comparison</a>}
          <a href="#courses">🎓 Courses and pathway</a>
          {data.careerAdvice && <a href="#career">💼 Career advice</a>}
        </nav>
        <div>
          {!isStudent && <section id="materials" className="panel reveal"><div className="panel__head"><h2 className="panel__title">📎 Current material analysis</h2></div><div className="summary-strip"><div><strong>{data.materialSummary?.submittedRequired ?? 0} / {data.materialSummary?.requiredTotal ?? 0}</strong><span>required materials uploaded</span></div><div><strong>{data.materialSummary?.missingRequired ?? 0}</strong><span>missing</span></div><div><strong>{data.materialSummary?.rejectedRequired ?? 0}</strong><span>invalid format/size</span></div><div><strong>{data.materialSummary?.isComplete ? "Complete" : "Incomplete"}</strong><span>system material check</span></div></div><ul className="items">{(data.materials || []).map((m) => <li className="item" key={m.key}><div className="item__row"><span className="item__label">{m.label}</span><span className={`pill ${m.status === "uploaded" ? "pill--ok" : m.status === "rejected" ? "pill--danger" : "pill--mute"}`}>{m.status}</span>{m.view_url && <a href={m.view_url} target="_blank" rel="noopener" className="why">View uploaded file ↗</a>}</div><div className="why">{m.reason}</div></li>)}</ul></section>}

          {!isStudent && <section id="checklist" className="panel reveal"><div className="panel__head"><h2 className="panel__title">📋 Application checklist</h2></div>{agentStatus.checklist?.missing_fields?.length ? <div className="note note--warn">Missing profile fields: {agentStatus.checklist.missing_fields.join(", ")}</div> : null}<ul className="items">{(data.checklist || []).map((item) => <li className="item" key={item.key || item.label}><div className="item__row"><span className="item__label">{item.label}</span><span className={item.required ? "pill pill--danger" : "pill pill--mute"}>{item.required ? "Required" : "Supporting"}</span><span className="pill pill--mute">{item.status}</span>{item.deadline && <span className="pill pill--warn">Due {item.deadline}</span>}</div><div className="why">{item.why}</div></li>)}</ul></section>}

          {!isStudent && <section id="compare" className="panel reveal"><div className="panel__head"><h2 className="panel__title">⚖️ Programme comparison</h2></div>{agentStatus.comparison?.speakable && <div className="note note--info" style={{ marginBottom: 12 }}>{agentStatus.comparison.speakable}</div>}<div className="table-scroll"><table><thead><tr><th>Programme</th><th>Duration</th><th>Fees</th><th>Format</th><th>Source</th></tr></thead><tbody>{(data.comparison || []).map((row) => <tr className={row.is_target ? "is-target-row" : ""} key={row.program}><td className={row.is_target ? "is-target" : ""}>{row.program}{row.is_target ? " ★" : ""}</td><td>{row.duration}</td><td>{row.fees}</td><td>{row.format}</td><td>{row.source_url ? <a href={row.source_url} target="_blank" rel="noopener">Official page ↗</a> : <span className="why">No source URL</span>}<br />{row.fetched_at && <span className="why">As of {row.fetched_at}</span>}</td></tr>)}</tbody></table></div><div className="note" style={{ marginTop: 12 }}>Official source links are returned by the backend from <code>programs_dataset.json</code>. The comparison is a decision-support view, not a ranking.</div></section>}

          {!isStudent && <section id="tracker" className="panel reveal"><div className="panel__head"><h2 className="panel__title">🔎 Application status</h2><span className="pill pill--warn">Demo / Mock Status</span></div>{agentStatus.tracker?.speakable && <div className="note note--info" style={{ marginBottom: 12 }}>{agentStatus.tracker.speakable}</div>}<label>Application timeline</label><ol className="timeline">{(data.timeline || []).map((step) => <li className={`timeline__item timeline__item--${step.state}`} key={step.key || step.label}><span className="timeline__dot" /><span>{step.label}</span><em>{step.state}</em></li>)}</ol></section>}

          <section id="courses" className="panel reveal"><div className="panel__head"><h2 className="panel__title">🎓 Course and skill direction advice</h2></div>{data.courseExplanation && <div className="note note--info" style={{ marginBottom: 12 }}>{data.courseExplanation}</div>}{(data.completedCodes || []).length ? <p className="why">Completed modules detected: {(data.completedCodes || []).join(", ")}</p> : <p className="why">No completed modules were entered, so the plan starts from 0 completed Units.</p>}<label>Recommended modules</label>{agentStatus.recommendation?.missing_fields?.length ? <div className="note note--warn">Missing profile fields: {agentStatus.recommendation.missing_fields.join(", ")}</div> : null}<ul className="items">{(data.recommended || []).map((mod) => <li className="item" key={mod.code}><div className="item__row"><span className="item__label"><strong>{mod.code}</strong> {mod.name}</span><span className="pill pill--mute">{mod.credits || 4} Units</span>{mod.source_url && <a href={mod.source_url} target="_blank" rel="noopener" className="why">Course source ↗</a>}</div>{mod.description && <div className="why">{mod.description}</div>}</li>)}</ul>{(data.prereqWarnings || []).length ? <><label>Prerequisite warnings</label><ul className="items">{data.prereqWarnings.map((w) => <li className="item" key={w.code}><strong>{w.code}</strong><div className="why">Missing prerequisite(s): {(w.missing || []).join(", ")}</div></li>)}</ul></> : null}<label>Skills to strengthen</label><div className="checks">{(data.skillGaps || []).length ? data.skillGaps.map((gap) => <span className="pill pill--warn" key={gap}>{gap}</span>) : <span className="pill pill--ok">No obvious skill gap detected</span>}</div><label>Graduation credit progress <span className="muted">{p.completed || 0} / {required} Units completed</span></label><div className="progress progress--stack"><div className="progress__bar progress__bar--completed" style={{ width: `${completedPct}%` }} /><div className="progress__bar progress__bar--planned" style={{ width: `${plannedPct}%` }} /></div><div className="progress-legend"><span><i className="legend-dot legend-dot--completed" />Completed: {p.completed || 0} Units</span><span><i className="legend-dot legend-dot--planned" />Recommended plan: +{p.planned || 0} Units</span><span>Remaining after plan: {p.remaining || 0} Units</span></div><div className="why">The headline progress only counts completed credits. The green segment shows recommended future modules for planning.</div></section>

          {data.careerAdvice && <section id="career" className="panel reveal"><div className="panel__head"><h2 className="panel__title">💼 Career-path advice</h2></div><div className="note note--info">{data.careerAdvice}</div>{(data.requiredSkills || []).length ? <><label>Role skills</label><div className="checks">{data.requiredSkills.map((s) => <span className="pill pill--mute" key={s}>{s}</span>)}</div></> : null}{(data.matchedSkills || []).length ? <><label>Already matched</label><div className="checks">{data.matchedSkills.map((s) => <span className="pill pill--ok" key={s}>{s}</span>)}</div></> : null}</section>}
        </div>
      </div>
    </>
  );
}
