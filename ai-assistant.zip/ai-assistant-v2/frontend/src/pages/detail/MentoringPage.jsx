import { useState } from 'react';
import { Star, Users, MessageCircle, Check, X, Clock, Plus, Trash2, UserCheck } from 'lucide-react';
import Modal from '../../components/Modal';

export default function MentoringPage() {
  const [mentorRequests, setMentorRequests] = useState([
    { id: 1, menteeName: 'John Smith', menteeEmail: 'john@university.edu', major: 'Computer Science', year: 'Junior', status: 'pending', message: 'Looking for guidance on career paths in AI.' },
    { id: 2, menteeName: 'Emily Davis', menteeEmail: 'emily@university.edu', major: 'Data Science', year: 'Senior', status: 'pending', message: 'Need advice on graduate school applications.' },
  ]);

  const [mentees, setMentees] = useState([
    { id: 1, name: 'Sarah Chen', email: 'sarah@university.edu', major: 'Computer Science', year: 'Sophomore', since: 'Jan 2024' },
  ]);

  const [mentorProfile, setMentorProfile] = useState({
    available: true,
    maxMentees: 3,
    expertise: ['Career Development', 'Tech Industry', 'AI/ML'],
    topics: ['Resume Building', 'Interview Prep', 'Graduate School'],
  });

  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // CRUD: Accept mentee request
  const acceptMentee = (id) => {
    const req = mentorRequests.find(r => r.id === id);
    if (req) {
      setMentees([...mentees, { id: Date.now(), name: req.menteeName, email: req.menteeEmail, major: req.major, year: req.year, since: new Date().toLocaleDateString() }]);
      setMentorRequests(mentorRequests.filter(r => r.id !== id));
    }
  };

  // CRUD: Reject mentee request
  const rejectMentee = (id) => {
    setMentorRequests(mentorRequests.filter(r => r.id !== id));
  };

  // CRUD: Remove mentee
  const removeMentee = (id) => {
    setMentees(mentees.filter(m => m.id !== id));
  };

  // Toggle availability
  const toggleAvailability = () => {
    setMentorProfile({ ...mentorProfile, available: !mentorProfile.available });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Mentoring</h1>
            <p className="text-orange-100">Share your experience with current students</p>
          </div>
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg ${mentorProfile.available ? 'bg-green-500/30' : 'bg-red-500/30'}`}>
            <Star size={16} />
            <span className="text-sm">{mentorProfile.available ? 'Available for Mentoring' : 'Not Accepting Mentees'}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{mentees.length}</p>
          <p className="text-sm text-green-600">Active Mentees</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-yellow-700">{mentorRequests.length}</p>
          <p className="text-sm text-yellow-600">Pending Requests</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{mentorProfile.maxMentees}</p>
          <p className="text-sm text-blue-600">Max Mentees</p>
        </div>
      </div>

      {mentorRequests.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Mentee Requests</h2>
          <div className="space-y-3">
            {mentorRequests.map((req) => (
              <div key={req.id} className="flex items-center justify-between p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{req.menteeName}</p>
                  <p className="text-sm text-gray-500">{req.major} • {req.year}</p>
                  <p className="text-sm text-gray-600 mt-1">{req.message}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => acceptMentee(req.id)} className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm flex items-center gap-1"><Check size={16}/> Accept</button>
                  <button onClick={() => rejectMentee(req.id)} className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm flex items-center gap-1"><X size={16}/> Decline</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">My Mentees</h2>
        </div>
        {mentees.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Users size={48} className="mx-auto text-gray-300 mb-3" />
            <p>No active mentees yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {mentees.map((mentee) => (
              <div key={mentee.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white font-bold">{mentee.name.charAt(0)}</div>
                  <div>
                    <p className="font-medium text-gray-900">{mentee.name}</p>
                    <p className="text-sm text-gray-500">{mentee.major} • {mentee.year}</p>
                    <p className="text-xs text-gray-400">Mentoring since: {mentee.since}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm flex items-center gap-1"><MessageCircle size={14}/> Message</button>
                  <button onClick={() => removeMentee(mentee.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-lg"><Trash2 size={16}/></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <button onClick={() => setShowSettingsModal(true)} className="w-full py-3 border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 text-sm">Update Mentor Settings</button>

      <Modal isOpen={showSettingsModal} onClose={() => setShowSettingsModal(false)} title="Mentor Settings" size="sm">
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div><p className="font-medium text-gray-900">Accepting Mentees</p><p className="text-sm text-gray-500">Allow students to request mentorship</p></div>
            <button onClick={toggleAvailability} className={`w-12 h-6 rounded-full transition-colors ${mentorProfile.available ? 'bg-green-500' : 'bg-gray-300'}`}><div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${mentorProfile.available ? 'translate-x-6' : 'translate-x-0.5'}`} /></button>
          </div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Max Mentees</label><input type="number" value={mentorProfile.maxMentees} onChange={(e) => setMentorProfile({...mentorProfile, maxMentees: parseInt(e.target.value)})} className="w-full px-4 py-2 border rounded-lg" /></div>
          <div className="flex justify-end"><button onClick={() => setShowSettingsModal(false)} className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700">Save</button></div>
        </div>
      </Modal>
    </div>
  );
}
