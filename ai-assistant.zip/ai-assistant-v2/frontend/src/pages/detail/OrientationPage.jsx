import { useState } from 'react';
import { Calendar, MapPin, Clock, Users, CheckCircle, UserCheck } from 'lucide-react';

export default function OrientationPage() {
  const [registeredSessions, setRegisteredSessions] = useState(['session-1', 'session-2']);

  const [orientationSessions] = useState([
    { id: 'session-1', title: 'Welcome & Keynote', date: 'August 20, 2024', time: '9:00 AM - 12:00 PM', location: 'Main Auditorium', type: 'mandatory', speaker: 'Dr. Sarah Mitchell, University President' },
    { id: 'session-2', title: 'Academic Advising', date: 'August 20, 2024', time: '1:00 PM - 4:00 PM', location: 'Academic Building, Room 201', type: 'mandatory', speaker: 'Department Advisors' },
    { id: 'session-3', title: 'Campus Tour', date: 'August 21, 2024', time: '10:00 AM - 12:00 PM', location: 'Student Center', type: 'optional', speaker: 'Student Ambassadors' },
    { id: 'session-4', title: 'Student Life Workshop', date: 'August 21, 2024', time: '2:00 PM - 4:00 PM', location: 'Recreation Center', type: 'optional', speaker: 'Student Affairs Team' },
    { id: 'session-5', title: 'Library & Research Resources', date: 'August 22, 2024', time: '9:00 AM - 11:00 AM', location: 'University Library', type: 'optional', speaker: 'Library Staff' },
    { id: 'session-6', title: 'Technology & Systems', date: 'August 22, 2024', time: '11:30 AM - 1:00 PM', location: 'Tech Center, Lab 101', type: 'mandatory', speaker: 'IT Services' },
  ]);

  const [importantInfo] = useState([
    { title: 'What to Bring', content: 'Government ID, admission letter, comfortable walking shoes, notebook and pen, questions!' },
    { title: 'Parking', content: 'Free parking available in Lot A and B. Shuttles run every 15 minutes.' },
    { title: 'Check-in', content: 'Arrive 30 minutes early. Bring your confirmation email.' },
    { title: 'Contact', content: 'Questions? Contact orientation@university.edu or call (555) 123-4567' },
  ]);

  // Toggle session registration
  const toggleSession = (sessionId) => {
    setRegisteredSessions(prev =>
      prev.includes(sessionId) ? prev.filter(id => id !== sessionId) : [...prev, sessionId]
    );
  };

  const [schedule] = useState([
    { day: 'Day 1', date: 'Aug 20', activities: ['Welcome & Keynote', 'Lunch', 'Academic Advising', 'Campus Social'] },
    { day: 'Day 2', date: 'Aug 21', activities: ['Campus Tour', 'Lunch', 'Student Life Workshop', 'Evening Event'] },
    { day: 'Day 3', date: 'Aug 22', activities: ['Library Resources', 'Technology Systems', 'Lunch', 'Closing Ceremony'] },
  ]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Orientation Schedule</h1>
            <p className="text-blue-100">August 20-22, 2024 • 3-Day Program</p>
          </div>
          <div className="text-right">
            <p className="text-blue-200 text-sm">Sessions Registered</p>
            <p className="text-3xl font-bold">{registeredSessions.length}/{orientationSessions.length}</p>
          </div>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
        <div className="flex items-center gap-3">
          <UserCheck size={24} className="text-yellow-600" />
          <div>
            <p className="font-medium text-yellow-800">Mandatory Sessions</p>
            <p className="text-sm text-yellow-700">Some sessions are required. Make sure to attend all mandatory sessions.</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Weekly Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {schedule.map((day) => (
            <div key={day.day} className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <p className="font-semibold text-gray-900">{day.day}</p>
                <p className="text-sm text-gray-500">{day.date}</p>
              </div>
              <div className="space-y-2">
                {day.activities.map((activity, idx) => (
                  <p key={idx} className="text-sm text-gray-600">• {activity}</p>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Available Sessions</h2>
        <div className="space-y-4">
          {orientationSessions.map((session) => {
            const isRegistered = registeredSessions.includes(session.id);
            const isMandatory = session.type === 'mandatory';
            return (
              <div
                key={session.id}
                className={`p-4 rounded-lg border ${
                  isRegistered ? 'bg-green-50 border-green-200' :
                  isMandatory ? 'bg-yellow-50 border-yellow-200' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                      isRegistered ? 'bg-green-500' : isMandatory ? 'bg-yellow-500' : 'bg-gray-300'
                    }`}>
                      {isRegistered ? (
                        <CheckCircle size={20} className="text-white" />
                      ) : (
                        <Calendar size={20} className="text-white" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium text-gray-900">{session.title}</h3>
                        {isMandatory && (
                          <span className="text-xs px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded-full">
                            Required
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{session.speaker}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock size={12} />
                          {session.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin size={12} />
                          {session.location}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">{session.date}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleSession(session.id)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium ${
                      isRegistered
                        ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        : isMandatory
                          ? 'bg-yellow-600 text-white hover:bg-yellow-700'
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                  >
                    {isRegistered ? 'Registered' : 'Register'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Important Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {importantInfo.map((info, idx) => (
            <div key={idx} className="p-4 bg-gray-50 rounded-lg">
              <p className="font-medium text-gray-900 mb-1">{info.title}</p>
              <p className="text-sm text-gray-600">{info.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
