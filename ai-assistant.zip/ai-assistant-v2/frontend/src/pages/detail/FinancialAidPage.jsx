import { useState } from 'react';
import { DollarSign, CheckCircle, Clock, AlertCircle, TrendingUp, Calendar, FileText } from 'lucide-react';

export default function FinancialAidPage() {
  const [aidSummary] = useState({
    total: '$25,000',
    scholarships: '$15,000',
    grants: '$8,000',
    loans: '$2,000',
    workStudy: '$0',
    balance: '$500',
  });

  const [aidItems, setAidItems] = useState([
    { id: 1, name: 'Merit Scholarship', amount: '$15,000', type: 'scholarship', status: 'accepted', requirements: 'Maintain 3.0 GPA', renewable: true },
    { id: 2, name: 'Federal Pell Grant', amount: '$6,000', type: 'grant', status: 'accepted', requirements: 'Enrolled full-time', renewable: true },
    { id: 3, name: 'State Grant', amount: '$2,000', type: 'grant', status: 'accepted', requirements: 'State resident', renewable: true },
    { id: 4, name: 'Federal Direct Loan', amount: '$2,000', type: 'loan', status: 'pending', requirements: 'Complete loan counseling', renewable: true },
  ]);

  const [disbursements] = useState([
    { id: 1, date: 'Sep 15, 2024', amount: '$12,500', status: 'scheduled', semester: 'Fall 2024' },
    { id: 2, date: 'Jan 15, 2025', amount: '$12,500', status: 'estimated', semester: 'Spring 2025' },
  ]);

  // CRUD: Accept/Decline aid
  const toggleAidStatus = (id) => {
    setAidItems(aidItems.map(item =>
      item.id === id
        ? { ...item, status: item.status === 'accepted' ? 'declined' : 'accepted' }
        : item
    ));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Financial Aid</h1>
            <p className="text-green-100">Manage your financial aid package</p>
          </div>
          <div className="text-right">
            <p className="text-green-200 text-sm">Total Aid Package</p>
            <p className="text-4xl font-bold">{aidSummary.total}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{aidSummary.scholarships}</p>
          <p className="text-sm text-blue-600">Scholarships</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{aidSummary.grants}</p>
          <p className="text-sm text-green-600">Grants</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-yellow-700">{aidSummary.loans}</p>
          <p className="text-sm text-yellow-600">Loans</p>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-gray-700">{aidSummary.balance}</p>
          <p className="text-sm text-gray-600">Balance Due</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Aid Package Details</h2>
        <div className="space-y-3">
          {aidItems.map((item) => (
            <div
              key={item.id}
              className={`p-4 rounded-lg border ${
                item.status === 'accepted' ? 'bg-green-50 border-green-200' :
                item.status === 'declined' ? 'bg-red-50 border-red-200' :
                'bg-yellow-50 border-yellow-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900">{item.name}</p>
                  <p className="text-xs text-gray-500 capitalize">{item.type}</p>
                  <p className="text-xs text-gray-400">{item.requirements}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-gray-900">{item.amount}</p>
                  <button
                    onClick={() => toggleAidStatus(item.id)}
                    className={`mt-1 px-3 py-1 rounded text-xs font-medium ${
                      item.status === 'accepted'
                        ? 'bg-green-100 text-green-700'
                        : item.status === 'declined'
                          ? 'bg-red-100 text-red-700'
                          : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    {item.status}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Disbursement Schedule</h2>
          <div className="space-y-3">
            {disbursements.map((disb) => (
              <div key={disb.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{disb.semester}</p>
                  <p className="text-sm text-gray-500">{disb.date}</p>
                </div>
                <div>
                  <p className="text-lg font-bold text-gray-900">{disb.amount}</p>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    disb.status === 'scheduled' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {disb.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Actions Required</h2>
          <div className="space-y-3">
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertCircle size={20} className="text-yellow-600 mt-0.5" />
                <div>
                  <p className="font-medium text-gray-900">Complete Loan Counseling</p>
                  <p className="text-sm text-gray-600">Required before loan disbursement</p>
                  <button className="mt-2 px-4 py-2 bg-yellow-600 text-white rounded text-sm hover:bg-yellow-700">
                    Start Counseling
                  </button>
                </div>
              </div>
            </div>
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start gap-3">
                <CheckCircle size={20} className="text-green-600 mt-0.5" />
                <div>
                  <p className="font-medium text-gray-900">FAFSA Completed</p>
                  <p className="text-sm text-gray-600">All requirements satisfied</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
