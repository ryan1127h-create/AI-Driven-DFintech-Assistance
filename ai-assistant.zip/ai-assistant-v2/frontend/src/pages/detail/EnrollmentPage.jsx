import { useState } from 'react';
import { CheckCircle, Circle, Plus, Trash2, Calendar, Clock, CreditCard, Home, GraduationCap } from 'lucide-react';
import Modal from '../../components/Modal';

export default function EnrollmentPage() {
  const [steps, setSteps] = useState([
    { id: 's1', name: 'Accept Admission Offer', status: 'completed', dueDate: 'May 1, 2024', description: 'Accept your admission offer through the student portal', icon: CheckCircle },
    { id: 's2', name: 'Pay Enrollment Deposit', status: 'completed', dueDate: 'May 1, 2024', description: '$500 non-refundable deposit to secure your spot', icon: CreditCard },
    { id: 's3', name: 'Complete Enrollment Forms', status: 'in_progress', dueDate: 'June 1, 2024', description: 'Submit required enrollment documents', icon: GraduationCap },
    { id: 's4', name: 'Housing Application', status: 'pending', dueDate: 'June 1, 2024', description: 'Apply for on-campus housing', icon: Home },
    { id: 's5', name: 'Orientation Registration', status: 'pending', dueDate: 'July 1, 2024', description: 'Register for orientation session', icon: Calendar },
    { id: 's6', name: 'Course Registration', status: 'pending', dueDate: 'August 1, 2024', description: 'Register for fall semester courses', icon: GraduationCap },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newStep, setNewStep] = useState({ name: '', dueDate: '', description: '' });

  // CRUD: Update step status
  const updateStepStatus = (stepId, status) => {
    setSteps(steps.map(step =>
      step.id === stepId ? { ...step, status } : step
    ));
  };

  // CRUD: Add step
  const addStep = () => {
    if (newStep.name.trim()) {
      setSteps([...steps, {
        id: `s${Date.now()}`,
        name: newStep.name.trim(),
        status: 'pending',
        dueDate: newStep.dueDate || 'TBD',
        description: newStep.description.trim(),
        icon: Circle
      }]);
      setNewStep({ name: '', dueDate: '', description: '' });
      setShowAddModal(false);
    }
  };

  // CRUD: Delete step
  const deleteStep = (stepId) => {
    setSteps(steps.filter(step => step.id !== stepId));
  };

  const completedCount = steps.filter(s => s.status === 'completed').length;
  const inProgressCount = steps.filter(s => s.status === 'in_progress').length;
  const totalCount = steps.length;

  const getStatusColor = (status) => {
    const colors = {
      completed: 'bg-green-100 text-green-700 border-green-200',
      in_progress: 'bg-blue-100 text-blue-700 border-blue-200',
      pending: 'bg-gray-100 text-gray-600 border-gray-200',
    };
    return colors[status] || colors.pending;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Enrollment Steps</h1>
            <p className="text-green-100">Complete your enrollment checklist</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-green-200">Progress</p>
            <p className="text-3xl font-bold">{completedCount}/{totalCount}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{completedCount}</p>
          <p className="text-sm text-green-600">Completed</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{inProgressCount}</p>
          <p className="text-sm text-blue-600">In Progress</p>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-gray-700">{totalCount - completedCount - inProgressCount}</p>
          <p className="text-sm text-gray-600">Pending</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Enrollment Checklist</h2>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"
          >
            <Plus size={16} />
            Add Step
          </button>
        </div>

        <div className="space-y-4">
          {steps.map((step) => (
            <div
              key={step.id}
              className={`p-4 rounded-lg border ${getStatusColor(step.status)}`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  step.status === 'completed' ? 'bg-green-500' :
                  step.status === 'in_progress' ? 'bg-blue-500' : 'bg-gray-300'
                }`}>
                  {step.status === 'completed' && <CheckCircle size={20} className="text-white" />}
                  {step.status === 'in_progress' && <Clock size={20} className="text-white" />}
                  {step.status === 'pending' && <Circle size={20} className="text-white" />}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{step.name}</p>
                  <p className="text-sm text-gray-500 mt-1">{step.description}</p>
                  <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                    <Calendar size={12} />
                    Due: {step.dueDate}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={step.status}
                    onChange={(e) => updateStepStatus(step.id, e.target.value)}
                    className="px-3 py-1.5 rounded-lg text-sm border-0 cursor-pointer bg-white/50"
                  >
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                  </select>
                  <button
                    onClick={() => deleteStep(step.id)}
                    className="p-2 text-red-500 hover:bg-red-100 rounded-lg"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Step Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => { setShowAddModal(false); setNewStep({ name: '', dueDate: '', description: '' }); }}
        title="Add Enrollment Step"
        size="sm"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Step Name</label>
            <input
              type="text"
              value={newStep.name}
              onChange={(e) => setNewStep({ ...newStep, name: e.target.value })}
              placeholder="e.g., Submit Health Forms"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
            <input
              type="text"
              value={newStep.dueDate}
              onChange={(e) => setNewStep({ ...newStep, dueDate: e.target.value })}
              placeholder="e.g., June 15, 2024"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              value={newStep.description}
              onChange={(e) => setNewStep({ ...newStep, description: e.target.value })}
              placeholder="Brief description of this step"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 min-h-[80px]"
            />
          </div>
          <div className="flex justify-end gap-3">
            <button
              onClick={() => { setShowAddModal(false); setNewStep({ name: '', dueDate: '', description: '' }); }}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={addStep}
              disabled={!newStep.name.trim()}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
            >
              Add Step
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
