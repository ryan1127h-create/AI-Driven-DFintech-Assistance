import { useState } from 'react';
import { User, BookOpen, Briefcase, MapPin, Code, DollarSign, Target, Brain, TrendingUp, Save, Edit2 } from 'lucide-react';
import Modal from '../../components/Modal';

export default function ProfilePage() {
  const [profile, setProfile] = useState({
    personal: {
      firstName: 'Alex',
      lastName: 'Johnson',
      email: 'alex.johnson@university.edu',
      phone: '(555) 123-4567',
      country: 'United States',
      region: 'California',
    },
    academic: {
      currentRole: 'enrolled',
      major: 'Computer Science',
      minor: 'Mathematics',
      year: 'Junior',
      gpa: 3.72,
      expectedGraduation: 'Spring 2025',
      institution: 'State University',
      previousEducation: [
        { degree: 'High School Diploma', institution: 'Central High School', year: '2022' },
      ],
    },
    workExperience: [
      { id: 1, company: 'Tech Internship Inc', role: 'Software Developer Intern', duration: 'Summer 2023', description: 'Developed REST APIs using Node.js' },
      { id: 2, company: 'Campus IT', role: 'Tech Support', duration: '2022-Present', description: 'Provided technical support to students' },
    ],
    technicalProficiency: {
      programming: { rating: 4, skills: ['Python', 'JavaScript', 'Java', 'C++'] },
      databases: { rating: 3, skills: ['PostgreSQL', 'MongoDB'] },
      frameworks: { rating: 3, skills: ['React', 'Node.js', 'Django'] },
      tools: { rating: 4, skills: ['Git', 'Docker', 'AWS', 'Linux'] },
      ai: { rating: 2, skills: ['TensorFlow basics'] },
    },
    financeKnowledge: {
      level: 'intermediate',
      courses: ['Financial Accounting', 'Microeconomics'],
      certifications: [],
      interests: ['Investment Banking', 'FinTech'],
    },
    targetJobRoles: [
      { role: 'Software Engineer', industry: 'Tech', priority: 1 },
      { role: 'Data Scientist', industry: 'Tech', priority: 2 },
      { role: 'Product Manager', industry: 'Tech', priority: 3 },
    ],
    learningStyle: {
      preferred: 'visual',
      pace: 'self-paced',
      groupWork: 'occasional',
      handsOn: true,
      formats: ['Video tutorials', 'Interactive projects', 'Reading documentation'],
    },
    applicationProgress: {
      applicationsSubmitted: 8,
      interviewsScheduled: 3,
      offersReceived: 0,
      networkingConnections: 12,
    },
    careerGoals: {
      shortTerm: 'Secure a software engineering internship',
      mediumTerm: 'Work at a top tech company',
      longTerm: 'Become a tech lead or start a company',
    },
    recommendations: [],
  });

  const [showWorkModal, setShowWorkModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [newWorkExp, setNewWorkExp] = useState({ company: '', role: '', duration: '', description: '' });
  const [newRole, setNewRole] = useState({ role: '', industry: '', priority: 1 });

  // CRUD: Add work experience
  const addWorkExperience = () => {
    if (newWorkExp.company.trim() && newWorkExp.role.trim()) {
      setProfile({
        ...profile,
        workExperience: [...profile.workExperience, { id: Date.now(), ...newWorkExp }]
      });
      setNewWorkExp({ company: '', role: '', duration: '', description: '' });
      setShowWorkModal(false);
    }
  };

  // CRUD: Remove work experience
  const removeWorkExperience = (id) => {
    setProfile({ ...profile, workExperience: profile.workExperience.filter(w => w.id !== id) });
  };

  // CRUD: Add target role
  const addTargetRole = () => {
    if (newRole.role.trim()) {
      setProfile({
        ...profile,
        targetJobRoles: [...profile.targetJobRoles, { ...newRole, priority: profile.targetJobRoles.length + 1 }]
      });
      setNewRole({ role: '', industry: '', priority: 1 });
      setShowRoleModal(false);
    }
  };

  // CRUD: Remove target role
  const removeTargetRole = (index) => {
    setProfile({
      ...profile,
      targetJobRoles: profile.targetJobRoles.filter((_, i) => i !== index)
    });
  };

  // Generate recommendations based on profile
  const generateRecommendations = () => {
    const recs = [];

    // Course recommendations based on technical gaps
    if (profile.technicalProficiency.ai.rating < 3) {
      recs.push({ type: 'course', title: 'Machine Learning Fundamentals', reason: 'Based on your career goals in tech', priority: 'high' });
    }
    if (profile.financeKnowledge.level === 'beginner') {
      recs.push({ type: 'course', title: 'Introduction to FinTech', reason: 'Aligns with your interest in FinTech', priority: 'medium' });
    }

    // Job recommendations based on target roles
    recs.push({ type: 'job', title: 'Software Engineering Intern at Google', reason: 'Matches your primary career goal', priority: 'high' });
    recs.push({ type: 'job', title: 'Data Science Intern at Microsoft', reason: 'Based on your secondary interest', priority: 'medium' });

    // Skill development recommendations
    if (profile.technicalProficiency.frameworks.rating < 4) {
      recs.push({ type: 'skill', title: 'Learn Kubernetes', reason: 'In-demand skill for your target roles', priority: 'high' });
    }

    // Networking recommendations
    recs.push({ type: 'network', title: 'Connect with alumni at Meta', reason: '3 alumni share your background', priority: 'medium' });

    setProfile({ ...profile, recommendations: recs });
  };

  const proficiencyLevels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
  const learningStyles = ['visual', 'auditory', 'reading', 'kinesthetic'];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center text-3xl font-bold">
            {profile.personal.firstName.charAt(0)}{profile.personal.lastName.charAt(0)}
          </div>
          <div>
            <h1 className="text-3xl font-bold">{profile.personal.firstName} {profile.personal.lastName}</h1>
            <p className="text-blue-100">{profile.academic.major} • {profile.academic.year}</p>
          </div>
        </div>
      </div>

      {/* Personal Information */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <User size={20} className="text-blue-600" />
          Personal Information
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" value={profile.personal.email} onChange={(e) => setProfile({...profile, personal: {...profile.personal, email: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
            <input type="text" value={profile.personal.phone} onChange={(e) => setProfile({...profile, personal: {...profile.personal, phone: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Country/Region</label>
            <input type="text" value={profile.personal.country} onChange={(e) => setProfile({...profile, personal: {...profile.personal, country: e.target.value, region: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
        </div>
      </div>

      {/* Academic Background */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <BookOpen size={20} className="text-green-600" />
          Academic Background
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Major</label>
            <input type="text" value={profile.academic.major} onChange={(e) => setProfile({...profile, academic: {...profile.academic, major: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Minor</label>
            <input type="text" value={profile.academic.minor} onChange={(e) => setProfile({...profile, academic: {...profile.academic, minor: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Current GPA</label>
            <input type="number" step="0.01" value={profile.academic.gpa} onChange={(e) => setProfile({...profile, academic: {...profile.academic, gpa: parseFloat(e.target.value)}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Expected Graduation</label>
            <input type="text" value={profile.academic.expectedGraduation} onChange={(e) => setProfile({...profile, academic: {...profile.academic, expectedGraduation: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
        </div>
        <div className="mt-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Previous Education</h3>
          <div className="space-y-2">
            {profile.academic.previousEducation.map((edu, idx) => (
              <div key={idx} className="p-3 bg-gray-50 rounded-lg">
                <p className="font-medium text-gray-900">{edu.degree}</p>
                <p className="text-sm text-gray-500">{edu.institution} • {edu.year}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Work Experience */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <Briefcase size={20} className="text-purple-600" />
            Work Experience
          </h2>
          <button onClick={() => setShowWorkModal(true)} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 text-sm flex items-center gap-2">
            <Edit2 size={16} /> Add Experience
          </button>
        </div>
        <div className="space-y-4">
          {profile.workExperience.map((work) => (
            <div key={work.id} className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-gray-900">{work.role}</p>
                  <p className="text-sm text-gray-500">{work.company} • {work.duration}</p>
                  <p className="text-sm text-gray-600 mt-1">{work.description}</p>
                </div>
                <button onClick={() => removeWorkExperience(work.id)} className="p-1 text-red-500 hover:bg-red-50 rounded">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Technical Proficiency */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Code size={20} className="text-indigo-600" />
          Technical Proficiency
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Object.entries(profile.technicalProficiency).map(([category, data]) => (
            <div key={category} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="font-medium text-gray-900 capitalize">{category}</p>
                <select
                  value={data.rating}
                  onChange={(e) => setProfile({
                    ...profile,
                    technicalProficiency: {
                      ...profile.technicalProficiency,
                      [category]: { ...data, rating: parseInt(e.target.value) }
                    }
                  })}
                  className="px-3 py-1 border rounded text-sm"
                >
                  {proficiencyLevels.map((level, idx) => (
                    <option key={level} value={idx}>{level}</option>
                  ))}
                </select>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full mb-2">
                <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${(data.rating / 4) * 100}%` }} />
              </div>
              <div className="flex flex-wrap gap-1">
                {data.skills.map((skill) => (
                  <span key={skill} className="text-xs px-2 py-1 bg-indigo-100 text-indigo-700 rounded-full">{skill}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Finance Knowledge */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <DollarSign size={20} className="text-green-600" />
          Finance Knowledge
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Knowledge Level</label>
            <select value={profile.financeKnowledge.level} onChange={(e) => setProfile({...profile, financeKnowledge: {...profile.financeKnowledge, level: e.target.value}})} className="w-full px-4 py-2 border rounded-lg">
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Courses Taken</label>
            <input type="text" value={profile.financeKnowledge.courses.join(', ')} onChange={(e) => setProfile({...profile, financeKnowledge: {...profile.financeKnowledge, courses: e.target.value.split(', ')}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Finance Interests</label>
            <input type="text" value={profile.financeKnowledge.interests.join(', ')} onChange={(e) => setProfile({...profile, financeKnowledge: {...profile.financeKnowledge, interests: e.target.value.split(', ')}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
        </div>
      </div>

      {/* Target Job Roles */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <Target size={20} className="text-red-600" />
            Target Job Roles
          </h2>
          <button onClick={() => setShowRoleModal(true)} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm flex items-center gap-2">
            <Edit2 size={16} /> Add Role
          </button>
        </div>
        <div className="space-y-3">
          {profile.targetJobRoles.map((role, idx) => (
            <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-medium">Priority {role.priority}</span>
                  <p className="font-medium text-gray-900">{role.role}</p>
                </div>
                <p className="text-sm text-gray-500">{role.industry}</p>
              </div>
              <button onClick={() => removeTargetRole(idx)} className="p-2 text-red-500 hover:bg-red-50 rounded">
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Preferred Learning Style */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Brain size={20} className="text-yellow-600" />
          Preferred Learning Style
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Learning Style</label>
            <select value={profile.learningStyle.preferred} onChange={(e) => setProfile({...profile, learningStyle: {...profile.learningStyle, preferred: e.target.value}})} className="w-full px-4 py-2 border rounded-lg">
              {learningStyles.map(style => <option key={style} value={style}>{style.charAt(0).toUpperCase() + style.slice(1)}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Pace</label>
            <select value={profile.learningStyle.pace} onChange={(e) => setProfile({...profile, learningStyle: {...profile.learningStyle, pace: e.target.value}})} className="w-full px-4 py-2 border rounded-lg">
              <option value="self-paced">Self-Paced</option>
              <option value="structured">Structured</option>
              <option value="intensive">Intensive</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Group Work</label>
            <select value={profile.learningStyle.groupWork} onChange={(e) => setProfile({...profile, learningStyle: {...profile.learningStyle, groupWork: e.target.value}})} className="w-full px-4 py-2 border rounded-lg">
              <option value="rarely">Rarely</option>
              <option value="occasional">Occasional</option>
              <option value="frequently">Frequently</option>
            </select>
          </div>
          <div className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={profile.learningStyle.handsOn} onChange={(e) => setProfile({...profile, learningStyle: {...profile.learningStyle, handsOn: e.target.checked}})} className="rounded" />
              <span className="text-sm font-medium text-gray-700">Hands-on Learning</span>
            </label>
          </div>
        </div>
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Formats</label>
          <input type="text" value={profile.learningStyle.formats.join(', ')} onChange={(e) => setProfile({...profile, learningStyle: {...profile.learningStyle, formats: e.target.value.split(', ')}})} className="w-full px-4 py-2 border rounded-lg" />
        </div>
      </div>

      {/* Application Progress */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <TrendingUp size={20} className="text-blue-600" />
          Application Progress
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className="text-2xl font-bold text-blue-700">{profile.applicationProgress.applicationsSubmitted}</p>
            <p className="text-sm text-blue-600">Applications Submitted</p>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg">
            <p className="text-2xl font-bold text-yellow-700">{profile.applicationProgress.interviewsScheduled}</p>
            <p className="text-sm text-yellow-600">Interviews Scheduled</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <p className="text-2xl font-bold text-green-700">{profile.applicationProgress.offersReceived}</p>
            <p className="text-sm text-green-600">Offers Received</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <p className="text-2xl font-bold text-purple-700">{profile.applicationProgress.networkingConnections}</p>
            <p className="text-sm text-purple-600">Network Connections</p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Short-term Goal</label>
            <input type="text" value={profile.careerGoals.shortTerm} onChange={(e) => setProfile({...profile, careerGoals: {...profile.careerGoals, shortTerm: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Medium-term Goal</label>
            <input type="text" value={profile.careerGoals.mediumTerm} onChange={(e) => setProfile({...profile, careerGoals: {...profile.careerGoals, mediumTerm: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Long-term Goal</label>
            <input type="text" value={profile.careerGoals.longTerm} onChange={(e) => setProfile({...profile, careerGoals: {...profile.careerGoals, longTerm: e.target.value}})} className="w-full px-4 py-2 border rounded-lg" />
          </div>
        </div>
      </div>

      {/* AI-Generated Recommendations */}
      {profile.recommendations.length > 0 && (
        <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-xl border border-indigo-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Brain size={20} className="text-indigo-600" />
            Personalized Recommendations
          </h2>
          <div className="space-y-3">
            {profile.recommendations.map((rec, idx) => (
              <div key={idx} className={`p-4 rounded-lg ${rec.priority === 'high' ? 'bg-red-50 border-red-200' : 'bg-white border-gray-200'} border`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className={`text-xs px-2 py-1 rounded-full ${rec.type === 'course' ? 'bg-blue-100 text-blue-700' : rec.type === 'job' ? 'bg-green-100 text-green-700' : rec.type === 'skill' ? 'bg-purple-100 text-purple-700' : 'bg-yellow-100 text-yellow-700'}`}>
                      {rec.type}
                    </span>
                    <p className="font-medium text-gray-900 mt-1">{rec.title}</p>
                    <p className="text-sm text-gray-500">{rec.reason}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded ${rec.priority === 'high' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}>
                    {rec.priority}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Save Button */}
      <div className="flex justify-end gap-4">
        <button onClick={generateRecommendations} className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2">
          <Brain size={18} /> Generate Recommendations
        </button>
        <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2">
          <Save size={18} /> Save Profile
        </button>
      </div>

      {/* Add Work Experience Modal */}
      <Modal isOpen={showWorkModal} onClose={() => setShowWorkModal(false)} title="Add Work Experience" size="md">
        <div className="space-y-4">
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Company</label><input type="text" value={newWorkExp.company} onChange={(e) => setNewWorkExp({...newWorkExp, company: e.target.value})} className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Role</label><input type="text" value={newWorkExp.role} onChange={(e) => setNewWorkExp({...newWorkExp, role: e.target.value})} className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Duration</label><input type="text" value={newWorkExp.duration} onChange={(e) => setNewWorkExp({...newWorkExp, duration: e.target.value})} placeholder="e.g., Summer 2024" className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Description</label><textarea value={newWorkExp.description} onChange={(e) => setNewWorkExp({...newWorkExp, description: e.target.value})} className="w-full px-4 py-2 border rounded-lg min-h-[80px]" /></div>
          <div className="flex justify-end gap-3"><button onClick={() => setShowWorkModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button><button onClick={addWorkExperience} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">Add</button></div>
        </div>
      </Modal>

      {/* Add Target Role Modal */}
      <Modal isOpen={showRoleModal} onClose={() => setShowRoleModal(false)} title="Add Target Role" size="sm">
        <div className="space-y-4">
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Job Role</label><input type="text" value={newRole.role} onChange={(e) => setNewRole({...newRole, role: e.target.value})} placeholder="e.g., Software Engineer" className="w-full px-4 py-2 border rounded-lg" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Industry</label><input type="text" value={newRole.industry} onChange={(e) => setNewRole({...newRole, industry: e.target.value})} placeholder="e.g., Tech" className="w-full px-4 py-2 border rounded-lg" /></div>
          <div className="flex justify-end gap-3"><button onClick={() => setShowRoleModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button><button onClick={addTargetRole} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">Add</button></div>
        </div>
      </Modal>
    </div>
  );
}
