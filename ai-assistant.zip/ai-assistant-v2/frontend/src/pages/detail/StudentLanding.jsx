import { Panel, Steps } from "../../components/Shell.jsx";

export default function StudentLanding({ onNext,  disabled = false }) {
  return (
    <>
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Select your profile type and get tailored guidance</h1>
            <p className="text-blue-100">This MVP supports applicant and current-student flows. Applicants get material checks, status, programme comparison, and course/career advice. Current students get course planning, skill-gap, and career-path advice only.</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-200"></p>
          </div>
        </div>
      </div>

      <br />
      <Steps current={1} />
      <form onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        onNext?.(fd);
      }}>
        <Panel title="1. Choose user type">
          <div className="role-cards" role="radiogroup" aria-label="User type">
            <label className="role-card"><input type="radio" name="lifecycle_stage" value="applicant" defaultChecked /><span className="role-card__title">Applicant</span><span className="role-card__desc">Upload materials, identify missing items, track status, compare programmes, and get course/career guidance.</span></label>
            <label className="role-card"><input type="radio" name="lifecycle_stage" value="current" /><span className="role-card__title">Current Student</span><span className="role-card__desc">Skip application materials and generate course recommendations, skill strengthening, and career direction.</span></label>
          </div>
        </Panel>
        <Panel title="2. Enter your information or upload a CV">
          <div className="note note--info">React now posts this form to the Flask backend. The backend parses PDF/Word files and reads <code>data/.deepseek.json</code> for DeepSeek extraction; the API key is not exposed to the browser.</div>
          <label htmlFor="text">Profile summary</label>
          <textarea id="text" name="text" rows="6" placeholder="Example: I majored in Computer Science, worked in banking for 2 years, completed IT5003 and FT5010, and want to become a fintech product manager." />
          <label htmlFor="cv">CV file</label>
          <input type="file" id="cv" name="cv" accept=".docx,.pdf" />
        </Panel>
        <button type="submit" className="btn btn--lg" disabled={disabled}>{disabled ? "Extracting with backend..." : "Next: confirm profile →"}</button>
      </form>
    </>
  );
}
