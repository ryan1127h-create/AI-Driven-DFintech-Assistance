import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useTheme.jsx';
import { Bookmark, BookmarkCheck, Shield, Trash2, Search, Filter, BookOpen } from 'lucide-react';
import Modal from '../../components/Modal.jsx';
import { usePrograms } from "../../context/ProgramsContext.jsx";

export default function ProgramsPage() {
  const { currentUser } = useAuth();
  const [savedPrograms, setSavedPrograms] = useState([]);
  const [showSavedModal, setShowSavedModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');  
  const [selectedTypes, setSelectedTypes] = useState([]);
  const [selectedFaculties, setSelectedFaculties] = useState([]);
  const [selectedDurations, setSelectedDurations] = useState([]);
  const [selectedAreas, setSelectedAreas] = useState([]);
  const [selectedIntakes, setSelectedIntakes] = useState([]);
  const [expandedIds, setExpandedIds] = useState([]);
  const { programs } = usePrograms();
  const [showFilters, setShowFilters] = useState(false);


  const toggleExpand = (id) => {
    setExpandedIds((prev) =>
      prev.includes(id)
        ? prev.filter((i) => i !== id)
        : [...prev, id]
    );
  };

  // CRUD: Save program
  const saveProgram = (program) => {
    if (!savedPrograms.find(p => p.id === program.id)) {
      setSavedPrograms([...savedPrograms, {
        id: program.id,
        name: program.name,
        degree: program.degree,
        tuition: program.tuition,
        deadline: program.deadline
      }]);
    }
  };

  // CRUD: Remove saved program
  const removeSavedProgram = (programId) => {
    setSavedPrograms(savedPrograms.filter(p => p.id !== programId));
  };

  const isProgramSaved = (programId) => {
    return savedPrograms.some(p => p.id === programId);
  };

  const types = [...new Set(programs.map(p => p.type))];    
  const faculties = [...new Set(programs.map(p => p.faculty))];
  const durations = [...new Set(programs.map(p => p.duration))];
  const intakes = [...new Set(programs.map(p => p.deadline))];

  // ✅ split area into tags
  const areas = [
    ...new Set(
      programs.flatMap(p =>
        p.area?.split(";").map(a => a.trim()) || []
      )
    )
  ];

  const toggleFilter = (value, selected, setSelected) => {
    setSelected(prev =>
      prev.includes(value)
        ? prev.filter(v => v !== value)
        : [...prev, value]
    );
  };

  const filteredPrograms = programs.filter(program => {
    const matchesSearch =
      program.name.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType =
      selectedTypes.length === 0 || selectedTypes.includes(program.type);

    const matchesFaculty =
      selectedFaculties.length === 0 || selectedFaculties.includes(program.faculty);

    const matchesDuration =
      selectedDurations.length === 0 || selectedDurations.includes(program.duration);

    const matchesIntake =
      selectedIntakes.length === 0 || selectedIntakes.includes(program.deadline);

    const matchesArea =
      selectedAreas.length === 0 ||
      program.area?.split(";").some(a =>
        selectedAreas.includes(a.trim())
      );

    return (
      matchesSearch &&
      matchesType &&
      matchesFaculty &&
      matchesDuration &&
      matchesIntake &&
      matchesArea
    );
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Programs</h1>
            <p className="text-blue-100">Explore our academic programs and find your path</p>
          </div>
          <button
            onClick={() => setShowSavedModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"
          >
            <Bookmark size={18} />
            <span className="text-sm font-medium">Saved ({savedPrograms.length})</span>
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3">

        {/* Search */}
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            placeholder="Search programs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Filter toggle button */}
        <button
          onClick={() => setShowFilters(prev => !prev)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg text-sm hover:bg-gray-200 transition"
        >
          <Filter size={16} />
          Filters
        </button>

        {/* Optional reset */}
        <button
          onClick={() => {
            setSelectedTypes([]);
            setSelectedFaculties([]);
            setSelectedDurations([]);
            setSelectedAreas([]);
            setSelectedIntakes([]);
          }}
          className="text-sm text-gray-500 hover:underline"
        >
          Reset
        </button>

       {showFilters && (
          <div className="bg-white border rounded-xl p-4 mt-3 shadow-sm space-y-4">

            {/* TYPE */}
            <div>
              <p className="text-sm font-medium mb-2">Programme Type</p>
              <div className="flex flex-wrap gap-3">
                {types.map(type => (
                  <label key={type} className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={selectedTypes.includes(type)}
                      onChange={() => toggleFilter(type, selectedTypes, setSelectedTypes)}
                    />
                    {type}
                  </label>
                ))}
              </div>
            </div>

            {/* FACULTY */}
            <div>
              <p className="text-sm font-medium mb-2">Faculty</p>
              <div className="flex flex-wrap gap-3">
                {faculties.map(f => (
                  <label key={f} className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={selectedFaculties.includes(f)}
                      onChange={() => toggleFilter(f, selectedFaculties, setSelectedFaculties)}
                    />
                    {f}
                  </label>
                ))}
              </div>
            </div>

            {/* MODE */}
            <div>
              <p className="text-sm font-medium mb-2">Mode</p>
              <div className="flex flex-wrap gap-3">
                {durations.map(d => (
                  <label key={d} className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={selectedDurations.includes(d)}
                      onChange={() => toggleFilter(d, selectedDurations, setSelectedDurations)}
                    />
                    {d}
                  </label>
                ))}
              </div>
            </div>

            {/* AREAS (chips) */}
            <div>
              <p className="text-sm font-medium mb-2">Area of Interest</p>
              <div className="flex flex-wrap gap-2">
                {areas.map(a => (
                  <button
                    key={a}
                    onClick={() => toggleFilter(a, selectedAreas, setSelectedAreas)}
                    className={`text-xs px-2 py-1 rounded-full border ${
                      selectedAreas.includes(a)
                        ? "bg-blue-600 text-white"
                        : "bg-gray-100"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>

          </div>
        )}


      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPrograms.map((program) => (
          <div
            key={program.id}
            className="bg-gray-50 rounded-2xl border border-gray-200 p-5 flex flex-col justify-between hover:shadow-md transition"
          >
            {/* Title + badge */}
            <div className="flex justify-between items-start">

              <h3 className="text-lg font-semibold text-gray-900 leading-snug line-clamp-2">
                {program.name}
              </h3>

              <button
                onClick={() => saveProgram(program)}
                className="p-1 rounded-full hover:bg-gray-200 transition"
              >
                {isProgramSaved(program.id) ? (
                  <BookmarkCheck size={18} className="text-green-600" />
                ) : (
                  <Bookmark size={18} className="text-gray-500" />
                )}
              </button>
            </div>

            {/* Faculty */}
            <p className="text-xs text-gray-400 mt-1">
              {program.faculty}
            </p>

            {/* Type */}
            <p className="text-sm text-gray-500 mt-2">
              {program.degree}
            </p>

            {/* Area (clean formatting) */}
            <p className="text-sm text-gray-600 mt-2 line-clamp-2">
              {program.area?.replace(/;/g, ", ")}
            </p>

            {/* Description (expandable) */}
            <div className="text-sm text-gray-600 mt-2">
              <p className={expandedIds.includes(program.id) ? "" : "line-clamp-3"}>
                {program.description}
              </p>

              {program.description && program.description.length > 150 && (
                <button
                  onClick={() => toggleExpand(program.id)}
                  className="text-blue-600 text-xs mt-1 hover:underline"
                >
                  {expandedIds.includes(program.id) ? "Show less" : "Show more"}
                </button>
              )}
            </div>

            {/* Key info */}
            <div className="mt-4 text-sm space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-500">Mode:</span>
                <span className="font-medium">{program.duration}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-500">Intake:</span>
                <span className="font-medium text-red-500">
                  {program.deadline}
                </span>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-3 mt-5">

              {/* Learn More */}
              <a
                href={program.link}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 text-center text-sm font-medium border border-gray-200 rounded-xl hover:bg-gray-100 transition"
              >
                Learn More
              </a>

              {/* Apply Now */}
              <a
                href={program.applyLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 text-center text-sm font-medium text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition"
              >
                Apply Now
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Saved Programs Modal */}
      <Modal
        isOpen={showSavedModal}
        onClose={() => setShowSavedModal(false)}
        title="Saved Programs"
        size="lg"
      >
        <div className="space-y-4">
          {savedPrograms.length === 0 ? (
            <div className="text-center py-8">
              <Bookmark size={48} className="mx-auto text-gray-300 mb-3" />
              <p className="text-gray-500">No saved programs yet.</p>
              <p className="text-sm text-gray-400 mt-1">Save programs to compare them later.</p>
            </div>
          ) : (
            savedPrograms.map((program) => (
              <div
                key={program.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div>
                  <h4 className="font-medium text-gray-900">{program.name}</h4>
                  <p className="text-sm text-gray-500">{program.degree}</p>
                  <div className="flex gap-4 mt-1 text-xs text-gray-400">
                    {/* <span>{program.tuition}</span> */}
                    <span>Deadline: {program.deadline}</span>
                  </div>
                </div>
                <button
                  onClick={() => removeSavedProgram(program.id)}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  title="Remove"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))
          )}
        </div>
      </Modal>
    </div>
  );
}
