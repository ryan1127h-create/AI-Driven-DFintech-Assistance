import { useState } from 'react';
import { BookOpen, Plus, Trash2, Search, Edit2, Eye, Shield } from 'lucide-react';
import Modal from '../../components/Modal';

export default function KnowledgePage() {
  const [articles, setArticles] = useState([
    { id: 1, title: 'Admission Requirements', category: 'admissions', content: 'To apply for admission, students must submit a completed application form, official transcripts, standardized test scores (SAT/ACT), letters of recommendation, and a personal statement...', views: 1234, updated: '2024-03-01' },
    { id: 2, title: 'Financial Aid Process', category: 'financial', content: 'Financial aid is available through scholarships, grants, loans, and work-study programs. Complete the FAFSA to determine eligibility...', views: 856, updated: '2024-03-10' },
    { id: 3, title: 'Course Registration Guide', category: 'registration', content: 'Course registration opens one month before each semester. Students must meet with their advisor before registering...', views: 634, updated: '2024-03-05' },
    { id: 4, title: 'Transfer Credit Policy', category: 'admissions', content: 'Transfer credits are evaluated on a case-by-case basis. Official transcripts from accredited institutions are required...', views: 423, updated: '2024-02-28' },
    { id: 5, title: 'Career Services Overview', category: 'career', content: 'Career services offers resume reviews, mock interviews, job fairs, and networking events throughout the academic year...', views: 567, updated: '2024-03-08' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [newArticle, setNewArticle] = useState({ title: '', category: 'admissions', content: '' });

  // CRUD: Add article
  const addArticle = () => {
    if (newArticle.title.trim() && newArticle.content.trim()) {
      setArticles([{
        id: Date.now(),
        ...newArticle,
        views: 0,
        updated: new Date().toISOString().split('T')[0]
      }, ...articles]);
      setNewArticle({ title: '', category: 'admissions', content: '' });
      setShowAddModal(false);
    }
  };

  // CRUD: Edit article
  const updateArticle = () => {
    if (selectedArticle) {
      setArticles(articles.map(a =>
        a.id === selectedArticle.id ? { ...selectedArticle, updated: new Date().toISOString().split('T')[0] } : a
      ));
      setShowEditModal(false);
    }
  };

  // CRUD: Delete article
  const deleteArticle = (id) => {
    setArticles(articles.filter(a => a.id !== id));
  };

  const filteredArticles = articles.filter(a => {
    const matchesSearch = a.title.toLowerCase().includes(searchTerm.toLowerCase()) || a.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterCategory === 'all' || a.category === filterCategory;
    return matchesSearch && matchesFilter;
  });

  const categories = ['all', 'admissions', 'financial', 'registration', 'career', 'housing', 'graduation'];

  const getCategoryColor = (category) => {
    const colors = {
      admissions: 'bg-blue-100 text-blue-700',
      financial: 'bg-green-100 text-green-700',
      registration: 'bg-purple-100 text-purple-700',
      career: 'bg-orange-100 text-orange-700',
      housing: 'bg-yellow-100 text-yellow-700',
      graduation: 'bg-emerald-100 text-emerald-700',
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Knowledge Base</h1>
            <p className="text-slate-300">Manage AI assistant knowledge articles</p>
          </div>
          <button onClick={() => setShowAddModal(true)} className="px-4 py-2 bg-white text-slate-800 rounded-lg hover:bg-slate-100 flex items-center gap-2">
            <Plus size={18} />
            Add Article
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{articles.filter(a => a.category === 'admissions').length}</p>
          <p className="text-sm text-blue-600">Admissions</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{articles.filter(a => a.category === 'financial').length}</p>
          <p className="text-sm text-green-600">Financial</p>
        </div>
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-purple-700">{articles.filter(a => a.category === 'registration').length}</p>
          <p className="text-sm text-purple-600">Registration</p>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-gray-700">{articles.reduce((sum, a) => sum + a.views, 0).toLocaleString()}</p>
          <p className="text-sm text-gray-600">Total Views</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative flex-1">
            {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
            <input type="text" placeholder="Search articles..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat === 'all' ? 'All Categories' : cat.charAt(0).toUpperCase() + cat.slice(1)}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredArticles.map((article) => (
            <div key={article.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow group">
              <div className="flex items-start justify-between mb-2">
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${getCategoryColor(article.category)}`}>
                  {article.category}
                </span>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => { setSelectedArticle(article); setShowEditModal(true); }} className="p-1.5 text-blue-600 hover:bg-blue-100 rounded">
                    <Edit2 size={14} />
                  </button>
                  <button onClick={() => deleteArticle(article.id)} className="p-1.5 text-red-600 hover:bg-red-100 rounded">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{article.title}</h3>
              <p className="text-sm text-gray-500 line-clamp-2">{article.content}</p>
              <div className="flex items-center justify-between mt-3 text-xs text-gray-400">
                <span className="flex items-center gap-1"><Eye size={12} /> {article.views} views</span>
                <span>Updated: {article.updated}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Article Modal */}
      <Modal isOpen={showAddModal} onClose={() => setShowAddModal(false)} title="Add Knowledge Article" size="md">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
            <input type="text" value={newArticle.title} onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })} placeholder="Article title" className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select value={newArticle.category} onChange={(e) => setNewArticle({ ...newArticle, category: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg">
              {categories.filter(c => c !== 'all').map(cat => (
                <option key={cat} value={cat}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
            <textarea value={newArticle.content} onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })} placeholder="Article content..." className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 min-h-[150px]" />
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowAddModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={addArticle} disabled={!newArticle.title.trim() || !newArticle.content.trim()} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">Add Article</button>
          </div>
        </div>
      </Modal>

      {/* Edit Article Modal */}
      <Modal isOpen={showEditModal} onClose={() => setShowEditModal(false)} title="Edit Article" size="md">
        {selectedArticle && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
              <input type="text" value={selectedArticle.title} onChange={(e) => setSelectedArticle({ ...selectedArticle, title: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select value={selectedArticle.category} onChange={(e) => setSelectedArticle({ ...selectedArticle, category: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg">
                {categories.filter(c => c !== 'all').map(cat => (
                  <option key={cat} value={cat}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
              <textarea value={selectedArticle.content} onChange={(e) => setSelectedArticle({ ...selectedArticle, content: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 min-h-[150px]" />
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setShowEditModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
              <button onClick={updateArticle} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Save Changes</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
