import { useState } from 'react';
import { Activity, Search, Filter, User, Settings, FileText, Users, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

export default function ActivityLogPage() {
  const [logs, setLogs] = useState([
    { id: 1, action: 'Inquiry Created', entity: 'inquiry', user: 'System', timestamp: '2024-03-12 10:30:15', details: 'Student John Smith created inquiry #1234', type: 'create' },
    { id: 2, action: 'Application Updated', entity: 'application', user: 'Admin', timestamp: '2024-03-12 10:25:42', details: 'Application #567 status changed to admitted', type: 'update' },
    { id: 3, action: 'Student Added', entity: 'student', user: 'Admin', timestamp: '2024-03-12 10:20:00', details: 'New student Emily Davis enrolled', type: 'create' },
    { id: 4, action: 'Inquiry Escalated', entity: 'inquiry', user: 'Admin', timestamp: '2024-03-12 10:15:30', details: 'Inquiry #1205 escalated to human agent', type: 'escalate' },
    { id: 5, action: 'Knowledge Article Added', entity: 'knowledge', user: 'Admin', timestamp: '2024-03-12 10:10:00', details: 'Article "Transfer Credit Policy" created', type: 'create' },
    { id: 6, action: 'Settings Changed', entity: 'settings', user: 'Admin', timestamp: '2024-03-12 10:05:00', details: 'Automation rate threshold updated', type: 'update' },
    { id: 7, action: 'User Login', entity: 'user', user: 'Admin', timestamp: '2024-03-12 10:00:00', details: 'Admin user logged in', type: 'login' },
    { id: 8, action: 'Inquiry Resolved', entity: 'inquiry', user: 'AI Agent', timestamp: '2024-03-12 09:55:30', details: 'Inquiry #1230 resolved automatically', type: 'resolve' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterEntity, setFilterEntity] = useState('all');

  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.action.toLowerCase().includes(searchTerm.toLowerCase()) || log.details.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || log.type === filterType;
    const matchesEntity = filterEntity === 'all' || log.entity === filterEntity;
    return matchesSearch && matchesType && matchesEntity;
  });

  const getActionIcon = (type) => {
    const icons = { create: CheckCircle, update: Settings, escalate: AlertTriangle, resolve: CheckCircle, login: User };
    const Icon = icons[type] || FileText;
    return <Icon size={16} className={type === 'escalate' ? 'text-red-500' : type === 'create' ? 'text-green-500' : type === 'resolve' ? 'text-blue-500' : 'text-gray-500'} />;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Activity Log</h1>
        <p className="text-slate-300">System activity audit trail and event history</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
            <input type="text" placeholder="Search logs..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
            <option value="all">All Actions</option>
            <option value="create">Create</option>
            <option value="update">Update</option>
            <option value="escalate">Escalate</option>
            <option value="resolve">Resolve</option>
          </select>
          <select value={filterEntity} onChange={(e) => setFilterEntity(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
            <option value="all">All Entities</option>
            <option value="inquiry">Inquiries</option>
            <option value="application">Applications</option>
            <option value="student">Students</option>
            <option value="knowledge">Knowledge</option>
            <option value="settings">Settings</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Action</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Details</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">User</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Timestamp</th>
            </tr>
          </thead>
          <tbody>
            {filteredLogs.map((log) => (
              <tr key={log.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 px-4">
                  <div className="flex items-center gap-2">
                    {getActionIcon(log.type)}
                    <span className="font-medium text-gray-900">{log.action}</span>
                  </div>
                </td>
                <td className="py-3 px-4 text-sm text-gray-600">{log.details}</td>
                <td className="py-3 px-4 text-sm text-gray-600">{log.user}</td>
                <td className="py-3 px-4 text-sm text-gray-400">{log.timestamp}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
