import { useState } from 'react';
import { Users, Calendar, Heart, Star, TrendingUp, Briefcase, Globe, Award } from 'lucide-react';

export default function AlumniPreviewPage() {
  const [alumniFeatures] = useState([
    { icon: Users, title: 'Global Network', description: '10,000+ alumni across 80 countries', stat: '10,000+' },
    { icon: Calendar, title: 'Exclusive Events', description: 'Annual galas, networking mixers, and regional meetups', stat: '50+ annually' },
    { icon: Star, title: 'Mentorship Program', description: 'Connect with current students as a mentor', stat: '500 mentors' },
    { icon: Briefcase, title: 'Career Network', description: 'Job postings from alumni-owned companies', stat: '2,000+ jobs' },
    { icon: Heart, title: 'Give Back', description: 'Support scholarships and campus initiatives', stat: '$5M raised' },
    { icon: TrendingUp, title: 'Professional Growth', description: 'Continuing education and leadership programs', stat: '100+ programs' },
  ]);

  const [successStories] = useState([
    { name: 'Dr. Sarah Chen', gradYear: 2015, role: 'CEO, TechStart Inc', quote: 'The alumni network opened doors I never knew existed.' },
    { name: 'Michael Rodriguez', gradYear: 2010, role: 'VP Engineering, Google', quote: 'I still mentor students and it\'s incredibly rewarding.' },
    { name: 'Jennifer Park', gradYear: 2018, role: 'Founder, GreenCycle', quote: 'Found my co-founder at an alumni networking event.' },
  ]);

  const [networkStats] = useState({
    totalAlumni: 45000,
    recentGraduates: 3500,
    activeMembers: 12000,
    countries: 80,
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <Users size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Welcome to the Alumni Network</h1>
            <p className="text-orange-100">Preview what awaits you after graduation</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{networkStats.totalAlumni.toLocaleString()}</p>
          <p className="text-sm text-gray-500">Total Alumni</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{networkStats.activeMembers.toLocaleString()}</p>
          <p className="text-sm text-gray-500">Active Members</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{networkStats.countries}</p>
          <p className="text-sm text-gray-500">Countries</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{networkStats.recentGraduates.toLocaleString()}</p>
          <p className="text-sm text-gray-500">Class of 2024</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Alumni Benefits</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {alumniFeatures.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="p-4 bg-gray-50 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                    <Icon size={20} className="text-orange-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{feature.title}</p>
                    <p className="text-xl font-bold text-orange-600">{feature.stat}</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Success Stories</h2>
        <div className="space-y-4">
          {successStories.map((story, idx) => (
            <div key={idx} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white font-bold shrink-0">
                {story.name.charAt(0)}
              </div>
              <div>
                <p className="font-medium text-gray-900">{story.name} <span className="text-sm text-gray-500">• Class of {story.gradYear}</span></p>
                <p className="text-sm text-gray-600">{story.role}</p>
                <p className="text-sm text-gray-500 italic mt-2">"{story.quote}"</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-r from-orange-100 to-yellow-50 rounded-xl border border-orange-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Ready to Join?</h3>
            <p className="text-sm text-gray-600">You'll automatically be enrolled in the alumni network upon graduation.</p>
          </div>
          <div className="flex items-center gap-2">
            <Award size={24} className="text-orange-600" />
            <span className="text-sm text-orange-700 font-medium">Alumni Status: Pending Graduation</span>
          </div>
        </div>
      </div>
    </div>
  );
}
