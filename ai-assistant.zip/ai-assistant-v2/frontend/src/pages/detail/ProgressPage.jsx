import { useState } from 'react';
import { TrendingUp, Plus, Calendar, BarChart3, Award, BookOpen } from 'lucide-react';
import Modal from '../../components/Modal';

export default function ProgressPage() {
  const [gpaHistory, setGpaHistory] = useState([
    { id: 1, semester: 'Fall 2022', credits: 15, gpa: 3.5, courses: ['CS101', 'MATH101', 'ENG101', 'PHYS101', 'HIST101'] },
    { id: 2, semester: 'Spring 2023', credits: 16, gpa: 3.6, courses: ['CS201', 'MATH201', 'ENG201', 'PHYS201'] },
    { id: 3, semester: 'Fall 2023', credits: 18, gpa: 3.8, courses: ['CS301', 'CS302', 'MATH301', 'ELECT201'] },
    { id: 4, semester: 'Spring 2024', credits: 18, gpa: 3.72, courses: ['CS401', 'CS402', 'MATH401'] },
  ]);

  const [progress, setProgress] = useState({
    totalCredits: 84,
    requiredCredits: 120,
    currentGPA: 3.72,
    standing: 'Good Standing',
    expectedGraduation: 'Spring 2025',
  });

  const [showAddGPAModal, setShowAddGPAModal] = useState(false);
  const [showUpdateCreditsModal, setShowUpdateCreditsModal] = useState(false);
  const [newGPA, setNewGPA] = useState({ semester: '', credits: 15, gpa: '' });
  const [newCredits, setNewCredits] = useState('');

  // CRUD: Add GPA record
  const addGPARecord = () => {
    if (newGPA.semester.trim() && newGPA.gpa) {
      setGpaHistory([...gpaHistory, {
        id: Date.now(),
        semester: newGPA.semester,
        credits: newGPA.credits,
        gpa: parseFloat(newGPA.gpa)
      }]);
      setNewGPA({ semester: '', credits: 15, gpa: '' });
      setShowAddGPAModal(false);
    }
  };

  // CRUD: Update credits
  const updateCredits = () => {
    if (newCredits) {
      setProgress({ ...progress, totalCredits: parseInt(newCredits) });
      setNewCredits('');
      setShowUpdateCreditsModal(false);
    }
  };

  const progressPercentage = (progress.totalCredits / progress.requiredCredits) * 100;
  const cumulativeGPA = (gpaHistory.reduce((sum, sem) => sum + sem.gpa, 0) / gpaHistory.length).toFixed(2);

  const requirements = [
    { name: 'Core Requirements', value: 85, color: 'bg-green-500' },
    { name: 'Major Courses', value: 72, color: 'bg-blue-500' },
    { name: 'Electives', value: 45, color: 'bg-purple-500' },
    { name: 'General Education', value: 90, color: 'bg-yellow-500' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Academic Progress</h1>
            <p className="text-indigo-100">Track your degree completion</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-indigo-200">Cumulative GPA</p>
            <p className="text-4xl font-bold">{cumulativeGPA}</p>
            <p className="text-sm text-indigo-200">{progress.standing}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
          <p className="text-3xl font-bold text-gray-900">{progress.totalCredits}</p>
          <p className="text-sm text-gray-500">Credits Earned</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
          <p className="text-3xl font-bold text-gray-900">{progress.requiredCredits - progress.totalCredits}</p>
          <p className="text-sm text-gray-500">Credits Remaining</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
          <p className="text-3xl font-bold text-gray-900">{Math.round(progressPercentage)}%</p>
          <p className="text-sm text-gray-500">Complete</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
          <p className="text-3xl font-bold text-gray-900">{progress.expectedGraduation}</p>
          <p className="text-sm text-gray-500">Expected Grad</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Degree Progress</h2>
          <button
            onClick={() => { setNewCredits(progress.totalCredits); setShowUpdateCreditsModal(true); }}
            className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700"
          >
            <TrendingUp size={16} />
            Update Credits
          </button>
        </div>
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">Overall Progress</span>
            <span className="font-medium">{progress.totalCredits}/{progress.requiredCredits}</span>
          </div>
          <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full" style={{ width: `${progressPercentage}%` }} />
          </div>
        </div>
        <div className="space-y-3">
          {requirements.map((req) => (
            <div key={req.name}>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-600">{req.name}</span>
                <span className="font-medium">{req.value}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full">
                <div className={`h-full ${req.color} rounded-full`} style={{ width: `${req.value}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">GPA History</h2>
          {/* <button
            onClick={() => setShowAddGPAModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm"
          >
            <Plus size={16} />
            Add Semester
          </button> */}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Semester</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Credits</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">GPA</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody>
              {gpaHistory.map((record) => (
                <tr key={record.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{record.semester}</td>
                  <td className="py-3 px-4 text-gray-600">{record.credits}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      record.gpa >= 3.5 ? 'bg-green-100 text-green-700' :
                      record.gpa >= 3.0 ? 'bg-blue-100 text-blue-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {record.gpa.toFixed(2)}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-green-600 text-sm">Completed</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add GPA Modal */}
      <Modal isOpen={showAddGPAModal} onClose={() => setShowAddGPAModal(false)} title="Add Semester GPA" size="sm">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Semester</label>
            <input type="text" value={newGPA.semester} onChange={(e) => setNewGPA({ ...newGPA, semester: e.target.value })} placeholder="e.g., Fall 2024" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Credits</label>
            <input type="number" value={newGPA.credits} onChange={(e) => setNewGPA({ ...newGPA, credits: parseInt(e.target.value) })} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">GPA</label>
            <input type="number" step="0.01" value={newGPA.gpa} onChange={(e) => setNewGPA({ ...newGPA, gpa: e.target.value })} placeholder="e.g., 3.85" className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500" />
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowAddGPAModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={addGPARecord} disabled={!newGPA.semester.trim() || !newGPA.gpa} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50">Add</button>
          </div>
        </div>
      </Modal>

      {/* Update Credits Modal */}
      <Modal isOpen={showUpdateCreditsModal} onClose={() => setShowUpdateCreditsModal(false)} title="Update Credits Earned" size="sm">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Total Credits Earned</label>
            <input type="number" value={newCredits} onChange={(e) => setNewCredits(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500" />
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowUpdateCreditsModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={updateCredits} disabled={!newCredits} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50">Update</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
