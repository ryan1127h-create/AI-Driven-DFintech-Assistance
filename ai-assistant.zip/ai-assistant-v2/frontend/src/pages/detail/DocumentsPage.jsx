import { useState } from 'react';
import { FileText, Upload, Plus, Trash2, Check, Clock, AlertCircle, Lock } from 'lucide-react';
import Modal from '../../components/Modal';

export default function DocumentsPage() {
  const [documents, setDocuments] = useState([
    { id: 1, name: 'Personal Statement', status: 'received', uploadDate: 'Feb 18, 2024', reviewed: true, reviewedBy: 'Admissions Office' },
    { id: 2, name: 'Official Transcripts', status: 'received', uploadDate: 'Feb 20, 2024', reviewed: true, reviewedBy: 'Records Office' },
    { id: 3, name: 'SAT/ACT Scores', status: 'received', uploadDate: 'Feb 15, 2024', reviewed: true, reviewedBy: 'Testing Center' },
    { id: 4, name: 'Recommendation Letters', status: 'pending', uploadDate: null, reviewed: false, reviewedBy: null },
    { id: 5, name: 'Portfolio (Optional)', status: 'not_submitted', uploadDate: null, reviewed: false, reviewedBy: null },
  ]);

  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [newDocName, setNewDocName] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);

  // CRUD: Add document (user adds a new document requirement)
  const addDocument = () => {
    if (newDocName.trim()) {
      setDocuments([...documents, {
        id: Date.now(),
        name: newDocName.trim(),
        status: 'pending',
        uploadDate: null,
        reviewed: false,
        reviewedBy: null
      }]);
      setNewDocName('');
      setShowAddModal(false);
    }
  };

  // CRUD: Upload document (changes status from pending/not_submitted to received)
  const uploadDocument = (docId) => {
    setSelectedDoc(docId);
    setShowUploadModal(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setDocuments(documents.map(doc =>
            doc.id === docId
              ? { ...doc, status: 'received', uploadDate: new Date().toLocaleDateString() }
              : doc
          ));
          setShowUploadModal(false);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  // CRUD: Delete document (only if not required)
  const deleteDocument = (docId) => {
    setDocuments(documents.filter(doc => doc.id !== docId));
  };

  const getStatusBadge = (status) => {
    const badges = {
      received: { icon: Check, text: 'Received', color: 'bg-green-100 text-green-700', iconColor: 'text-green-600' },
      pending: { icon: Clock, text: 'Pending Upload', color: 'bg-yellow-100 text-yellow-700', iconColor: 'text-yellow-600' },
      not_submitted: { icon: AlertCircle, text: 'Not Submitted', color: 'bg-gray-100 text-gray-600', iconColor: 'text-gray-500' },
    };
    return badges[status];
  };

  const receivedCount = documents.filter(d => d.status === 'received').length;
  const totalCount = documents.length;
  const progressPercentage = (receivedCount / totalCount) * 100;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Documents</h1>
            <p className="text-blue-100">Manage your application documents</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-200">Completion</p>
            <p className="text-3xl font-bold">{receivedCount}/{totalCount}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">Overall Progress</span>
            <span className="font-medium">{Math.round(progressPercentage)}%</span>
          </div>
          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-yellow-500 to-green-500 rounded-full transition-all" style={{ width: `${progressPercentage}%` }} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold text-gray-900">Required Documents</h2>
            <Lock size={16} className="text-gray-400" title="Secure Data" />
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm"
          >
            <Plus size={16} />
            Add Document
          </button>
        </div>

        <div className="space-y-3">
          {documents.map((doc) => {
            const badge = getStatusBadge(doc.status);
            const StatusIcon = badge.icon;
            return (
              <div
                key={doc.id}
                className={`flex items-center justify-between p-4 rounded-lg ${
                  doc.status === 'received' ? 'bg-green-50' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    doc.status === 'received' ? 'bg-green-100' : 'bg-gray-200'
                  }`}>
                    <FileText size={20} className={doc.status === 'received' ? 'text-green-600' : 'text-gray-500'} />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{doc.name}</p>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      {doc.uploadDate ? (
                        <span>Uploaded: {doc.uploadDate}</span>
                      ) : (
                        <span>Not yet uploaded</span>
                      )}
                      {doc.reviewed && <span className="text-green-600">• Reviewed by {doc.reviewedBy}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {doc.status !== 'received' && (
                    <button
                      onClick={() => uploadDocument(doc.id)}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
                    >
                      <Upload size={16} />
                      Upload
                    </button>
                  )}
                  {doc.status === 'received' && (
                    <span className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-medium ${badge.color}`}>
                      <StatusIcon size={14} className={badge.iconColor} />
                      {badge.text}
                    </span>
                  )}
                  <button
                    onClick={() => deleteDocument(doc.id)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                    title="Remove"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Upload Modal */}
      <Modal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        title="Uploading Document"
        size="sm"
      >
        <div className="space-y-4 text-center">
          <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-blue-600 rounded-full transition-all" style={{ width: `${uploadProgress}%` }} />
          </div>
          <p className="text-sm text-gray-600">{uploadProgress}% complete</p>
          {uploadProgress >= 100 && (
            <p className="text-green-600 font-medium">Upload complete!</p>
          )}
        </div>
      </Modal>

      {/* Add Document Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => { setShowAddModal(false); setNewDocName(''); }}
        title="Add Document Requirement"
        size="sm"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Document Name</label>
            <input
              type="text"
              value={newDocName}
              onChange={(e) => setNewDocName(e.target.value)}
              placeholder="e.g., Financial Aid Form"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex justify-end gap-3">
            <button
              onClick={() => { setShowAddModal(false); setNewDocName(''); }}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={addDocument}
              disabled={!newDocName.trim()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              Add Document
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
