import { useState } from 'react';
import { CheckCircle, Circle, Plus, Trash2, Calendar, Clock, AlertCircle } from 'lucide-react';
import Modal from '../../components/Modal';

export default function TasksPage() {
  const [tasks, setTasks] = useState([
    { id: 't1', title: 'Complete application form', completed: true, dueDate: 'Mar 1, 2024', priority: 'high' },
    { id: 't2', title: 'Pay application fee', completed: true, dueDate: 'Mar 1, 2024', priority: 'high' },
    { id: 't3', title: 'Submit transcripts', completed: true, dueDate: 'Mar 15, 2024', priority: 'high' },
    { id: 't4', title: 'Submit test scores', completed: true, dueDate: 'Mar 15, 2024', priority: 'high' },
    { id: 't5', title: 'Submit recommendation letters', completed: false, dueDate: 'Mar 30, 2024', priority: 'high' },
    { id: 't6', title: 'Review financial aid options', completed: false, dueDate: 'Apr 1, 2024', priority: 'medium' },
    { id: 't7', title: 'Schedule campus visit', completed: false, dueDate: 'Apr 15, 2024', priority: 'low' },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', dueDate: '', priority: 'medium' });

  // CRUD: Toggle task completion
  const toggleTask = (taskId) => {
    setTasks(tasks.map(task =>
      task.id === taskId ? { ...task, completed: !task.completed } : task
    ));
  };

  // CRUD: Add task
  const addTask = () => {
    if (newTask.title.trim()) {
      setTasks([...tasks, {
        id: `t${Date.now()}`,
        title: newTask.title.trim(),
        completed: false,
        dueDate: newTask.dueDate || 'No due date',
        priority: newTask.priority
      }]);
      setNewTask({ title: '', dueDate: '', priority: 'medium' });
      setShowAddModal(false);
    }
  };

  // CRUD: Delete task
  const deleteTask = (taskId) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };

  const completedCount = tasks.filter(t => t.completed).length;
  const totalCount = tasks.length;
  const progressPercentage = (completedCount / totalCount) * 100;

  const getPriorityColor = (priority) => {
    const colors = {
      high: 'bg-red-100 text-red-700',
      medium: 'bg-yellow-100 text-yellow-700',
      low: 'bg-gray-100 text-gray-600',
    };
    return colors[priority] || colors.medium;
  };

  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Tasks & Checklist</h1>
            <p className="text-blue-100">Complete your application checklist</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-200">Completed</p>
            <p className="text-3xl font-bold">{completedCount}/{totalCount}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">Overall Progress</span>
            <span className="font-medium">{Math.round(progressPercentage)}%</span>
          </div>
          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-yellow-500 to-green-500 rounded-full transition-all" style={{ width: `${progressPercentage}%` }} />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="p-4 bg-green-50 rounded-lg">
            <p className="text-2xl font-bold text-green-700">{completedCount}</p>
            <p className="text-sm text-green-600">Completed</p>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg">
            <p className="text-2xl font-bold text-yellow-700">{totalCount - completedCount}</p>
            <p className="text-sm text-yellow-600">Remaining</p>
          </div>
          <div className="p-4 bg-red-50 rounded-lg">
            <p className="text-2xl font-bold text-red-700">{tasks.filter(t => t.priority === 'high' && !t.completed).length}</p>
            <p className="text-sm text-red-600">High Priority</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Task List</h2>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
          >
            <Plus size={16} />
            Add Task
          </button>
        </div>

        <div className="space-y-2">
          {sortedTasks.map((task) => (
            <div
              key={task.id}
              className={`flex items-center gap-4 p-4 rounded-lg border transition-all cursor-pointer hover:shadow-sm ${
                task.completed
                  ? 'bg-green-50 border-green-200'
                  : task.priority === 'high'
                    ? 'bg-red-50 border-red-200'
                    : 'bg-gray-50 border-gray-200'
              }`}
            >
              <button
                onClick={() => toggleTask(task.id)}
                className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
                  task.completed ? 'bg-green-500' : 'border-2 border-gray-300 hover:border-green-500'
                }`}
              >
                {task.completed ? <CheckCircle size={16} className="text-white" /> : <Circle size={16} className="text-gray-400" />}
              </button>
              <div className="flex-1">
                <p className={`font-medium ${task.completed ? 'text-gray-500 line-through' : 'text-gray-900'}`}>
                  {task.title}
                </p>
                <div className="flex items-center gap-3 text-sm text-gray-500 mt-1">
                  <span className="flex items-center gap-1">
                    <Calendar size={14} />
                    {task.dueDate}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                </div>
              </div>
              <button
                onClick={() => deleteTask(task.id)}
                className="p-2 text-red-500 hover:bg-red-100 rounded-lg"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Add Task Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => { setShowAddModal(false); setNewTask({ title: '', dueDate: '', priority: 'medium' }); }}
        title="Add New Task"
        size="sm"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Task Title</label>
            <input
              type="text"
              value={newTask.title}
              onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              placeholder="e.g., Schedule campus visit"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
            <input
              type="text"
              value={newTask.dueDate}
              onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
              placeholder="e.g., Mar 30, 2024"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
            <select
              value={newTask.priority}
              onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg"
            >
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
          <div className="flex justify-end gap-3">
            <button
              onClick={() => { setShowAddModal(false); setNewTask({ title: '', dueDate: '', priority: 'medium' }); }}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={addTask}
              disabled={!newTask.title.trim()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              Add Task
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
