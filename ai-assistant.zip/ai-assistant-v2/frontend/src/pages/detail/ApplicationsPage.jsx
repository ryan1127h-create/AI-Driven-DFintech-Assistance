import { useState } from 'react';
import { FileText, Plus, Trash2, Search, CheckCircle, Clock, AlertTriangle, Eye } from 'lucide-react';
import Modal from '../../components/Modal';

export default function ApplicationsPage() {
  const [applications, setApplications] = useState([
    { id: 1, studentName: 'Sarah Johnson', program: 'Computer Science', status: 'under_review', submittedDate: '2024-02-20', documents: 3, notes: 'Strong academic background' },
    { id: 2, studentName: 'Michael Chen', program: 'Data Science', status: 'admitted', submittedDate: '2024-01-15', documents: 5, notes: 'Accepted' },
    { id: 3, studentName: 'Alex Turner', program: 'Engineering', status: 'pending_documents', submittedDate: '2024-03-01', documents: 2, notes: 'Missing transcripts' },
    { id: 4, studentName: 'Emily Davis', program: 'Business Administration', status: 'pending', submittedDate: '2024-03-10', documents: 4, notes: '' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedApp, setSelectedApp] = useState(null);

  // CRUD: Update status
  const updateStatus = (id, status) => {
    setApplications(applications.map(a => a.id === id ? { ...a, status } : a));
  };

  // CRUD: Delete
  const deleteApp = (id) => {
    setApplications(applications.filter(a => a.id !== id));
  };

  // CRUD: Add notes
  const updateNotes = (id, notes) => {
    setApplications(applications.map(a => a.id === id ? { ...a, notes } : a));
  };

  const filteredApps = applications.filter(a => {
    const matchesSearch = a.studentName.toLowerCase().includes(searchTerm.toLowerCase()) || a.program.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || a.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (status) => {
    const badges = {
      pending: 'bg-gray-100 text-gray-700',
      pending_documents: 'bg-orange-100 text-orange-700',
      under_review: 'bg-blue-100 text-blue-700',
      admitted: 'bg-green-100 text-green-700',
      rejected: 'bg-red-100 text-red-700',
    };
    return badges[status] || badges.pending;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Applications Management</h1>
        <p className="text-slate-300">Review and process student applications</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-gray-700">{applications.filter(a => a.status === 'pending').length}</p>
          <p className="text-sm text-gray-600">Pending</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{applications.filter(a => a.status === 'under_review').length}</p>
          <p className="text-sm text-blue-600">Under Review</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{applications.filter(a => a.status === 'admitted').length}</p>
          <p className="text-sm text-green-600">Admitted</p>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-orange-700">{applications.filter(a => a.status === 'pending_documents').length}</p>
          <p className="text-sm text-orange-600">Pending Docs</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative flex-1">
            {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
            <input type="text" placeholder="Search applications..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="under_review">Under Review</option>
            <option value="admitted">Admitted</option>
            <option value="rejected">Rejected</option>
            <option value="pending_documents">Pending Documents</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Student</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Program</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Submitted</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredApps.map((app) => (
                <tr key={app.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <p className="font-medium text-gray-900">{app.studentName}</p>
                    <p className="text-xs text-gray-500">{app.documents} documents</p>
                  </td>
                  <td className="py-3 px-4 text-gray-600">{app.program}</td>
                  <td className="py-3 px-4 text-gray-600">{app.submittedDate}</td>
                  <td className="py-3 px-4">
                    <select value={app.status} onChange={(e) => updateStatus(app.id, e.target.value)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border-0 cursor-pointer ${getStatusBadge(app.status)}`}>
                      <option value="pending">Pending</option>
                      <option value="under_review">Under Review</option>
                      <option value="admitted">Admitted</option>
                      <option value="rejected">Rejected</option>
                      <option value="pending_documents">Pending Docs</option>
                    </select>
                  </td>
                  <td className="py-3 px-4 flex gap-1">
                    <button onClick={() => { setSelectedApp(app); setShowViewModal(true); }} className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg">
                      <Eye size={16} />
                    </button>
                    <button onClick={() => deleteApp(app.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-lg">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* View Modal */}
      <Modal isOpen={showViewModal} onClose={() => setShowViewModal(false)} title="Application Details" size="md">
        {selectedApp && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-500">Student Name</p>
                <p className="font-medium text-gray-900">{selectedApp.studentName}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Program</p>
                <p className="font-medium text-gray-900">{selectedApp.program}</p>
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1">Notes</p>
              <textarea
                value={selectedApp.notes}
                onChange={(e) => setSelectedApp({ ...selectedApp, notes: e.target.value })}
                className="w-full p-3 border border-gray-200 rounded-lg min-h-[100px]"
              />
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setShowViewModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
              <button onClick={() => { updateNotes(selectedApp.id, selectedApp.notes); setShowViewModal(false); }} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Save</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
