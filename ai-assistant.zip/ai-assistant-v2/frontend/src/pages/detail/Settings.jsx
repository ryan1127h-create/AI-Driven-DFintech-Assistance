import { useEffect, useState } from "react";
import { getSettingsStatus, saveSettings } from "../../api.js";

export default function Settings() {
  const [status, setStatus] = useState(null);
  const [message, setMessage] = useState("");
  const [ok, setOk] = useState(null);
  const [busy, setBusy] = useState(false);

  async function loadStatus() {
    try {
      const payload = await getSettingsStatus();
      setStatus(payload.status);
    } catch (err) {
      setMessage(err.message || "Unable to read backend settings.");
      setOk(false);
    }
  }

  useEffect(() => { loadStatus(); }, []);

  async function submitForm(form, action) {
    const fd = new FormData(form);
    setBusy(true);
    setMessage("");
    setOk(null);
    try {
      const payload = await saveSettings({
        apiKey: fd.get("api_key") || "",
        model: fd.get("model") || "",
        baseUrl: fd.get("base_url") || "",
        action,
      });
      setStatus(payload.status);
      setMessage(payload.message || "Saved.");
      setOk(payload.ok !== false);
    } catch (err) {
      setMessage(err.message || "Settings update failed.");
      setOk(false);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head reveal"><h1>Credential settings</h1><p>Configure the DeepSeek API key used by the Flask backend. The React browser app never sees the saved key.</p></div>
      <div className="panel reveal">
        <div className="note">Current status: {status?.configured ? <span style={{ color: "var(--ok)" }}>Configured ({status.source}, {status.key_hint})</span> : <span style={{ color: "var(--danger)" }}>Not configured</span>}</div>
        <div className="note" style={{ marginTop: 8 }}>Model: <strong>{status?.model || "deepseek-v4-pro"}</strong></div>
        {message && <div className={`note ${ok ? "note--info" : "note--warn"}`} style={{ marginTop: 12 }}>{message}</div>}
        <form key={status?.model || "default"} onSubmit={(e) => { e.preventDefault(); submitForm(e.currentTarget, "save"); }} style={{ marginTop: 18 }}>
          <label>API Key</label>
          <input name="api_key" type="password" placeholder="sk-... (leave blank to keep current value)" />
          <label>Model</label>
          <input name="model" type="text" defaultValue={status?.model || "deepseek-v4-pro"} />
          <label>Base URL</label>
          <input name="base_url" type="text" placeholder="https://api.deepseek.com" />
          <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
            <button type="submit" className="btn" disabled={busy}>{busy ? "Saving..." : "Save"}</button>
            <button type="button" className="btn btn--ghost" disabled={busy} onClick={(e) => submitForm(e.currentTarget.form, "test")}>Test connection</button>
          </div>
        </form>
        <p className="disc">The key is stored locally by the backend in <code>data/.deepseek.json</code>. Environment variables still take priority in production.</p>
      </div>
    </>
  );
}
