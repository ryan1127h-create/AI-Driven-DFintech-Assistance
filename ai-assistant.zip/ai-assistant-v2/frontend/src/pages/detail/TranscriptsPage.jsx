import { useState } from 'react';
import { Download, FileText, Clock, CheckCircle, Plus, Eye, AlertCircle } from 'lucide-react';
import Modal from '../../components/Modal';

export default function TranscriptsPage() {
  const [transcripts, setTranscripts] = useState([
    { id: 1, type: 'Official Transcript', requestedDate: 'Mar 10, 2024', status: 'completed', sentTo: 'Graduate School', copies: 1 },
    { id: 2, type: 'Unofficial Transcript', requestedDate: 'Feb 15, 2024', status: 'completed', sentTo: 'Self', copies: 1 },
    { id: 3, type: 'Official Transcript', requestedDate: 'Mar 12, 2024', status: 'processing', sentTo: 'Graduate School', copies: 2 },
  ]);

  const [showRequestModal, setShowRequestModal] = useState(false);
  const [newRequest, setNewRequest] = useState({ type: 'official', copies: 1, recipient: '', delivery: 'electronic' });

  // Mock transcript data
  const gpaSummary = {
    cumulative: 3.72,
    totalCredits: 84,
    totalCourses: 28,
    honors: 'Dean\'s List',
  };

  const semesterSummary = [
    { semester: 'Fall 2022', credits: 15, gpa: 3.50, status: 'completed' },
    { semester: 'Spring 2023', credits: 16, gpa: 3.60, status: 'completed' },
    { semester: 'Fall 2023', credits: 18, gpa: 3.80, status: 'completed' },
    { semester: 'Spring 2024', credits: 18, gpa: 3.72, status: 'in_progress' },
  ];

  // CRUD: Request transcript
  const requestTranscript = () => {
    if (newRequest.recipient.trim()) {
      setTranscripts([...transcripts, {
        id: Date.now(),
        type: newRequest.type === 'official' ? 'Official Transcript' : 'Unofficial Transcript',
        requestedDate: new Date().toLocaleDateString(),
        status: 'processing',
        sentTo: newRequest.recipient,
        copies: newRequest.copies,
      }]);
      setNewRequest({ type: 'official', copies: 1, recipient: '', delivery: 'electronic' });
      setShowRequestModal(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Transcripts</h1>
            <p className="text-emerald-100">Request and manage your academic transcripts</p>
          </div>
          <button
            onClick={() => setShowRequestModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white text-emerald-700 rounded-lg hover:bg-emerald-50"
          >
            <Plus size={18} />
            Request Transcript
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{gpaSummary.cumulative.toFixed(2)}</p>
          <p className="text-sm text-gray-500">Cumulative GPA</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{gpaSummary.totalCredits}</p>
          <p className="text-sm text-gray-500">Total Credits</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{gpaSummary.totalCourses}</p>
          <p className="text-sm text-gray-500">Courses Completed</p>
        </div>
        <div className="bg-gradient-to-r from-yellow-100 to-yellow-50 rounded-xl border border-yellow-200 p-4 text-center">
          <p className="text-lg font-bold text-yellow-800">{gpaSummary.honors}</p>
          <p className="text-sm text-yellow-600">Academic Standing</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Academic Summary</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Semester</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Credits</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">GPA</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {semesterSummary.map((sem, idx) => (
                <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{sem.semester}</td>
                  <td className="py-3 px-4 text-gray-600">{sem.credits}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      sem.gpa >= 3.7 ? 'bg-green-100 text-green-700' :
                      sem.gpa >= 3.5 ? 'bg-blue-100 text-blue-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {sem.gpa.toFixed(2)}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`text-sm ${sem.status === 'completed' ? 'text-green-600' : 'text-yellow-600'}`}>
                      {sem.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg">
                      <Eye size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Transcript Requests</h2>
        <div className="space-y-3">
          {transcripts.length === 0 ? (
            <div className="text-center py-8">
              <FileText size={48} className="mx-auto text-gray-300 mb-3" />
              <p className="text-gray-500">No transcript requests yet</p>
            </div>
          ) : (
            transcripts.map((trans) => (
              <div key={trans.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    trans.status === 'completed' ? 'bg-green-100' : 'bg-yellow-100'
                  }`}>
                    {trans.status === 'completed' ? (
                      <CheckCircle size={20} className="text-green-600" />
                    ) : (
                      <Clock size={20} className="text-yellow-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{trans.type}</p>
                    <p className="text-sm text-gray-500">Sent to: {trans.sentTo} • {trans.copies} {trans.copies > 1 ? 'copies' : 'copy'}</p>
                    <p className="text-xs text-gray-400">Requested: {trans.requestedDate}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    trans.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {trans.status}
                  </span>
                  {trans.status === 'completed' && (
                    <button className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg">
                      <Download size={16} />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-700">
            <AlertCircle size={14} className="inline mr-1" />
            Official transcripts take 3-5 business days to process.
          </p>
        </div>
      </div>

      {/* Request Transcript Modal */}
      <Modal
        isOpen={showRequestModal}
        onClose={() => setShowRequestModal(false)}
        title="Request Transcript"
        size="md"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Transcript Type</label>
            <select
              value={newRequest.type}
              onChange={(e) => setNewRequest({ ...newRequest, type: e.target.value })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg"
            >
              <option value="official">Official Transcript</option>
              <option value="unofficial">Unofficial Transcript</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Number of Copies</label>
            <input
              type="number"
              value={newRequest.copies}
              onChange={(e) => setNewRequest({ ...newRequest, copies: parseInt(e.target.value) || 1 })}
              min="1"
              max="5"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Recipient</label>
            <input
              type="text"
              value={newRequest.recipient}
              onChange={(e) => setNewRequest({ ...newRequest, recipient: e.target.value })}
              placeholder="e.g., Graduate School, Employer Name"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Method</label>
            <select
              value={newRequest.delivery}
              onChange={(e) => setNewRequest({ ...newRequest, delivery: e.target.value })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg"
            >
              <option value="electronic">Electronic (PDF)</option>
              <option value="mail">Mail (Paper)</option>
              <option value="pickup">Pick Up</option>
            </select>
          </div>
          <div className="flex justify-end gap-3">
            <button
              onClick={() => setShowRequestModal(false)}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={requestTranscript}
              disabled={!newRequest.recipient.trim()}
              className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50"
            >
              Submit Request
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
