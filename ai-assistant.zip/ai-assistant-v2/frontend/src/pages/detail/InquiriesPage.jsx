import { useState } from 'react';
import { FileText, Plus, Trash2, AlertTriangle, MessageCircle, UserCheck, Search, Filter, Check, Clock } from 'lucide-react';
import Modal from '../../components/Modal';

export default function InquiriesPage() {
  const [inquiries, setInquiries] = useState([
    { id: 1, studentName: 'John Smith', category: 'admissions', status: 'open', priority: 'normal', message: 'What are the admission requirements for CS?', createdAt: '2024-03-10', response: null },
    { id: 2, studentName: 'Sarah Johnson', category: 'application', status: 'escalated', priority: 'high', message: 'My application shows pending but I submitted all documents', createdAt: '2024-03-12', response: null },
    { id: 3, studentName: 'Emily Davis', category: 'registration', status: 'resolved', priority: 'normal', message: 'How do I register for courses?', createdAt: '2024-03-14', response: 'Use the course registration portal to select your classes...' },
    { id: 4, studentName: 'Michael Chen', category: 'financial', status: 'open', priority: 'high', message: 'Scholarship application deadline clarification', createdAt: '2024-03-15', response: null },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showRespondModal, setShowRespondModal] = useState(false);
  const [selectedInquiry, setSelectedInquiry] = useState(null);
  const [response, setResponse] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // CRUD: Add inquiry
  const addInquiry = (inquiry) => {
    setInquiries([{
      id: Date.now(),
      ...inquiry,
      status: 'open',
      createdAt: new Date().toISOString().split('T')[0],
      response: null
    }, ...inquiries]);
  };

  // CRUD: Update status
  const updateStatus = (id, status) => {
    setInquiries(inquiries.map(i => i.id === id ? { ...i, status } : i));
  };

  // CRUD: Respond
  const respondToInquiry = () => {
    if (selectedInquiry && response.trim()) {
      setInquiries(inquiries.map(i =>
        i.id === selectedInquiry.id ? { ...i, status: 'resolved', response: response.trim() } : i
      ));
      setResponse('');
      setShowRespondModal(false);
    }
  };

  // CRUD: Escalate
  const escalateInquiry = (id) => {
    setInquiries(inquiries.map(i => i.id === id ? { ...i, status: 'escalated', priority: 'high' } : i));
  };

  // CRUD: Delete
  const deleteInquiry = (id) => {
    setInquiries(inquiries.filter(i => i.id !== id));
  };

  const filteredInquiries = inquiries.filter(i => {
    const matchesSearch = i.studentName.toLowerCase().includes(searchTerm.toLowerCase()) || i.message.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || i.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (status) => {
    const badges = {
      open: 'bg-blue-100 text-blue-700',
      resolved: 'bg-green-100 text-green-700',
      escalated: 'bg-red-100 text-red-700',
      pending: 'bg-yellow-100 text-yellow-700',
    };
    return badges[status] || badges.open;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Inquiries Management</h1>
            <p className="text-slate-300">Review and respond to student inquiries</p>
          </div>
          <button onClick={() => setShowAddModal(true)} className="px-4 py-2 bg-white text-slate-800 rounded-lg hover:bg-slate-100 flex items-center gap-2">
            <Plus size={18} />
            Add Inquiry
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{inquiries.filter(i => i.status === 'open').length}</p>
          <p className="text-sm text-blue-600">Open</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-yellow-700">{inquiries.filter(i => i.status === 'escalated').length}</p>
          <p className="text-sm text-yellow-600">Escalated</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{inquiries.filter(i => i.status === 'resolved').length}</p>
          <p className="text-sm text-green-600">Resolved</p>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-red-700">{inquiries.filter(i => i.priority === 'high').length}</p>
          <p className="text-sm text-red-600">High Priority</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative flex-1">
            {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
            <input type="text" placeholder="Search inquiries..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
            <option value="all">All Status</option>
            <option value="open">Open</option>
            <option value="escalated">Escalated</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>

        <div className="space-y-3">
          {filteredInquiries.map((inquiry) => (
            <div key={inquiry.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium text-gray-900">{inquiry.studentName}</p>
                    <span className={`px-2 py-0.5 rounded-full text-xs ${inquiry.priority === 'high' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}>
                      {inquiry.priority}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 capitalize">{inquiry.category} • {inquiry.createdAt}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadge(inquiry.status)}`}>
                  {inquiry.status}
                </span>
              </div>
              <p className="text-sm text-gray-700 mb-3">{inquiry.message}</p>
              {inquiry.response && (
                <div className="bg-green-50 border-l-4 border-green-400 p-3 rounded text-sm text-gray-600">
                  <span className="font-medium text-green-700">Response: </span>{inquiry.response}
                </div>
              )}
              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-200">
                <select value={inquiry.status} onChange={(e) => updateStatus(inquiry.id, e.target.value)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border-0 cursor-pointer ${getStatusBadge(inquiry.status)}`}>
                  <option value="open">Open</option>
                  <option value="escalated">Escalated</option>
                  <option value="resolved">Resolved</option>
                </select>
                <button onClick={() => { setSelectedInquiry(inquiry); setResponse(inquiry.response || ''); setShowRespondModal(true); }} className="px-4 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm flex items-center gap-1">
                  <MessageCircle size={14} />
                  Respond
                </button>
                {inquiry.status !== 'escalated' && (
                  <button onClick={() => escalateInquiry(inquiry.id)} className="px-4 py-1.5 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 text-sm flex items-center gap-1">
                    <AlertTriangle size={14} />
                    Escalate
                  </button>
                )}
                <button onClick={() => deleteInquiry(inquiry.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-lg ml-auto">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Respond Modal */}
      <Modal isOpen={showRespondModal} onClose={() => setShowRespondModal(false)} title="Respond to Inquiry" size="md">
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm font-medium text-gray-900">{selectedInquiry?.studentName}</p>
            <p className="text-sm text-gray-600 mt-1">{selectedInquiry?.message}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Your Response</label>
            <textarea value={response} onChange={(e) => setResponse(e.target.value)} placeholder="Type your response..." className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 min-h-[120px]" />
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowRespondModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={respondToInquiry} disabled={!response.trim()} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">Send Response</button>
          </div>
        </div>
      </Modal>

      {/* Add Inquiry Modal */}
      <Modal isOpen={showAddModal} onClose={() => setShowAddModal(false)} title="Log New Inquiry" size="sm">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Student Name</label>
            <input type="text" placeholder="Enter student name" className="w-full px-4 py-2 border rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select className="w-full px-4 py-2 border rounded-lg">
              <option value="admissions">Admissions</option>
              <option value="application">Application</option>
              <option value="financial">Financial</option>
              <option value="registration">Registration</option>
            </select>
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowAddModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={() => setShowAddModal(false)} className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-800">Add Inquiry</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
