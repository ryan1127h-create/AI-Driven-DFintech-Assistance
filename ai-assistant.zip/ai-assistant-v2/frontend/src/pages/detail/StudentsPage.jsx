import { useState } from 'react';
import { Users, Search, Plus, Trash2, Eye, Mail, TrendingUp, Calendar } from 'lucide-react';
import Modal from '../../components/Modal';

export default function StudentsPage() {
  const [students, setStudents] = useState([
    { id: 1, name: 'Emily Davis', email: 'emily.davis@university.edu', role: 'enrolled', progress: 70, year: 'Junior', gpa: 3.72, major: 'Computer Science' },
    { id: 2, name: 'David Wilson', email: 'david.wilson@university.edu', role: 'graduating', progress: 95, year: 'Senior', gpa: 3.45, major: 'Data Science' },
    { id: 3, name: 'Jessica Martinez', email: 'jessica.martinez@university.edu', role: 'alumni', progress: 100, year: '2023', gpa: 3.80, major: 'Business Administration' },
    { id: 4, name: 'Alex Thompson', email: 'alex.thompson@university.edu', role: 'enrolled', progress: 45, year: 'Sophomore', gpa: 3.55, major: 'Engineering' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [newStudent, setNewStudent] = useState({ name: '', email: '', role: 'enrolled', major: '' });

  // CRUD: Add student
  const addStudent = () => {
    if (newStudent.name.trim() && newStudent.email.trim()) {
      setStudents([...students, {
        id: Date.now(),
        ...newStudent,
        progress: 0,
        year: 'Freshman',
        gpa: 0.00
      }]);
      setNewStudent({ name: '', email: '', role: 'enrolled', major: '' });
      setShowAddModal(false);
    }
  };

  // CRUD: Update progress
  const updateProgress = (id, progress) => {
    setStudents(students.map(s => s.id === id ? { ...s, progress: parseInt(progress) || 0 } : s));
  };

  // CRUD: Delete
  const deleteStudent = (id) => {
    setStudents(students.filter(s => s.id !== id));
  };

  const filteredStudents = students.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterRole === 'all' || s.role === filterRole;
    return matchesSearch && matchesFilter;
  });

  const getRoleBadge = (role) => {
    const badges = {
      enrolled: 'bg-blue-100 text-blue-700',
      graduating: 'bg-purple-100 text-purple-700',
      alumni: 'bg-green-100 text-green-700',
    };
    return badges[role] || badges.enrolled;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Student Management</h1>
            <p className="text-slate-300">View and manage student records</p>
          </div>
          <button onClick={() => setShowAddModal(true)} className="px-4 py-2 bg-white text-slate-800 rounded-lg hover:bg-slate-100 flex items-center gap-2">
            <Plus size={18} />
            Add Student
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{students.filter(s => s.role === 'enrolled').length}</p>
          <p className="text-sm text-blue-600">Enrolled</p>
        </div>
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-purple-700">{students.filter(s => s.role === 'graduating').length}</p>
          <p className="text-sm text-purple-600">Graduating</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{students.filter(s => s.role === 'alumni').length}</p>
          <p className="text-sm text-green-600">Alumni</p>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-gray-700">{students.length}</p>
          <p className="text-sm text-gray-600">Total</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative flex-1">
            {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
            <input type="text" placeholder="Search students..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={filterRole} onChange={(e) => setFilterRole(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
            <option value="all">All Roles</option>
            <option value="enrolled">Enrolled</option>
            <option value="graduating">Graduating</option>
            <option value="alumni">Alumni</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Name</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Email</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Role</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Progress</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">GPA</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.map((student) => (
                <tr key={student.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <p className="font-medium text-gray-900">{student.name}</p>
                    <p className="text-xs text-gray-500">{student.major}</p>
                  </td>
                  <td className="py-3 px-4">
                    <a href={`mailto:${student.email}`} className="text-sm text-blue-600 hover:underline">{student.email}</a>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleBadge(student.role)}`}>
                      {student.role}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        value={student.progress}
                        onChange={(e) => updateProgress(student.id, e.target.value)}
                        className="w-16 px-2 py-1 border rounded text-xs"
                        min="0"
                        max="100"
                      />
                      <span className="text-xs text-gray-500">%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-sm text-gray-600">{student.gpa.toFixed(2)}</td>
                  <td className="py-3 px-4 flex gap-1">
                    <button onClick={() => deleteStudent(student.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-lg">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Student Modal */}
      <Modal isOpen={showAddModal} onClose={() => setShowAddModal(false)} title="Add New Student" size="sm">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
            <input type="text" value={newStudent.name} onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })} placeholder="Full name" className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" value={newStudent.email} onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })} placeholder="Email address" className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Major</label>
            <input type="text" value={newStudent.major} onChange={(e) => setNewStudent({ ...newStudent, major: e.target.value })} placeholder="Major" className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
            <select value={newStudent.role} onChange={(e) => setNewStudent({ ...newStudent, role: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg">
              <option value="enrolled">Enrolled</option>
              <option value="graduating">Graduating</option>
              <option value="alumni">Alumni</option>
            </select>
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowAddModal(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={addStudent} disabled={!newStudent.name.trim() || !newStudent.email.trim()} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">Add</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
