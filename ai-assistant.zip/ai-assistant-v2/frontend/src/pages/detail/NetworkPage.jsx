import { useState } from 'react';
import { Users, Search, Plus, Trash2, MessageCircle, UserCheck, Shield, Lock, Eye, EyeOff, AlertCircle, Check, X, Star } from 'lucide-react';
import Modal from '../../components/Modal';

export default function NetworkPage() {
  const [userSettings, setUserSettings] = useState({
    allowNetworking: true,
    allowMessaging: true,
    profileVisible: true,
  });

  const [connections, setConnections] = useState([
    { id: 1, name: 'Alex Turner', company: 'Google', role: 'Senior Engineer', consentGiven: true, connected: true, mentor: true },
    { id: 2, name: 'Maria Garcia', company: 'McKinsey', role: 'Manager', consentGiven: true, connected: true, mentor: false },
  ]);

  const [connectionRequests, setConnectionRequests] = useState([
    { id: 1, senderName: 'James Wilson', senderCompany: 'Netflix', status: 'pending', timestamp: '2 hours ago' },
    { id: 2, senderName: 'Emily Chen', senderCompany: 'Meta', status: 'pending', timestamp: '1 day ago' },
  ]);

  const [alumniNetwork, setAlumniNetwork] = useState([
    { id: 'a1', name: 'Alex Turner', gradYear: 2020, program: 'Computer Science', company: 'Google', role: 'Senior Software Engineer', location: 'San Francisco, CA', mentorshipAvailable: true, consentGiven: true, connected: true },
    { id: 'a2', name: 'Maria Garcia', gradYear: 2019, program: 'Business Administration', company: 'McKinsey & Company', role: 'Engagement Manager', location: 'New York, NY', mentorshipAvailable: true, consentGiven: true, connected: true },
    { id: 'a3', name: 'James Wilson', gradYear: 2018, program: 'Data Science', company: 'Netflix', role: 'Data Scientist', location: 'Los Angeles, CA', mentorshipAvailable: false, consentGiven: true, connected: false },
    { id: 'a4', name: 'Sarah Lee', gradYear: 2021, program: 'Computer Science', company: 'Apple', role: 'iOS Developer', location: 'Cupertino, CA', mentorshipAvailable: true, consentGiven: false, connected: false },
    { id: 'a5', name: 'Michael Brown', gradYear: 2017, program: 'Engineering', company: 'Tesla', role: 'Mechanical Engineer', location: 'Austin, TX', mentorshipAvailable: false, consentGiven: true, connected: false },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProgram, setSelectedProgram] = useState('all');
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showRequestsModal, setShowRequestsModal] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [selectedAlumni, setSelectedAlumni] = useState(null);
  const [newMessage, setNewMessage] = useState('');

  const programs = ['all', ...new Set(alumniNetwork.map(a => a.program))];

  const filteredAlumni = alumniNetwork.filter((alumni) => {
    const matchesSearch = alumni.name.toLowerCase().includes(searchTerm.toLowerCase()) || alumni.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesProgram = selectedProgram === 'all' || alumni.program === selectedProgram;
    return matchesSearch && matchesProgram;
  });

  // CRUD: Request connection
  const requestConnection = (alumniId) => {
    const alumni = alumniNetwork.find(a => a.id === alumniId);
    if (alumni && alumni.consentGiven) {
      alert(`Connection request sent to ${alumni.name}`);
    }
  };

  // CRUD: Accept connection request
  const acceptConnection = (requestId) => {
    const request = connectionRequests.find(r => r.id === requestId);
    if (request) {
      setConnections([...connections, {
        id: Date.now(),
        name: request.senderName,
        company: request.senderCompany,
        role: 'Alumni',
        consentGiven: true,
        connected: true,
        mentor: false
      }]);
      setConnectionRequests(connectionRequests.filter(r => r.id !== requestId));
    }
  };

  // CRUD: Reject connection request
  const rejectConnection = (requestId) => {
    setConnectionRequests(connectionRequests.filter(r => r.id !== requestId));
  };

  // CRUD: Remove connection
  const removeConnection = (connectionId) => {
    setConnections(connections.filter(c => c.id !== connectionId));
  };

  // CRUD: Send message (only if connected)
  const sendMessage = () => {
    if (selectedAlumni && newMessage.trim()) {
      alert(`Message sent to ${selectedAlumni.name}: ${newMessage}`);
      setNewMessage('');
      setShowMessageModal(false);
    }
  };

  const isConnected = (alumniId) => {
    const alumni = alumniNetwork.find(a => a.id === alumniId);
    return connections.some(c => c.name === alumni?.name && c.connected);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Alumni Network</h1>
            <p className="text-orange-100">Connect with fellow graduates</p>
          </div>
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg ${userSettings.allowNetworking ? 'bg-green-500/30' : 'bg-red-500/30'}`}>
              {userSettings.allowNetworking ? <Eye size={16} /> : <EyeOff size={16} />}
              <span className="text-sm">{userSettings.allowNetworking ? 'Discoverable' : 'Hidden'}</span>
            </div>
            <button onClick={() => setShowSettingsModal(true)} className="px-4 py-2 bg-white/20 rounded-lg hover:bg-white/30 text-sm flex items-center gap-2">
              <Shield size={16} />
              Privacy
            </button>
          </div>
        </div>
      </div>

      {connectionRequests.filter(r => r.status === 'pending').length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertCircle size={24} className="text-yellow-600" />
              <div>
                <p className="font-medium text-gray-900">Pending Connection Requests</p>
                <p className="text-sm text-gray-600">{connectionRequests.filter(r => r.status === 'pending').length} request(s) awaiting your approval</p>
              </div>
            </div>
            <button onClick={() => setShowRequestsModal(true)} className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">
              Review
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{connections.filter(c => c.connected).length}</p>
          <p className="text-sm text-blue-600">Connections</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-yellow-700">{connectionRequests.filter(r => r.status === 'pending').length}</p>
          <p className="text-sm text-yellow-600">Pending Requests</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{connections.filter(c => c.mentor).length}</p>
          <p className="text-sm text-green-600">Mentors</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">My Connections</h2>
        </div>
        <div className="space-y-3">
          {connections.filter(c => c.connected).map((connection) => (
            <div key={connection.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white font-bold">
                  {connection.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium text-gray-900">{connection.name}</p>
                  <p className="text-sm text-gray-500">{connection.role} at {connection.company}</p>
                </div>
                {connection.mentor && <Star size={14} className="text-yellow-500" title="Mentor" />}
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => { setSelectedAlumni(connection); setShowMessageModal(true); }} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm flex items-center gap-1">
                  <MessageCircle size={14} />
                  Message
                </button>
                <button onClick={() => removeConnection(connection.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-lg">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Find Alumni</h2>
          <div className="flex items-center gap-2">
            <Shield size={14} className="text-green-500" />
            <span className="text-xs text-green-600">Verified Alumni</span>
          </div>
        </div>
        <div className="flex items-center gap-2 mb-4">
          <div className="relative flex-1">
            {/* <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /> */}
            <input type="text" placeholder="Search by name or company..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={selectedProgram} onChange={(e) => setSelectedProgram(e.target.value)} className="w-48 px-4 py-2 border border-gray-200 rounded-lg text-sm">
            {programs.map((prog) => (
              <option key={prog} value={prog}>{prog === 'all' ? 'All Programs' : prog}</option>
            ))}
          </select>
        </div>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {filteredAlumni.map((alumni) => {
            const connected = isConnected(alumni.id);
            return (
              <div key={alumni.id} className={`p-4 rounded-lg border ${!alumni.consentGiven ? 'bg-gray-100 border-gray-200' : 'bg-white border-gray-200'}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white font-bold">
                      {alumni.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-gray-900">{alumni.name}</p>
                        {!alumni.consentGiven && <Lock size={12} className="text-gray-400" title="Privacy restricted" />}
                      </div>
                      <p className="text-xs text-gray-500">{alumni.role} at {alumni.company}</p>
                      <p className="text-xs text-gray-400">Class of {alumni.gradYear} • {alumni.program}</p>
                    </div>
                  </div>
                  {alumni.mentorshipAvailable && <span className="flex items-center gap-1 text-xs text-green-600 font-medium"><Star size={12} /> Mentor</span>}
                </div>
                <div className="flex gap-2 mt-3">
                  {alumni.consentGiven ? (
                    connected ? (
                      <button onClick={() => { setSelectedAlumni(alumni); setShowMessageModal(true); }} className="flex-1 py-1.5 rounded text-sm font-medium bg-blue-600 text-white hover:bg-blue-700 flex items-center justify-center gap-1">
                        <MessageCircle size={14} />
                        Message
                      </button>
                    ) : (
                      <button onClick={() => requestConnection(alumni.id)} className="flex-1 py-1.5 rounded text-sm font-medium bg-gray-100 text-gray-700 hover:bg-gray-200">
                        Connect
                      </button>
                    )
                  ) : (
                    <span className="text-xs text-gray-400 py-1.5 px-3 bg-gray-100 rounded">
                      <Lock size={12} className="inline mr-1" />
                      Consent Required
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Settings Modal */}
      <Modal isOpen={showSettingsModal} onClose={() => setShowSettingsModal(false)} title="Privacy & Consent Settings" size="md">
        <div className="space-y-4">
          {[
            { key: 'allowNetworking', label: 'Allow Networking', desc: 'Let other alumni find you in searches' },
            { key: 'allowMessaging', label: 'Allow Messaging', desc: 'Let connections send you messages' },
            { key: 'profileVisible', label: 'Profile Visible', desc: 'Show your profile publicly' },
          ].map((setting) => (
            <div key={setting.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">{setting.label}</p>
                <p className="text-sm text-gray-500">{setting.desc}</p>
              </div>
              <button onClick={() => setUserSettings({ ...userSettings, [setting.key]: !userSettings[setting.key] })} className={`w-12 h-6 rounded-full transition-colors ${userSettings[setting.key] ? 'bg-green-500' : 'bg-gray-300'}`}>
                <div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${userSettings[setting.key] ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>
          ))}
          <div className="flex justify-end">
            <button onClick={() => setShowSettingsModal(false)} className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700">Save Settings</button>
          </div>
        </div>
      </Modal>

      {/* Connection Requests Modal */}
      <Modal isOpen={showRequestsModal} onClose={() => setShowRequestsModal(false)} title="Connection Requests" size="md">
        <div className="space-y-4">
          {connectionRequests.filter(r => r.status === 'pending').length === 0 ? (
            <p className="text-center text-gray-500 py-8">No pending requests</p>
          ) : (
            connectionRequests.filter(r => r.status === 'pending').map((request) => (
              <div key={request.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{request.senderName}</p>
                  <p className="text-sm text-gray-500">{request.senderCompany}</p>
                  <p className="text-xs text-gray-400">{request.timestamp}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => acceptConnection(request.id)} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"><Check size={16} className="inline mr-1" /> Accept</button>
                  <button onClick={() => rejectConnection(request.id)} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"><X size={16} className="inline mr-1" /> Reject</button>
                </div>
              </div>
            ))
          )}
        </div>
      </Modal>

      {/* Message Modal */}
      <Modal isOpen={showMessageModal} onClose={() => { setShowMessageModal(false); setNewMessage(''); }} title={`Message ${selectedAlumni?.name || 'Alumni'}`} size="md">
        <div className="space-y-4">
          <textarea value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type your message..." className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 min-h-[120px]" />
          <div className="flex justify-end gap-3">
            <button onClick={() => { setShowMessageModal(false); setNewMessage(''); }} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onClick={sendMessage} disabled={!newMessage.trim()} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">Send Message</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
