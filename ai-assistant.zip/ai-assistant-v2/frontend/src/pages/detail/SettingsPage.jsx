import { useState } from 'react';
import { Settings as SettingsIcon, User, Bell, Shield, Database, Mail, Globe, Save } from 'lucide-react';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    siteName: 'Student Lifecycle Assistant',
    adminEmail: 'admin@university.edu',
    supportEmail: 'support@university.edu',
    autoReply: true,
    notifications: { email: true, sms: false, push: true },
    security: { twoFactor: true, sessionTimeout: 30, passwordExpiry: 90 },
    maintenance: { mode: false, message: 'System is under maintenance' },
  });

  const updateSetting = (path, value) => {
    setSettings(prev => {
      const newSettings = { ...prev };
      const keys = path.split('.');
      let current = newSettings;
      for (let i = 0; i < keys.length - 1; i++) {
        current = current[keys[i]];
      }
      current[keys[keys.length - 1]] = value;
      return newSettings;
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <SettingsIcon size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold">System Settings</h1>
            <p className="text-slate-300">Configure system preferences and options</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2"><Globe size={20} className="text-blue-600" />General Settings</h2>
          <div className="space-y-4">
            <div><label className="block text-sm font-medium text-gray-700 mb-1">Site Name</label><input type="text" value={settings.siteName} onChange={(e) => updateSetting('siteName', e.target.value)} className="w-full px-4 py-2 border rounded-lg" /></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-1">Admin Email</label><input type="email" value={settings.adminEmail} onChange={(e) => updateSetting('adminEmail', e.target.value)} className="w-full px-4 py-2 border rounded-lg" /></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-1">Support Email</label><input type="email" value={settings.supportEmail} onChange={(e) => updateSetting('supportEmail', e.target.value)} className="w-full px-4 py-2 border rounded-lg" /></div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"><div><p className="font-medium text-gray-900">Auto-Reply</p><p className="text-sm text-gray-500">Automatically reply to inquiries</p></div><button onClick={() => updateSetting('autoReply', !settings.autoReply)} className={`w-12 h-6 rounded-full transition-colors ${settings.autoReply ? 'bg-green-500' : 'bg-gray-300'}`}><div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${settings.autoReply ? 'translate-x-6' : 'translate-x-0.5'}`} /></button></div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2"><Bell size={20} className="text-yellow-600" />Notifications</h2>
          <div className="space-y-3">
            {Object.entries(settings.notifications).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div><p className="font-medium text-gray-900 capitalize">{key} Notifications</p><p className="text-sm text-gray-500">Receive {key} alerts</p></div>
                <button onClick={() => updateSetting(`notifications.${key}`, !value)} className={`w-12 h-6 rounded-full transition-colors ${value ? 'bg-green-500' : 'bg-gray-300'}`}><div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${value ? 'translate-x-6' : 'translate-x-0.5'}`} /></button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2"><Shield size={20} className="text-red-600" />Security Settings</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div><p className="font-medium text-gray-900">Two-Factor Authentication</p><p className="text-sm text-gray-500">Require 2FA for admin accounts</p></div>
              <button onClick={() => updateSetting('security.twoFactor', !settings.security.twoFactor)} className={`w-12 h-6 rounded-full transition-colors ${settings.security.twoFactor ? 'bg-green-500' : 'bg-gray-300'}`}><div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${settings.security.twoFactor ? 'translate-x-6' : 'translate-x-0.5'}`} /></button>
            </div>
            <div><label className="block text-sm font-medium text-gray-700 mb-1">Session Timeout (minutes)</label><input type="number" value={settings.security.sessionTimeout} onChange={(e) => updateSetting('security.sessionTimeout', parseInt(e.target.value))} className="w-full px-4 py-2 border rounded-lg" /></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-1">Password Expiry (days)</label><input type="number" value={settings.security.passwordExpiry} onChange={(e) => updateSetting('security.passwordExpiry', parseInt(e.target.value))} className="w-full px-4 py-2 border rounded-lg" /></div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2"><Database size={20} className="text-purple-600" />Maintenance Mode</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div><p className="font-medium text-gray-900">Enable Maintenance Mode</p><p className="text-sm text-gray-500">Temporarily disable access</p></div>
              <button onClick={() => updateSetting('maintenance.mode', !settings.maintenance.mode)} className={`w-12 h-6 rounded-full transition-colors ${settings.maintenance.mode ? 'bg-red-500' : 'bg-gray-300'}`}><div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${settings.maintenance.mode ? 'translate-x-6' : 'translate-x-0.5'}`} /></button>
            </div>
            <div><label className="block text-sm font-medium text-gray-700 mb-1">Maintenance Message</label><textarea value={settings.maintenance.message} onChange={(e) => updateSetting('maintenance.message', e.target.value)} className="w-full px-4 py-2 border rounded-lg min-h-[80px]" /></div>
          </div>
        </div>
      </div>

      <div className="flex justify-end"><button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"><Save size={18} />Save Settings</button></div>
    </div>
  );
}
