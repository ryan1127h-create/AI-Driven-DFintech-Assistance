import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import KPICard from '../components/KPICard.jsx';
import { GraduationCap, FileText, Briefcase, Users, Lock, Shield, Award, Download, ArrowRight, CheckCircle, Clock, TrendingUp } from 'lucide-react';

export default function GraduatingStudentDashboard() {
  const { currentUser } = useAuth();

  const stats = {
    daysRemaining: 47,
    expectedDate: 'May 15, 2024',
    requirementsComplete: 4,
    totalRequirements: 6,
    applications: 12,
    interviews: 3,
    offers: 1,
  };

  const requirements = [
    { id: 1, title: 'Complete 120 credit hours', completed: true },
    { id: 2, title: 'Maintain minimum 2.0 GPA', completed: true },
    { id: 3, title: 'Clear all financial holds', completed: false },
    { id: 4, title: 'Complete exit survey', completed: false },
  ];

  const recentApplications = [
    { id: 1, company: 'Tech Innovations Inc', role: 'Software Engineer', status: 'interview' },
    { id: 2, company: 'Data Driven Corp', role: 'Data Analyst', status: 'applied' },
    { id: 3, company: 'Cloud Solutions LLC', role: 'Cloud Engineer', status: 'offer' },
  ];

  const getStatusBadge = (status) => {
    const badges = {
      applied: 'bg-blue-100 text-blue-700',
      interview: 'bg-yellow-100 text-yellow-700',
      offer: 'bg-green-100 text-green-700',
      rejected: 'bg-red-100 text-red-700',
    };
    return badges[status] || badges.applied;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <GraduationCap size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-1">Graduation Countdown</h1>
            <p className="text-emerald-100 text-lg">
              {stats.daysRemaining} days until graduation on {stats.expectedDate}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Career Applications" value={stats.applications} subtitle="total submitted" icon={FileText} color="blue" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'career' }))} />
        <KPICard title="Interviews Scheduled" value={stats.interviews} subtitle="upcoming" icon={Briefcase} color="green" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'career' }))} />
        <KPICard title="Job Offers" value={stats.offers} subtitle="pending review" icon={Award} color="purple" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'career' }))} />
        <KPICard title="Days to Graduation" value={stats.daysRemaining} subtitle={stats.expectedDate} icon={Clock} color="yellow" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'graduation' }))} />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold text-gray-900">Graduation Requirements</h2>
            <Shield size={16} className="text-green-500" />
          </div>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'graduation' }))}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
          >
            View all <ArrowRight size={14} />
          </button>
        </div>
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Progress</span>
            <span className="text-sm font-medium">{stats.requirementsComplete}/{stats.totalRequirements} completed</span>
          </div>
          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-green-500 to-emerald-600 rounded-full" style={{ width: `${(stats.requirementsComplete / stats.totalRequirements) * 100}%` }} />
          </div>
        </div>
        <div className="space-y-3">
          {requirements.map((req) => (
            <div key={req.id} className={`flex items-center gap-3 p-3 rounded-lg ${req.completed ? 'bg-green-50' : 'bg-gray-50'}`}>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${req.completed ? 'bg-green-500' : 'bg-gray-300'}`}>
                {req.completed && <CheckCircle size={14} className="text-white" />}
              </div>
              <span className={`font-medium ${req.completed ? 'text-green-900' : 'text-gray-700'}`}>
                {req.title}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Job Applications</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'career' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {recentApplications.map((app) => (
              <div key={app.id} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-gray-900">{app.role}</p>
                    <p className="text-sm text-gray-600">{app.company}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(app.status)}`}>
                    {app.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Documents</h2>
            <Lock size={16} className="text-gray-400" />
          </div>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
              <span className="font-medium text-gray-900">Official Transcript</span>
              <Download size={18} className="text-gray-500" />
            </button>
            <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
              <span className="font-medium text-gray-900">Degree Verification</span>
              <Download size={18} className="text-gray-500" />
            </button>
            <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
              <span className="font-medium text-gray-900">Enrollment Certificate</span>
              <Download size={18} className="text-gray-500" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'graduation' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <CheckCircle size={24} className="text-green-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Complete Requirements</h3>
          <p className="text-sm text-gray-500">Finish remaining graduation tasks</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'career' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <Briefcase size={24} className="text-blue-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Career Services</h3>
          <p className="text-sm text-gray-500">Explore job opportunities</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'alumni-preview' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <Users size={24} className="text-purple-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Alumni Preview</h3>
          <p className="text-sm text-gray-500">See what awaits after graduation</p>
        </button>
      </div>
    </div>
  );
}
