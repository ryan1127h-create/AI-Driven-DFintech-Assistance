import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import KPICard from '../components/KPICard.jsx';
import { Users, Calendar, Briefcase, Heart, Shield, ArrowRight, MessageCircle, Star, Eye, UserCheck } from 'lucide-react';

export default function AlumniDashboard() {
  const { currentUser } = useAuth();

  const stats = {
    totalConnections: 145,
    pendingRequests: 3,
    eventsAttended: 8,
    mentorshipHours: 32,
    donations: '$500',
  };

  const upcomingEvents = [
    { id: 1, title: 'Annual Alumni Gala', date: 'April 15, 2024', type: 'networking' },
    { id: 2, title: 'Tech Industry Panel', date: 'April 22, 2024', type: 'career' },
  ];

  const featuredAlumni = [
    { id: 1, name: 'Alex Turner', company: 'Google', role: 'Senior Engineer' },
    { id: 2, name: 'Maria Garcia', company: 'McKinsey', role: 'Manager' },
  ];

  const mentorshipRequests = 2;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome Back, Alumni!</h1>
            <p className="text-orange-100 text-lg">Connect, mentor, and grow with your alma mater community.</p>
          </div>
          <div className="flex items-center gap-2 bg-white/20 px-3 py-1.5 rounded-lg">
            <Shield size={16} />
            <span className="text-sm">Verified Alumni</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Connections" value={stats.totalConnections} subtitle="in your network" icon={Users} color="blue" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'network' }))} />
        <KPICard title="Pending Requests" value={stats.pendingRequests} subtitle="awaiting response" icon={UserCheck} color="yellow" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'network' }))} />
        <KPICard title="Events Attended" value={stats.eventsAttended} subtitle="in 2024" icon={Calendar} color="purple" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'events' }))} />
        <KPICard title="Mentorship Hours" value={stats.mentorshipHours} subtitle="this year" icon={MessageCircle} color="green" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'mentoring' }))} />
      </div>

      {stats.pendingRequests > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <UserCheck size={24} className="text-yellow-600" />
              <div>
                <p className="font-medium text-gray-900">You have pending connection requests</p>
                <p className="text-sm text-gray-600">{stats.pendingRequests} request(s) waiting for your approval</p>
              </div>
            </div>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'network' }))}
              className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700"
            >
              Review Requests
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Upcoming Events</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'events' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Calendar size={18} className="text-orange-600" />
                  <div>
                    <p className="font-medium text-gray-900">{event.title}</p>
                    <p className="text-sm text-gray-500">{event.date}</p>
                  </div>
                  <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                    {event.type}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Featured Alumni</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'network' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {featuredAlumni.map((alumni) => (
              <div key={alumni.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white font-bold">
                  {alumni.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{alumni.name}</p>
                  <p className="text-sm text-gray-500">{alumni.role} at {alumni.company}</p>
                </div>
                <Shield size={14} className="text-green-500" />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'network' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <Users size={24} className="text-blue-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Alumni Network</h3>
          <p className="text-sm text-gray-500">Find and connect with fellow alumni</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'mentoring' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <Star size={24} className="text-purple-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Mentorship</h3>
          <p className="text-sm text-gray-500">{mentorshipRequests > 0 ? `${mentorshipRequests} pending requests` : 'Become a mentor'}</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'events' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <Calendar size={24} className="text-green-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Events</h3>
          <p className="text-sm text-gray-500">Join alumni gatherings and panels</p>
        </button>
      </div>

      <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Heart size={24} className="text-indigo-600" />
            <div>
              <h3 className="font-semibold text-gray-900">Support Future Students</h3>
              <p className="text-sm text-gray-600">Your contribution this year: {stats.donations}</p>
            </div>
          </div>
          <button className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-medium">
            Make a Donation
          </button>
        </div>
      </div>
    </div>
  );
}
