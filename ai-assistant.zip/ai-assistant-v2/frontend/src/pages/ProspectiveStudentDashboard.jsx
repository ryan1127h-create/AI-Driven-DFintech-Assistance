import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import KPICard from '../components/KPICard.jsx';
import { BookOpen, Calendar, Users, HelpCircle, Shield, ArrowRight, Bookmark, Clock } from 'lucide-react';
import { usePrograms } from "../context/ProgramsContext.jsx";

export default function ProspectiveStudentDashboard() {
  const { currentUser } = useAuth();
  const [savedCount] = useState(0);
  const { programs = [] } = usePrograms();

  const featuredPrograms = programs.slice(0, 3);

  const stats = {
    programs: programs.length,
    events: 12,
    tours: 3,
    scholarships: '$0',
    deadlines: 2,
    inquiries: 5,
  };

  const upcomingEvents = [
    { id: 1, title: 'Virtual Campus Tour', date: 'March 20, 2024', time: '2:00 PM EST' },
    { id: 2, title: 'Information Session', date: 'March 25, 2024', time: '3:00 PM EST' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome to Your Future</h1>
        <p className="text-blue-100 text-lg">
          Explore our programs and take the first step toward your academic journey.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Available Programs" value={stats.programs} subtitle="across 8 schools" icon={BookOpen} color="blue" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'programs' }))} />
        <KPICard title="Upcoming Events" value={stats.events} subtitle="this month" icon={Calendar} color="green" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'events' }))} />
        <KPICard title="Saved Programs" value={savedCount} subtitle="in your list" icon={Bookmark} color="purple" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'programs' }))} />
        <KPICard title="Scholarships" value={stats.scholarships} subtitle="available in aid" icon={HelpCircle} color="yellow" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Featured Programs</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'programs' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {featuredPrograms?.map((program) => (
              <div key={program.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'programs' }))}>
                <div className="flex items-center gap-3">
                  <BookOpen size={18} className="text-blue-600" />
                  <span className="font-medium text-gray-900">{program.name}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Clock size={14} />
                  <span>Deadline: {program.deadline}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Upcoming Events</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'events' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Calendar size={18} className="text-green-600" />
                  <div>
                    <p className="font-medium text-gray-900">{event.title}</p>
                    <p className="text-sm text-gray-500">{event.date} at {event.time}</p>
                  </div>
                </div>
                <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">
                  Register
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'programs' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <BookOpen size={24} className="text-blue-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Browse Programs</h3>
          <p className="text-sm text-gray-500">Explore 50+ programs and save your favorites</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'inquiry' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <HelpCircle size={24} className="text-green-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">FAQ</h3>
          <p className="text-sm text-gray-500">Get answers from our FAQ</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'events' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <Users size={24} className="text-purple-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Campus Tours</h3>
          <p className="text-sm text-gray-500">Schedule virtual or in-person visits</p>
        </button>
      </div>
    </div>
  );
}
