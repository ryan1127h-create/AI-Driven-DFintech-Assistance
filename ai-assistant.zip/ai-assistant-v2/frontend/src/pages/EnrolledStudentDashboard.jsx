import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import KPICard from '../components/KPICard.jsx';
import { BookOpen, BarChart3, CreditCard, Clock, Lock, ArrowRight, TrendingUp, Calendar } from 'lucide-react';

export default function EnrolledStudentDashboard() {
  const { currentUser } = useAuth();

  const stats = {
    totalCredits: 84,
    requiredCredits: 120,
    currentGPA: 3.72,
    semester: 'Spring 2024',
    coursesEnrolled: 5,
    creditHours: 15,
    year: 'Junior',
  };

  const currentCourses = [
    { id: 1, code: 'CS101', name: 'Introduction to Programming', grade: 'A-' },
    { id: 2, code: 'CS201', name: 'Data Structures', grade: 'B+' },
    { id: 3, code: 'CS301', name: 'Database Systems', grade: 'A' },
  ];

  const upcomingAssignments = [
    { id: 1, title: 'Database Design Project', due: 'Mar 20, 2024', course: 'CS301' },
    { id: 2, title: 'Algorithm Analysis', due: 'Mar 22, 2024', course: 'CS201' },
  ];

  const progressPercentage = (stats.totalCredits / stats.requiredCredits) * 100;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Academic Dashboard</h1>
            <p className="text-indigo-100 text-lg">{stats.semester} • {stats.year} Year</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-indigo-200">Current GPA</p>
            <p className="text-4xl font-bold">{stats.currentGPA}</p>
            <p className="text-sm text-indigo-200 mt-1">Good Standing</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Credits Completed" value={`${stats.totalCredits}/${stats.requiredCredits}`} subtitle={`${Math.round(progressPercentage)}% complete`} icon={CreditCard} color="blue" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'progress' }))} />
        <KPICard title="Current Semester" value={stats.creditHours} subtitle="credit hours" icon={BookOpen} color="green" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'courses' }))} />
        <KPICard title="Courses Enrolled" value={stats.coursesEnrolled} subtitle="this semester" icon={BookOpen} color="purple" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'courses' }))} />
        <KPICard title="Cumulative GPA" value={stats.currentGPA} subtitle="Good Standing" icon={TrendingUp} color="yellow" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'progress' }))} />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Degree Progress</h2>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'progress' }))}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
          >
            View details <ArrowRight size={14} />
          </button>
        </div>
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">Overall Progress</span>
            <span className="font-medium">{stats.totalCredits}/{stats.requiredCredits} credits</span>
          </div>
          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full" style={{ width: `${progressPercentage}%` }} />
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Core Requirements', value: 85 },
            { label: 'Major Courses', value: 72 },
            { label: 'Electives', value: 45 },
            { label: 'General Education', value: 90 },
          ].map((item) => (
            <div key={item.label} className="text-center p-3 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-gray-900">{item.value}%</p>
              <p className="text-xs text-gray-500">{item.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Current Courses</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'courses' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {currentCourses.map((course) => (
              <div key={course.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-sm">
                    {course.code}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{course.name}</p>
                    <p className="text-sm text-gray-500">Current Grade: {course.grade}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'courses' }))}
            className="w-full mt-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium"
          >
            Plan Next Semester
          </button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Upcoming Assignments</h2>
          </div>
          <div className="space-y-3">
            {upcomingAssignments.map((assignment) => (
              <div key={assignment.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Calendar size={18} className="text-orange-600" />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{assignment.title}</p>
                  <p className="text-sm text-gray-500">{assignment.course} • Due: {assignment.due}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-green-50 rounded-lg text-center">
            <p className="text-sm text-green-700">All assignments on track</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'courses' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <BookOpen size={24} className="text-blue-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Course Planning</h3>
          <p className="text-sm text-gray-500">Register for next semester courses</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'progress' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <TrendingUp size={24} className="text-green-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Academic Progress</h3>
          <p className="text-sm text-gray-500">Track your degree completion</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'financial' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <CreditCard size={24} className="text-purple-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Financial Aid</h3>
          <p className="text-sm text-gray-500">Review your financial aid status</p>
        </button>
      </div>
    </div>
  );
}
