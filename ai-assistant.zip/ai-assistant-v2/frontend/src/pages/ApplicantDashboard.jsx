import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import KPICard from '../components/KPICard.jsx';
import Timeline from '../components/Timeline.jsx';
import { FileText, Clock, CheckCircle, AlertTriangle, Lock, ArrowRight, Calendar, Upload } from 'lucide-react';

export default function ApplicantDashboard() {
  const { currentUser } = useAuth();

  const stats = {
    documentsComplete: 75,
    tasksComplete: 80,
    daysSinceSubmission: 24,
    pendingActions: 1,
  };

  const timelineEvents = [
    { title: 'Application Submitted', description: 'Your application has been received', status: 'completed', date: 'Feb 20, 2024' },
    { title: 'Documents Under Review', description: 'Admissions team is reviewing your documents', status: 'active', date: 'In Progress', action: 'Track Progress' },
    { title: 'Interview', description: 'Schedule your interview with admissions', status: 'pending', date: 'TBD' },
    { title: 'Decision', description: 'Admission decision will be communicated', status: 'pending', date: 'Apr 15, 2024' },
  ];

  const recentDocuments = [
    { id: 1, name: 'Personal Statement', status: 'received' },
    { id: 2, name: 'Recommendation Letters', status: 'pending' },
    { id: 3, name: 'Official Transcripts', status: 'received' },
  ];

  const getDocStatusColor = (status) => {
    if (status === 'received') return 'bg-green-100 text-green-700';
    if (status === 'pending') return 'bg-yellow-100 text-yellow-700';
    return 'bg-gray-100 text-gray-600';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Application Tracker</h1>
            <p className="text-blue-100 text-lg">Track your application progress</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-200">Expected Decision</p>
            <p className="text-2xl font-bold">Apr 15, 2024</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Application Status" value="Under Review" icon={FileText} color="blue" />
        <KPICard title="Days Since Submission" value={stats.daysSinceSubmission} subtitle="of 55 avg" icon={Clock} color="green" />
        <KPICard title="Documents Complete" value={`${stats.documentsComplete}%`} icon={CheckCircle} color="yellow" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'documents' }))} />
        <KPICard title="Action Required" value={stats.pendingActions} subtitle="upload document" icon={AlertTriangle} color="red" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'documents' }))} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Application Timeline</h2>
          <Timeline events={timelineEvents} />
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Documents</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'documents' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {recentDocuments.map((doc) => (
              <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <FileText size={18} className="text-gray-400" />
                  <span className="font-medium text-gray-900">{doc.name}</span>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDocStatusColor(doc.status)}`}>
                  {doc.status}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-2">
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'documents' }))}
              className="flex-1 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium"
            >
              Upload Document
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold text-gray-900">Tasks & Checklist</h2>
            <Lock size={16} className="text-gray-400" />
          </div>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'tasks' }))}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
          >
            View all <ArrowRight size={14} />
          </button>
        </div>
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">Progress</span>
            <span className="font-medium">{stats.tasksComplete}%</span>
          </div>
          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-500 to-green-500 rounded-full" style={{ width: `${stats.tasksComplete}%` }} />
          </div>
        </div>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'tasks' }))}
          className="w-full py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 text-sm font-medium"
        >
          Complete Remaining Tasks
        </button>
      </div>
    </div>
  );
}
