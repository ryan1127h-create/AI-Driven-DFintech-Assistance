import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import KPICard from '../components/KPICard.jsx';
import { HorizontalTimeline } from '../components/Timeline.jsx';
import { Calendar, MapPin, CreditCard, Users, BookOpen, Shield, Gift, ArrowRight, CheckCircle, Clock } from 'lucide-react';

export default function AdmittedStudentDashboard() {
  const { currentUser } = useAuth();

  const stats = {
    financialAid: '$25,000',
    orientationDate: 'Aug 20',
    housingDeadline: 'Jun 1',
    advisor: 'Dr. Smith',
    stepsComplete: 2,
    totalSteps: 6,
  };

  const enrollmentSteps = ['Accept Offer', 'Pay Deposit', 'Complete Forms', 'Housing', 'Orientation', 'Register'];
  const currentStep = stats.stepsComplete;

  const upcomingDeadlines = [
    { id: 1, title: 'Housing Application', date: 'June 1, 2024', completed: false },
    { id: 2, title: 'Health Forms', date: 'June 15, 2024', completed: false },
    { id: 3, title: 'Orientation', date: 'August 20-22', completed: false },
  ];

  const orientationSessions = [
    { id: 1, title: 'Welcome Session', date: 'August 20, 2024' },
    { id: 2, title: 'Academic Advising', date: 'August 20, 2024' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <Gift size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Congratulations!</h1>
            <p className="text-green-100 text-lg">You've been admitted to the Data Science program</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-white/80 text-sm">
          <Shield size={16} />
          <span>Verified admission offer - Official policy</span>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Enrollment Progress</h2>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'enrollment' }))}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
          >
            View details <ArrowRight size={14} />
          </button>
        </div>
        <HorizontalTimeline steps={enrollmentSteps} currentStep={currentStep} />
        <div className="mt-4 flex items-center gap-4">
          <div className="flex-1">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-600">Steps Completed</span>
              <span className="font-medium">{stats.stepsComplete}/{stats.totalSteps}</span>
            </div>
            <div className="w-full h-2 bg-gray-200 rounded-full">
              <div className="h-full bg-green-500 rounded-full" style={{ width: `${(stats.stepsComplete / stats.totalSteps) * 100}%` }} />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Financial Aid Awarded" value={stats.financialAid} icon={CreditCard} color="green" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'financial' }))} />
        <KPICard title="Orientation Date" value={stats.orientationDate} subtitle="3-day session" icon={Calendar} color="blue" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'orientation' }))} />
        <KPICard title="Housing Deadline" value={stats.housingDeadline} subtitle="30 days left" icon={MapPin} color="yellow" onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'housing' }))} />
        <KPICard title="Advisor Assigned" value={stats.advisor} subtitle="Computer Science" icon={Users} color="purple" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Upcoming Deadlines</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'enrollment' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {upcomingDeadlines.map((deadline) => (
              <div key={deadline.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Clock size={18} className="text-yellow-600" />
                  <span className="font-medium text-gray-900">{deadline.title}</span>
                </div>
                <span className="text-sm text-gray-500">{deadline.date}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Orientation Schedule</h2>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'orientation' }))}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {orientationSessions.map((session) => (
              <div key={session.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <BookOpen size={18} className="text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">{session.title}</p>
                  <p className="text-sm text-gray-500">{session.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'enrollment' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <CheckCircle size={24} className="text-green-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Complete Enrollment</h3>
          <p className="text-sm text-gray-500">Finish remaining enrollment steps</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'housing' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <MapPin size={24} className="text-yellow-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Apply for Housing</h3>
          <p className="text-sm text-gray-500">Choose your residence hall</p>
        </button>
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'financial' }))}
          className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-left"
        >
          <CreditCard size={24} className="text-blue-600 mb-3" />
          <h3 className="font-semibold text-gray-900 mb-1">Financial Aid</h3>
          <p className="text-sm text-gray-500">Review and accept your aid package</p>
        </button>
      </div>
    </div>
  );
}
