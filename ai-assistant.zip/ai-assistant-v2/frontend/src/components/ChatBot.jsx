import { useState, useRef, useEffect } from 'react';
import { useChat } from '../context/ChatContext.jsx';
import { useAuth } from '../hooks/useTheme.jsx';
import { roleBasedSuggestions } from '../data/mockData.js';
import {
  MessageCircle, X, Send, Minimize2, Maximize2, Bot, User, Sparkles, Loader2,
  Shield, BookOpen, AlertCircle, TrendingUp, Users, GraduationCap, Briefcase
} from 'lucide-react';
import { sendMessage as sendToAPI } from "../api";
import ReactMarkdown from 'react-markdown';


// Agent definitions
const agents = {
  admissions: { name: "Admissions Agent", color: "blue", icon: Shield, description: "Handles admission requirements and process" },
  academic: { name: "Academic Advisor", color: "green", icon: BookOpen, description: "Provides academic guidance" },
  financial: { name: "Finance Assistant", color: "yellow", icon: TrendingUp, description: "Assists with financial matters" },
  assessment: { name: "Profile Evaluator", color: "purple", icon: AlertCircle, description: "Evaluates student profiles" },
  supervisor: { name: "General Assistant", color: "gray", icon: Shield, description: "Provides general assistance" },
};

const generateLoadingReasoning = () => {
  return [
    { step: 1, text: "Understanding your question...", time: 1 },
    { step: 2, text: "Detecting intent...", time: 2 },
    { step: 3, text: "Routing to best agent...", time: 3 },
    { step: 4, text: "Generating response...", time: 4 },
  ];
};

const linkifyContent = (text) => {
  if (!text) return "";

  // Convert URLs first
  let formattedText = text.replace(
    /(https?:\/\/[^\s]+)/g,
    (url) => `[${url}](${url})`
  );

  // Convert emails
  formattedText = formattedText.replace(
    /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/g,
    (email) => `[${email}](mailto:${email})`
  );

  return formattedText;
};

const shouldEscalate = ({ message, confidence, intent }) => {
  const text = message.toLowerCase();

  const emotionalKeywords = ["angry", "frustrated", "complaint", "unhappy", "bad", "appeal"];
  const sensitiveKeywords = ["refund", "legal", "complaint", "appeal"];

  const isEmotional = emotionalKeywords.some(k => text.includes(k));
  const isSensitive = sensitiveKeywords.some(k => text.includes(k));
  const isLowConfidence = confidence < 70;
  const isUnknownIntent = !intent || intent === "unknown";

  return isEmotional || isSensitive || isLowConfidence || isUnknownIntent;
};

export default function ChatBot() {
  const { messages, isOpen, isTyping, unreadCount, toggleChat, closeChat, sendMessage: originalSendMessage } = useChat();
  const { currentUser } = useAuth();
  const [inputValue, setInputValue] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [currentAgent, setCurrentAgent] = useState(null);
  const [currentIntent, setCurrentIntent] = useState(null);
  const [reasoning, setReasoning] = useState([]);
  const [confidence, setConfidence] = useState(null);
  const [showReasoning, setShowReasoning] = useState(false);
  const [enhancedMessages, setEnhancedMessages] = useState([]);
  const messagesEndRef = useRef(null);
  const [isEscalated, setIsEscalated] = useState(false);

  const suggestions = currentUser ? roleBasedSuggestions[currentUser.role] || [] : [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [enhancedMessages]);

  const handleSend = () => {
    if (inputValue.trim()) {
      const userMessage = {
        id: `msg-${Date.now()}`,
        role: 'user',
        content: inputValue.trim(),
        timestamp: new Date().toISOString(),
      };

      setEnhancedMessages(prev => [...prev, userMessage]);
      setInputValue('');
      setCurrentAgent(null);
      setReasoning([]);

      // Simulate agent processing            
      setCurrentAgent(null);
      setCurrentIntent(null);

      // ✅ show generic reasoning immediately
      setReasoning(generateLoadingReasoning());

      setTimeout(async () => {
        const data = await sendToAPI(inputValue, currentUser);
        const conf = Math.floor(Math.random() * 20) + 80; // optional

        const escalate = shouldEscalate({
          message: inputValue,
          confidence: conf,
          intent: data.intent
        });

        const aiMessage = {
          id: `msg-${Date.now()}-response`,
          role: "assistant",
          content: data.reply,         // ✅ REAL response
          timestamp: new Date().toISOString(),
          agent: agents[data.intent] || agents.supervisor,  // ✅ REAL agent
          intent: data.intent || 'general',  // ✅ REAL intent    
          tags: ["Live response"],     // you can improve this later
          confidence: conf,
        };

        setEnhancedMessages(prev => [...prev, aiMessage]);
        setReasoning([]);

        // ✅ HANDLE ESCALATION
        if (escalate) {
          const escalationMessage = {
            id: `esc-${Date.now()}`,
            role: "assistant",
            content: "ESCALATION_OPTIONS",
            timestamp: new Date().toISOString(),
            meta: {
              type: "escalation-options",
              referenceId: Date.now()
            }
          };

          setEnhancedMessages(prev => [...prev, escalationMessage]);
        }

        originalSendMessage(inputValue.trim());

      }, 1200);

    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setInputValue(suggestion);
    handleSend();
  };

  const handleContinueAI = (messageId) => {
    // remove the escalation prompt
    setEnhancedMessages(prev =>
      prev.filter(msg => msg.id !== messageId)
    );

    // optional message
    setEnhancedMessages(prev => [
      ...prev,
      {
        id: `ai-${Date.now()}`,
        role: "system",
        content: "✅ Continuing with AI assistance.",
        timestamp: new Date().toISOString()
      }
    ]);
  };

  const handleHumanEscalation = (refId) => {
    setIsEscalated(true);

    setEnhancedMessages(prev => [
      ...prev,
      {
        id: `human-${Date.now()}`,
        role: "system",
        content: `✅ Your request has been sent to support. Reference ID: ${refId}`,
        timestamp: new Date().toISOString()
      }
    ]);
  };


  if (!isOpen) {
    return (
      <button
        onClick={toggleChat}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 z-50 flex items-center justify-center group"
      >
        <MessageCircle size={24} />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium">
            {unreadCount}
          </span>
        )}
        <span className="absolute inset-0 rounded-full bg-blue-400 animate-ping opacity-20" />
      </button>
    );
  }

  return (
    <div className={`fixed z-50 bg-white flex flex-col shadow-2xl border border-gray-200 transition-all duration-300 animate-slide-up ${
      isExpanded ? 'inset-4 md:inset-8 lg:inset-16 rounded-2xl' : 'bottom-24 right-6 w-96 h-[32rem] rounded-2xl'
    }`}>
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 rounded-t-2xl shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <Bot size={20} />
            </div>
            <div>
              <h3 className="font-semibold">AI Student Assistant</h3>
              <p className="text-xs text-white/80 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-green-400" />
                {currentAgent ? agents[currentAgent]?.name : 'Online'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {/* <button onClick={() => setShowReasoning(!showReasoning)} className="p-2 hover:bg-white/10 rounded-lg" title="Show reasoning">
              <Sparkles size={18} />
            </button> */}
            <button onClick={() => setIsExpanded(!isExpanded)} className="p-2 hover:bg-white/10 rounded-lg" title={isExpanded ? 'Minimize' : 'Expand'}>
              {isExpanded ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>
            <button onClick={toggleChat} className="p-2 hover:bg-white/10 rounded-lg" title="Close">
              <X size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Reasoning Panel */}
      {showReasoning && reasoning.length > 0 && (
        <div className="bg-gray-900 text-white p-4 text-sm space-y-2 shrink-0">
          <p className="font-medium mb-2">Agent Reasoning:</p>
          {reasoning.map((step, idx) => (
            <div key={idx} className="flex items-center gap-2 text-gray-300 text-xs">
              <div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-white">{step.step}</div>
              <span>{step.text}</span>
            </div>
          ))}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {enhancedMessages.length === 0 && (
          <div className="text-center py-8">
            <Bot size={48} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">Hello! How can I help you today?</p>
          </div>
        )}

        {enhancedMessages.map((message) => (
          <div key={message.id} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {message.role === 'assistant' && (
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center shrink-0">
                <Sparkles size={14} className="text-white" />
              </div>
            )}
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
              message.role === 'user' ? 'bg-blue-600 text-white rounded-br-md' : 'bg-white border border-gray-100 text-gray-800 rounded-bl-md shadow-sm'
            }`}>
              {message.agent && (
                <div className="flex items-center gap-2 mb-2">
                  <message.agent.icon size={12} className="text-blue-600" />
                  <span className="text-xs font-medium text-blue-600">{message.agent.name}</span>
                  {message.intent && <span className="text-xs text-gray-400">• {message.intent}</span>}
                </div>
              )}
              <div className="text-sm whitespace-pre-wrap">                
                {/* <ReactMarkdown
                  components={{
                    a: ({ ...props }) => (
                      <a
                        {...props}
                        className="text-blue-600 underline hover:text-blue-800"
                        target="_blank"
                        rel="noopener noreferrer"
                      />
                    ),
                  }}
                >
                  {linkifyContent(message.content)}
                </ReactMarkdown> */}
                {message.meta?.type === "escalation-options" ? (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">

                    <div className="flex items-center gap-2 text-yellow-700 font-medium">
                      <AlertCircle size={18} />
                      <span>This might need further assistance</span>
                    </div>

                    <p className="text-sm text-gray-600 mt-2">
                      Would you like to continue with AI support or connect with a human advisor?
                    </p>

                    <div className="flex gap-2 mt-3">

                      {/* Continue AI */}
                      <button
                        onClick={() => handleContinueAI(message.id)}
                        className="flex-1 py-2 text-sm bg-gray-100 hover:bg-gray-200 rounded-lg"
                      >
                        Continue with AI
                      </button>

                      {/* Escalate */}
                      <button
                        onClick={() => handleHumanEscalation(message.meta.referenceId)}
                        className="flex-1 py-2 text-sm bg-blue-600 text-white hover:bg-blue-700 rounded-lg"
                      >
                        Talk to Human
                      </button>

                    </div>

                  </div>
                ) : (
                  <ReactMarkdown>
                    {linkifyContent(message.content)}
                  </ReactMarkdown>
                )}

              </div>

              {/* Confidence and tags */}
              {message.role === 'assistant' && (
                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-gray-100">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    message.confidence >= 90 ? 'bg-green-100 text-green-700' :
                    message.confidence >= 70 ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {message.confidence}% confidence
                  </span>
                  {message.tags?.map((tag, idx) => (
                    <span key={idx} className="text-xs px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              <p className={`text-xs mt-1 ${message.role === 'user' ? 'text-blue-100' : 'text-gray-400'}`}>
                {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
            {message.role === 'user' && (
              <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center shrink-0">
                <User size={14} className="text-white" />
              </div>
            )}
          </div>
        ))}

        {reasoning.length > 0 && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center shrink-0">
              <Sparkles size={14} className="text-white" />
            </div>
            <div className="bg-white border border-gray-100 rounded-2xl rounded-bl-md px-4 py-3 shadow-sm">
              <div className="flex gap-1">
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {isEscalated && (
        <div className="px-4 py-2 bg-red-50 border-t border-red-200">
          <div className="text-sm text-red-600 flex items-center gap-2">
            <AlertCircle size={16} />
            <span>Escalated to human support</span>
          </div>
        </div>
      )}

      {/* Low confidence warning */}
      {confidence !== null && confidence < 80 && (
        <div className="px-4 py-2 bg-yellow-50 border-t border-yellow-200 shrink-0">
          <div className="flex items-center gap-2 text-sm text-yellow-700">
            <AlertCircle size={16} />
            <span>Low confidence - Consider 
              <button
                onClick={() => {
                  setIsEscalated(true);

                  sendEscalationToBackend({
                    user: currentUser,
                    history: enhancedMessages
                  });

                  setEnhancedMessages(prev => [
                    ...prev,
                    {
                      id: `manual-${Date.now()}`,
                      role: "system",
                      content: "✅ You have requested human assistance. Our team will contact you soon.",
                      timestamp: new Date().toISOString()
                    }
                  ]);
                }}
                className="underline font-medium"
              >
                escalate to human support
              </button>

            </span>
          </div>
        </div>
      )}

      {/* Suggestions */}
      {enhancedMessages.length <= 2 && suggestions.length > 0 && (
        <div className="px-4 py-2 bg-white border-t border-gray-100 shrink-0">
          <p className="text-xs text-gray-500 mb-2">Suggested questions:</p>
          <div className="flex flex-wrap gap-2">
            {suggestions.slice(0, isExpanded ? 6 : 3).map((suggestion, idx) => (
              <button key={idx} onClick={() => handleSuggestionClick(suggestion)} className="text-xs px-3 py-1.5 bg-blue-50 text-blue-700 rounded-full hover:bg-blue-100 transition-colors">
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-4 bg-white border-t border-gray-200 shrink-0 rounded-b-2xl">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me anything..."
            className="flex-1 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button onClick={handleSend} disabled={!inputValue.trim()} className="p-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
