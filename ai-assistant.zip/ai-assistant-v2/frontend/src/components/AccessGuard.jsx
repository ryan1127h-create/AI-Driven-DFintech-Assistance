import { useAuth } from '../hooks/useTheme.jsx';
import { useState } from "react";
import { Shield, Lock, AlertCircle } from 'lucide-react';
import { users } from '../data/mockData.js';

const accessConfig = {
  unauthenticated: {
    allowedPages: ['programs', 'login', 'inquiry'],
    description: 'Public access only',
  },
  prospective: {
    allowedPages: ['dashboard', 'programs', 'inquiry', 'events'],
    description: 'Full prospective student access',
  },
  applicant: {
    allowedPages: ['dashboard', 'application', 'documents', 'tasks', 'inquiry', 'landing', 'form', 'results'],
    description: 'Application and task management',
  },
  admitted: {
    allowedPages: ['dashboard', 'enrollment', 'housing', 'orientation', 'financial'],
    description: 'Enrollment and onboarding access',
  },
  enrolled: {
    allowedPages: ['dashboard', 'courses', 'progress', 'financial', 'resources'],
    description: 'Course planning and academic progress',
  },
  graduating: {
    allowedPages: ['dashboard', 'graduation', 'career', 'transcripts', 'alumni-preview'],
    description: 'Graduation prep and career services',
  },
  alumni: {
    allowedPages: ['dashboard', 'network', 'mentoring', 'events', 'transcripts', 'career'],
    description: 'Alumni network and services',
  },
  staff: {
    allowedPages: [
      'dashboard',
      'analytics',
      'inquiries',
      'applications',
      'students',
      'knowledge',
      'activity-log',
      'settings',
    ],
    description: 'Full admin access',
  },
};

export function AccessGuard({ children, requiredPage }) {
  const { currentUser, isAuthenticated } = useAuth();

  const currentRole = isAuthenticated ? currentUser?.role : 'unauthenticated';
  const access = accessConfig[currentRole] || accessConfig.unauthenticated;

  const hasAccess = access.allowedPages.includes(requiredPage);

  if (!hasAccess) {
    return <AccessDenied page={requiredPage} requiredRole={getRequiredRoles(requiredPage)} />;
  }

  return children;
}

function getRequiredRoles(page) {
  const roles = [];
  Object.entries(accessConfig).forEach(([role, config]) => {
    if (config.allowedPages.includes(page)) {
      roles.push(role);
    }
  });
  return roles;
}

function AccessDenied({ page, requiredRole }) {
  const { loginAsRole } = useAuth();

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="max-w-md w-full mx-4">
        <div className="bg-white rounded-2xl border border-gray-200 shadow-lg p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-6">
            <Lock size={32} className="text-red-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-6">
            You don't have permission to access this page. This page requires{' '}
            <span className="font-medium text-gray-900">
              {requiredRole.join(', ').replace('_', ' ')}
            </span>{' '}
            role.
          </p>
          <div className="flex items-center justify-center gap-2 mb-6 p-4 bg-yellow-50 rounded-lg">
            <AlertCircle size={18} className="text-yellow-600" />
            <span className="text-sm text-yellow-700">
              Please contact your administrator if you believe this is an error.
            </span>
          </div>
          <div className="flex flex-col gap-3">
            <p className="text-sm text-gray-500">Switch to a role with access:</p>
            <div className="flex flex-wrap justify-center gap-2">
              {users
                .filter((u) => getRequiredRoles(page).includes(u.role))
                .slice(0, 3)
                .map((user) => (
                  <button
                    key={user.id}
                    onClick={() => loginAsRole(user.role)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium"
                  >
                    {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                  </button>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function RoleSwitcher() {
  const { currentUser, switchRole } = useAuth();
  const [open, setOpen] = useState(false);

  const roleLabels = {
    prospective: "Prospective Student",
    applicant: "Applicant",
    admitted: "Admitted Student",
    enrolled: "Enrolled Student",
    graduating: "Graduating Student",
    alumni: "Alumni",
    staff: "Staff Admin",
  };

  return (
    <div className="fixed bottom-24 right-6 z-20">
      
      {/* ✅ Floating Toggle Button */}
      <button
        onClick={() => setOpen(!open)}
        className="bg-purple-600 text-white px-4 py-3 rounded-full shadow-lg hover:bg-purple-700 transition"
      >
        {open ? "✖" : "👤"}
      </button>

      {/* ✅ Popup Panel */}
      {open && (
        <div className="mt-3 bg-white rounded-xl border border-gray-200 shadow-lg p-4 w-72">
          <p className="text-xs text-gray-500 mb-2 font-medium">
            Role Switcher (Demo)
          </p>

          <div className="flex flex-wrap gap-2">
            {Object.keys(roleLabels).map((role) => (
              <button
                key={role}
                onClick={() => {
                  switchRole(role);
                  setOpen(false); // ✅ auto close
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  currentUser?.role === role
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {roleLabels[role]}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}


export function AccessIndicator() {
  const { currentUser, isAuthenticated } = useAuth();
  const currentRole = isAuthenticated ? currentUser?.role : 'unauthenticated';
  const access = accessConfig[currentRole] || accessConfig.unauthenticated;

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-200 rounded-lg">
      <Shield size={14} className="text-green-600" />
      <span className="text-xs text-green-700 font-medium">
        {access.description}
      </span>
    </div>
  );
}

export { accessConfig };
