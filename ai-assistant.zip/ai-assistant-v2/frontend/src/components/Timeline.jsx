import { CheckCircle, Circle, Clock, AlertCircle, ArrowRight } from 'lucide-react';

export default function Timeline({ events, activeStep }) {
  const getIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={16} className="text-white" />;
      case 'active':
        return <Clock size={16} className="text-white" />;
      case 'pending':
        return <Circle size={16} className="text-gray-400" />;
      case 'error':
        return <AlertCircle size={16} className="text-white" />;
      default:
        return <Circle size={16} className="text-gray-400" />;
    }
  };

  const getColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'active':
        return 'bg-blue-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-gray-200';
    }
  };

  const getLineColor = (index) => {
    const currentIndex = events.findIndex((e) => e.status === 'active');
    if (index < currentIndex || events[index].status === 'completed') {
      return 'bg-green-500';
    }
    return 'bg-gray-200';
  };

  return (
    <div className="space-y-4">
      {events.map((event, index) => (
        <div key={index} className="flex items-start gap-4">
          <div className="flex flex-col items-center">
            <div
              className={`w-8 h-8 rounded-full ${getColor(event.status)} flex items-center justify-center shadow-sm`}
            >
              {getIcon(event.status)}
            </div>
            {index < events.length - 1 && (
              <div
                className={`w-0.5 h-16 ${getLineColor(index)} mt-2`}
              />
            )}
          </div>
          <div className="flex-1 pb-8">
            <div className="flex items-center gap-2">
              <p className={`font-medium ${
                event.status === 'pending' ? 'text-gray-400' : 'text-gray-900'
              }`}>
                {event.title}
              </p>
              {event.badge && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">
                  {event.badge}
                </span>
              )}
            </div>
            <p className="text-sm text-gray-500 mt-1">{event.description}</p>
            {event.date && (
              <p className="text-xs text-gray-400 mt-1">{event.date}</p>
            )}
            {event.status === 'active' && event.action && (
              <button className="mt-2 text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
                {event.action}
                <ArrowRight size={14} />
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

export function HorizontalTimeline({ steps, currentStep }) {
  return (
    <div className="flex items-center justify-between w-full px-4">
      {steps.map((step, index) => (
        <div key={index} className="flex items-center flex-1">
          <div className="flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${
                index < currentStep
                  ? 'bg-green-500 text-white'
                  : index === currentStep
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-200 text-gray-500'
              }`}
            >
              {index < currentStep ? (
                <CheckCircle size={16} />
              ) : (
                <span className="text-sm font-medium">{index + 1}</span>
              )}
            </div>
            <p className={`text-xs mt-2 text-center ${
              index <= currentStep ? 'text-gray-900' : 'text-gray-400'
            }`}>
              {step}
            </p>
          </div>
          {index < steps.length - 1 && (
            <div
              className={`flex-1 h-0.5 mx-4 -mt-6 ${
                index < currentStep ? 'bg-green-500' : 'bg-gray-200'
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
}
