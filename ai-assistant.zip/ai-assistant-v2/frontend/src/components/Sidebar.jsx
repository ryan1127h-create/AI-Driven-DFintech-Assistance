import { useState } from 'react';
import { useAuth } from '../hooks/useTheme.jsx';
import {
  Home,
  FileText,
  Calendar,
  BookOpen,
  Briefcase,
  Users,
  BarChart3,
  Settings,
  LogOut,
  GraduationCap,
  ChevronDown,
  ChevronRight,
  Bell,
  Shield,
  Lock
} from 'lucide-react';

const menuConfig = {
  prospective: [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'programs', label: 'Programs', icon: BookOpen },
    { id: 'inquiry', label: 'FAQ', icon: FileText },

  ],
  applicant: [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'application', label: 'Application Tracker', icon: FileText, verified: true },
    { id: 'documents', label: 'Documents', icon: FileText, secure: true },
    { id: 'tasks', label: 'Tasks & Checklist', icon: Calendar },
    { id: 'landing', label: 'Application Guidance', icon: FileText },
  ],
  admitted: [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'enrollment', label: 'Enrollment', icon: GraduationCap, verified: true },
    { id: 'housing', label: 'Housing', icon: Home },
    { id: 'orientation', label: 'Orientation', icon: Calendar },
  ],
  enrolled: [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'courses', label: 'Course Planning', icon: BookOpen, verified: true },
    { id: 'progress', label: 'Academic Progress', icon: BarChart3, secure: true },
    { id: 'financial', label: 'Financial Aid', icon: FileText, secure: true },
    { id: 'resources', label: 'Resources', icon: Users },
  ],
  graduating: [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'graduation', label: 'Graduation', icon: GraduationCap, verified: true },
    { id: 'career', label: 'Career Insights', icon: Briefcase },
    { id: 'transcripts', label: 'Transcripts', icon: FileText, secure: true },
    { id: 'alumni-preview', label: 'Alumni Preview', icon: Users },
  ],
  alumni: [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'network', label: 'Alumni Network', icon: Users, verified: true },
    { id: 'mentoring', label: 'Mentoring', icon: Users },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'transcripts', label: 'Transcripts', icon: FileText, secure: true },
    { id: 'career', label: 'Career Services', icon: Briefcase },
  ],
  staff: [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'inquiries', label: 'Inquiries', icon: FileText },
    { id: 'applications', label: 'Applications', icon: FileText },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'knowledge', label: 'Knowledge Base', icon: BookOpen },
    { id: 'activity-log', label: 'Activity Log', icon: Shield },
    { id: 'settings', label: 'Settings', icon: Settings },
  ],
};

export default function Sidebar({ isOpen, currentPage, onNavigate }) {
  const { currentUser, logout } = useAuth();
  const [expandedItems, setExpandedItems] = useState([]);

  if (!currentUser) return null;

  const menuItems = menuConfig[currentUser.role] || [];

  const toggleExpand = (itemId) => {
    setExpandedItems(prev =>
      prev.includes(itemId)
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  return (
    <aside
      className={`fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white border-r border-gray-200 shadow-sm transition-all duration-300 z-40 ${
        isOpen ? 'w-64' : 'w-0 overflow-hidden'
      }`}
    >
      <div className="flex flex-col h-full">
        <div className="px-4 py-4 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
              {currentUser.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <span className="text-white font-medium text-sm">
                  {currentUser.name.charAt(0)}
                </span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {currentUser.name}
              </p>
              <p className="text-xs text-gray-500 capitalize">
                {currentUser.role.replace('_', ' ')}
              </p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-2">
          <ul className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              const hasChildren = item.children && item.children.length > 0;
              const isExpanded = expandedItems.includes(item.id);

              return (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      if (hasChildren) {
                        toggleExpand(item.id);
                      } else {
                        onNavigate(item.id);
                      }
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all ${
                      isActive
                        ? 'bg-blue-50 text-blue-700 font-medium'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Icon size={20} className={isActive ? 'text-blue-600' : 'text-gray-500'} />
                    <span className="flex-1 text-sm">{item.label}</span>

                    {item.verified && (
                      <Shield size={14} className="text-green-500" title="Verified Source" />
                    )}
                    {item.secure && (
                      <Lock size={14} className="text-gray-400" title="Secure Data" />
                    )}

                    {hasChildren && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleExpand(item.id);
                        }}
                        className="p-1"
                      >
                        {isExpanded ? (
                          <ChevronDown size={16} />
                        ) : (
                          <ChevronRight size={16} />
                        )}
                      </button>
                    )}
                  </button>

                  {hasChildren && isExpanded && (
                    <ul className="ml-6 mt-1 space-y-1">
                      {item.children.map((child) => (
                        <li key={child.id}>
                          <button
                            onClick={() => onNavigate(child.id)}
                            className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-sm ${
                              currentPage === child.id
                                ? 'bg-blue-50 text-blue-700'
                                : 'text-gray-600 hover:bg-gray-50'
                            }`}
                          >
                            {child.label}
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t border-gray-200 p-4">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
          >
            <LogOut size={20} />
            <span className="text-sm font-medium">Logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
}
