import { useState } from 'react';
import { Check, Circle, Clock, AlertCircle } from 'lucide-react';

export default function Checklist({ items, onToggle, readOnly = false, showProgress = true }) {
  const completedCount = items.filter((item) => item.completed).length;
  const totalCount = items.length;
  const progressPercentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  return (
    <div className="space-y-4">
      {showProgress && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Progress</span>
            <span className="font-medium text-gray-900">
              {completedCount} of {totalCount} completed
            </span>
          </div>
          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full transition-all duration-500"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
        </div>
      )}

      <div className="space-y-2">
        {items.map((item) => (
          <div
            key={item.id}
            onClick={() => !readOnly && onToggle && onToggle(item.id)}
            className={`flex items-start gap-3 p-3 rounded-lg border transition-all ${
              item.completed
                ? 'bg-green-50 border-green-200'
                : item.priority === 'high'
                ? 'bg-red-50 border-red-200'
                : 'bg-white border-gray-200 hover:border-gray-300'
            } ${!readOnly && onToggle ? 'cursor-pointer' : ''}`}
          >
            <div className={`mt-0.5 ${item.completed ? 'text-green-500' : 'text-gray-400'}`}>
              {item.completed ? (
                <Check size={20} className="text-green-500" />
              ) : item.priority === 'high' ? (
                <AlertCircle size={20} className="text-red-500" />
              ) : (
                <Circle size={20} />
              )}
            </div>
            <div className="flex-1">
              <p
                className={`text-sm ${
                  item.completed ? 'text-gray-500 line-through' : 'text-gray-900'
                }`}
              >
                {item.task}
              </p>
              {item.deadline && (
                <div className="flex items-center gap-1 mt-1">
                  <Clock size={12} className="text-gray-400" />
                  <span className="text-xs text-gray-500">{item.deadline}</span>
                </div>
              )}
            </div>
            {item.badge && (
              <span
                className={`text-xs px-2 py-1 rounded-full ${
                  item.badge === ' urgent'
                    ? 'bg-red-100 text-red-600'
                    : item.badge === 'optional'
                    ? 'bg-gray-100 text-gray-600'
                    : 'bg-blue-100 text-blue-600'
                }`}
              >
                {item.badge}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export function SimpleChecklist({ items }) {
  return (
    <div className="space-y-2">
      {items.map((item, index) => (
        <div
          key={index}
          className="flex items-center gap-2 text-sm text-gray-700"
        >
          <div
            className={`w-4 h-4 rounded flex items-center justify-center ${
              item.completed ? 'bg-green-500' : 'border-2 border-gray-300'
            }`}
          >
            {item.completed && <Check size={12} className="text-white" />}
          </div>
          <span className={item.completed ? 'line-through text-gray-400' : ''}>
            {item.task}
          </span>
        </div>
      ))}
    </div>
  );
}
