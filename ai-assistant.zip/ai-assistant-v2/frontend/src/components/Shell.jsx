export default function Shell({ app = "student", active = "home", children }) {
  const isAdmin = app === "admin";
  return (
    <div className={isAdmin ? "app--admin" : "app--student"}>
      <header className="topbar">
        <div className="topbar__inner">
          <a className="brand" href="#/">
            <span className="brand__mark">D</span>
            <span>{isAdmin ? "MSc DFT Console" : "MSc DFT Assistant"}</span>
            <span className="brand__role">{isAdmin ? "Staff" : "Student"}</span>
          </a>
          <nav className="nav">
            {isAdmin ? (
              <>
                <a href="#/admin" aria-current={active === "home" ? "page" : undefined}>Edit data</a>
                <a href="#/admin/history" aria-current={active === "history" ? "page" : undefined}>History / rollback</a>
                <a href="#/settings" aria-current={active === "settings" ? "page" : undefined}>Credentials</a>
              </>
            ) : (
              <>
                <a href="#/" aria-current={active === "home" ? "page" : undefined}>Start</a>
                <a href="#/settings" aria-current={active === "settings" ? "page" : undefined}>Settings</a>
              </>
            )}
          </nav>
        </div>
      </header>
      <main className="wrap">{children}</main>
    </div>
  );
}

export function Steps({ current = 1 }) {
  const steps = ["Select profile and provide information", "Confirm profile", "Get recommendations"];
  return (
    <ol className="steps reveal" aria-hidden="true">
      {steps.map((label, index) => (
        <FragmentWithSep key={label} last={index === steps.length - 1}>
          <li data-on={current === index + 1 ? true : undefined}>
            <span className="dot">{current > index + 1 ? "✓" : index + 1}</span> {label}
          </li>
        </FragmentWithSep>
      ))}
    </ol>
  );
}

function FragmentWithSep({ children, last }) {
  return <>{children}{!last && <span className="sep" />}</>;
}

export function Panel({ title, children, className = "" }) {
  return (
    <section className={`panel reveal ${className}`.trim()}>
      {title && <h2>{title}</h2>}
      {children}
    </section>
  );
}
