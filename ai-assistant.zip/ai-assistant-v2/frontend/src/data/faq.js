export const faqData = [
    {
        "section": "Admission Criteria",
        "question": "Is there a requirement of education major for Master of Science in Digital Financial Technology?",
        "answer": "In terms of education major, we are looking for students with background in Computing, Financial Engineering, Finance, Statistics, or other STEM. We also prefer candidates with work experience, internship experience, or research project experience related to FinTech. For students with only social science programmes, there should be evidence of sufficient background to complete programming courses offered by School of Computing."
    },
    {
        "section": "Admission Criteria",
        "question": "What would be the average years of experience required to apply for this programme?",
        "answer": "There is no requirement about work experience."
    },
    {
        "section": "Admission Criteria",
        "question": "I have FinTech work experience but I do not have a Business or STEM degree. Do I qualify for the Master of Science in Digital Financial Technology?",
        "answer": "You may put in your application, however, having relevant degrees would be advantageous. The admissions committee takes into consideration all your submitted credential which include qualifications, relevant FinTech work experience, project experiences related to FinTech, standard test scores, etc."
    },
    {
        "section": "Admission Criteria",
        "question": "What is the minimum GPA to apply for the MSc in Digital Financial Technology?",
        "answer": "There is no minimum GPA requirement."
    },
    {
        "section": "Admission Criteria",
        "question": "I do not have experience in programming or coding. Do I qualify for the Master of Science in Digital Financial Technologies?",
        "answer": "It is advantageous for interested applicants to know basic programming language (especially Python) as it would be used in several core and elective courses. Students with no background in programming will need to provide evidence that they can learn well in those technical courses under MSc in DFT."
    },
    {
        "section": "Admission Criteria",
        "question": "What level of finance and computer science knowledge are potential candidates expected to possess?",
        "answer": "Admitted students typically have one of the following educational backgrounds: CS, IS, Finance, or Financial Engineering. A small number of candidates have strong background in both Finance and CS, or STEM background (in Statistics, Math or IEOR)."
    },
    {
        "section": "Admission Criteria",
        "question": "I am a fresh graduate from the university. Am I eligible to apply for the MSc in DFT?",
        "answer": "All fresh graduates are welcome to apply for the MSc DFT programme. The admissions committee takes into considerations all relevant qualifications when selecting suitable candidates. There is no requirement for work experience when applying for the MSc DFT programme. However, possessing FinTech-related work or project experience would be advantageous."
    },
    {
        "section": "Admission Criteria",
        "question": "How would I know if my scores are good enough?",
        "answer": "There is no minimum cut-off for any component. The admission is competitive basis."
    },
    {
        "section": "Admission Criteria",
        "question": "What is the cut-off/average score required for GRE/GMAT?",
        "answer": "There is no minimum cut-off. A GMAT/GRE score is not mandatory, however, a good GMAT/GRE score will strengthen your application. Generally, a score of 700 out of 800 for the GMAT, or the GMAT equivalent in GRE is expected."
    },
    {
        "section": "Admission Criteria",
        "question": "Can I apply for the programme if my GRE/GMAT results is not ready?",
        "answer": "Applicants MUST upload all the required documents prior to submitting their application. Only applications with complete submissions will be reviewed."
    },
    {
        "section": "Admission Criteria",
        "question": "Is TOEFL/IELTS score mandatory?",
        "answer": "International applicants who graduated from universities where English is not the main medium of instruction must submit TOEFL or IELTS (International English Language Testing System) scores. Please note that TOEFL iBT Test- MyBest™ Scores and TOEFL Home Edition tests are acceptable."
    },
    {
        "section": "Admission",
        "question": "How many intakes do you have per year?",
        "answer": "There is one admission intake in August each year."
    },
    {
        "section": "Admission",
        "question": "What industry role do different vertical tracks prepare students to fit in?",
        "answer": "MSc DFT graduates would be suitable for the following career options: Software Developers and Data Scientists for financial institutions or FinTech firms, Quantitative Analysts with knowledge in AI or Data Science."
    },
    {
        "section": "Admission",
        "question": "Is there career planning support provided for MSc in DFT students?",
        "answer": "The programme requires students to complete a 6-month internship (capstone project) as part of the programme requirement. The capstone component provides excellent career opportunities for students. Under NUS Centre for Future Graduates (CFG) website, NUS provides a wide range of career workshops and career guidance to help you be better prepared. Students can also look out for career opportunities at the career fairs organized regularly by the University and SoC."
    },
    {
        "section": "Application Process",
        "question": "Is it compulsory to submit my financial documents?",
        "answer": "All mandatory documents must be submitted by the application deadline."
    },
    {
        "section": "Application Process",
        "question": "Can I have more than 2 referees?",
        "answer": "There must be at least 2 referee report submissions. You may submit more if available."
    },
    {
        "section": "Application Process",
        "question": "Who can I nominate as my referees?",
        "answer": "The person who may qualify as your referee can be a professor you have understudied, an ex-employer or supervisor. This person should be able to provide objective reviews on your contributions, especially relevant work experience, your area of expertise or projects and achievements that you wish to highlight in your application."
    },
    {
        "section": "Application Process",
        "question": "If the application has closed, can I still apply?",
        "answer": "No applications will be accepted for review after the application deadline."
    },
    {
        "section": "Application Process",
        "question": "Are there any interviews for applicants?",
        "answer": "Interview is not mandatory for all applicants. The admissions committee may interview shortlisted applicants if more information is needed."
    },
    {
        "section": "Fees Matters",
        "question": "What is the payment method?",
        "answer": "The various payment modes are detailed here ."
    },
    {
        "section": "Fees Matters",
        "question": "Can I use my parents' bank account as my supporting financial document?",
        "answer": "Please provide a written letter stating their consent to sponsor your studies as well as either your parents’ bank statements and/or payslips."
    },
    {
        "section": "Others",
        "question": "How do I apply for the entry visa and Student's Pass?",
        "answer": "Nationals from countries (such as PR China, India, Vietnam, Bangladesh, Pakistan, Myanmar, etc) will require entry visa. The School of Computing, Graduate Studies’ Office will apply a single-journey visa cum in-principle Student’s Pass approval on behalf of these students via the Student Pass On-Line Application & Registration (SOLAR) system administered by the Immigration & Checkpoints Authority (ICA). We will inform you in writing on how to complete the application process at your end, if you have been selected for admission and are accepting our offer."
    },
    {
        "section": "Others",
        "question": "Is it possible for MSc DFT students to have part-time appointments so that they can support themselves?",
        "answer": "When considering part-time work arrangements, it should be noted that a high level of commitment is expected of all graduate students enrolled in full-time programmes, and the taking on of external part-time work to supplement personal income is generally not encouraged. Only students who have completed their registration formalities are allowed to apply for part-time appointment schemes, where applicable. Please refer to the Immigration & Checkpoints Authority’s (ICA) Student’s Pass (STP) guidelines on International Students seeking part-time jobs and internships in Singapore. Students are advised to adhere strictly to ICA’s STP guidelines . For more details, you may refer to the Ministry of Manpower website or NUS Centre for Future Graduates website ."
    },
    {
        "section": "Others",
        "question": "How can I find a part-time job in NUS while I am in the full-time MSc DFT programme?",
        "answer": "Students can source for work opportunities on their own, speak to the SoC industry partners or check out the job offerings published under NUS Centre for Future Graduates website."
    },
    {
        "section": "Others",
        "question": "I am a foreigner. Where can I find more information on accommodation and immigration matters?",
        "answer": "Please refer to http://nus.edu.sg/osa/ ."
    },
    {
        "section": "Others",
        "question": "I have accepted the offer via the Graduate Admission System (GDA), but why am I unable to apply for the NUS accommodation via the provided link?",
        "answer": "You can apply for NUS accommodation when the application is open. Please ensure that your admission status has been updated to “Offer Accepted” in GDA before you proceed to submit your accommodation application."
    },
    {
        "section": "Others",
        "question": "What is the estimated cost of living in Singapore?",
        "answer": "You may find out more about the estimated cost of living here . You may also refer to the websites of the Office of Student Affairs & the International Students Survival Kit for more information on helping you adjust and navigate through your experience living in Singapore."
    },

]