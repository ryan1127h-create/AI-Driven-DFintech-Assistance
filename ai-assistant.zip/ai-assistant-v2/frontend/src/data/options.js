export const degreeLevels = ["high_school", "bachelor", "master", "phd"];
export const fields = ["computer_science", "finance", "economics", "engineering", "mathematics", "business", "other"];
export const proficiencies = ["none", "basic", "intermediate", "advanced"];
export const applicationTypes = ["full_time", "part_time"];
export const roles = ["fintech_pm", "quant_risk", "digital_banking", "payments", "compliance_regtech", "data_analytics"];

export const materials = [
  { key: "personal_statement", label: "Personal Statement", required: "required", hint: "Explains reasons for applying, preparation, career plans, and relevant background." },
  { key: "cv", label: "Curriculum Vitae / CV", required: "required", hint: "Summarises education, work experience, projects, achievements, and skills." },
  { key: "proof_of_residence", label: "Proof of Residence / Passport / NRIC", required: "required", hint: "Confirms identity and residence status." },
  { key: "degree_certificate", label: "Official Degree Certificate / Expected Graduation Letter", required: "required", hint: "Confirms award or expected completion of degree." },
  { key: "transcript", label: "Official Transcript(s)", required: "required", hint: "Verifies academic record and grades for all courses." },
  { key: "english_proficiency", label: "TOEFL / IELTS Score Report", required: "conditional", hint: "Required if prior university education was not mainly taught in English." },
  { key: "standardised_test_scores", label: "GRE / GMAT / GATE Score Report", required: "supporting", hint: "Optional supporting evidence where available." },
  { key: "referee_reports", label: "Two Referee Reports / Evidence", required: "required", hint: "Referees normally submit online in the real system." },
  { key: "financial_support", label: "Financial Support Document", required: "supporting", hint: "Bank statements, payslips, or sponsor letter." },
  { key: "application_fee", label: "Application Fee Payment Proof", required: "required", hint: "S$109 application fee payment screenshot or receipt." },
  { key: "other_supporting_documents", label: "Other Supporting Documents", required: "supporting", hint: "Awards, certificates, or other evidence where applicable." }
];

export const sampleResult = {
  profileType: "applicant",
  materialSummary: { submittedRequired: 2, requiredTotal: 7, missingRequired: 5, rejectedRequired: 0, isComplete: false },
  materials: materials.slice(0, 5).map((m, index) => ({ ...m, status: index < 2 ? "uploaded" : "missing", reason: index < 2 ? "Uploaded; click to view" : "Not uploaded" })),
  checklist: [
    { label: "Personal Statement", required: true, status: "Submitted", why: "Required for application assessment." },
    { label: "Official Transcript(s)", required: true, status: "To prepare", why: "Needed to verify academic record." }
  ],
  timeline: [
    { label: "Fill in profile", state: "done" },
    { label: "Upload application materials", state: "current" },
    { label: "Material completeness check", state: "pending" },
    { label: "Formal academic review", state: "pending" },
    { label: "Admission decision", state: "pending" }
  ],
  recommended: [
    { code: "FT5001", name: "Fintech Innovations: A Strategic Landscape", credits: 4 },
    { code: "FT5010", name: "Algorithmic Trading Systems Design and Deployment", credits: 4 },
    { code: "BT5153", name: "Applied Machine Learning for Business Analytics", credits: 4 }
  ],
  skillGaps: ["Programming", "Data analytics", "Finance knowledge"],
  progress: { completed: 8, planned: 24, required: 52, remaining: 20 }
};

export const sampleComparison = [
  {
    program: "NUS MSc in Digital Financial Technology",
    is_target: true,
    duration: "Full-time normal duration 1.5 years; part-time normal duration 2.5 years.",
    fees: "S$74,120 tuition fee for AY2026/2027 August 2026 intake onwards.",
    format: "On-campus coursework plus two-semester FT5007 FinTech Capstone Project.",
    source_url: "https://www.comp.nus.edu.sg/programmes/pg/mdft/",
    fetched_at: "2026-06-05",
  },
  {
    program: "SMU MSc in Applied Finance (FinTech track)",
    is_target: false,
    duration: "18 months full-time; 24 months part-time.",
    fees: "S$63,220 tuition fee inclusive of GST.",
    format: "On-campus coursework with internship option through SMU partner network.",
    source_url: "https://masters.smu.edu.sg/programme/msc-in-applied-finance",
    fetched_at: "2026-06-05",
  },
  {
    program: "NTU MSc in Financial Technology",
    is_target: false,
    duration: "1 year full-time; 2 years part-time.",
    fees: "Refer to official programme fee table.",
    format: "Coursework programme jointly supported by finance and technology training.",
    source_url: "https://www.ntu.edu.sg/spms/about-us/mathematics/grad/msc-in-financial-technology",
    fetched_at: "2026-06-05",
  },
];
