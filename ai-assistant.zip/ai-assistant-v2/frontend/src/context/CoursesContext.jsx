import { createContext, useContext, useEffect, useState } from "react";
import moduleCatalog from "../data/module_catalog.json";

const CoursesContext = createContext();

export const CoursesProvider = ({ children }) => {
  const [courses, setCourses] = useState([]);

  const transformCourses = (data) => {
    return data.modules.map((m) => ({
      id: m.code,
      code: m.code,
      name: m.name,
      credits: m.credits,
      description: m.description,
      source_url: m.source_url,
      semester: m.semesters || [],
      workload: m.workload_hours,
      prereq: m.prereq_tree,
      enrolled: false, // UI state
      seats: 10,       // mock (optional)
      capacity: 20     // mock
    }));
  };

  useEffect(() => {
    const transformed = transformCourses(moduleCatalog);
    setCourses(transformed);
  }, []);

  return (
    <CoursesContext.Provider value={{ courses, setCourses }}>
      {children}
    </CoursesContext.Provider>
  );
};

export const useCourses = () => useContext(CoursesContext);
