import { createContext, useContext, useState } from 'react';
import { chatMessages as initialMessages } from '../data/mockData';

const ChatContext = createContext(null);

export const ChatProvider = ({ children }) => {
  const [messages, setMessages] = useState(initialMessages);
  const [isOpen, setIsOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const toggleChat = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setUnreadCount(0);
    }
  };

  const openChat = () => setIsOpen(true);
  const closeChat = () => setIsOpen(false);

  const sendMessage = (content) => {
    const newMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, newMessage]);

    setIsTyping(true);

    setTimeout(() => {
      const aiResponse = {
        id: `msg-${Date.now()}-response`,
        role: 'assistant',
        content: generateAIResponse(content),
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);

      if (!isOpen) {
        setUnreadCount(prev => prev + 1);
      }
    }, 1500);
  };

  const generateAIResponse = (userMessage) => {
    const responses = [
      "I'd be happy to help you with that. Let me check the information for you.",
      "Based on your inquiry, here's what I found...",
      "That's a great question! Here's what you need to know:",
      "I can help you with that. Let me provide you with the relevant information.",
      "Thank you for reaching out. I'm processing your request now.",
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  return (
    <ChatContext.Provider value={{
      messages,
      isOpen,
      isTyping,
      unreadCount,
      toggleChat,
      openChat,
      closeChat,
      sendMessage,
    }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
