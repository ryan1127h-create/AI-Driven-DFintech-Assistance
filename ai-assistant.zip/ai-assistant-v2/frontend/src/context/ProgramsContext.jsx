import { createContext, useContext, useEffect, useState } from "react";
import data from "../data/programme.json"; 

const ProgramsContext = createContext();

export const ProgramsProvider = ({ children }) => {
  const [programs, setPrograms] = useState([]);

  const transformData = (data) => {
    return data.map((item, index) => {
      const p = item.programme;

      return {
        id: index + 1,
        name: p.Title__c || "N/A",
        degree: p.Type__c || "N/A",
        duration: p.Mode_of_Study__c || "N/A",
        type: p.Type__c || "N/A",
        tuition: "N/A",
        deadline: p.Intake_Period__c || "N/A",
        description: p.Open_Text__c || "No description",
        area: p.Area_of_Interest__c || "",
        faculty: item.facultyDisplay || "",
        link: p.Program_Page_Link__c,
        applyLink: p.Application_URL__c,
      };
    });
  };

  // ✅ load + transform once
  useEffect(() => {
    const transformed = transformData(data.returnValue);
    setPrograms(transformed);
  }, []);

  return (
    <ProgramsContext.Provider value={{ programs }}>
      {children}
    </ProgramsContext.Provider>
  );
};

// ✅ custom hook (clean usage)
export const usePrograms = () => useContext(ProgramsContext);
