# 🚀 Running the Application

## ✅ Start Backend (FastAPI)

cd backend

pip install -r requirements.txt

python -m uvicorn app.main:app --reload

## ✅ Start Frontend

cd frontend

npm install

npm run dev
