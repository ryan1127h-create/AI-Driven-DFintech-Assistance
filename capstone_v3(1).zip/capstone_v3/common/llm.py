"""DeepSeek LLM client wrapper (OpenAI-compatible).

The LLM is used ONLY for natural-language explanation / narrative. All
decisions (eligibility, missing items, status, recommendations) are made by
deterministic rule engines, never here.

Offline/degraded mode: when DEEPSEEK_API_KEY is unset, `explain` returns the
provided fallback text. This keeps every agent runnable and tests deterministic
without network access.
"""
from __future__ import annotations

from . import config


def _get_client():
    # Built fresh per call so a key saved at runtime (via /settings) takes effect.
    from openai import OpenAI

    return OpenAI(api_key=config.get_api_key(), base_url=config.get_base_url())


def available() -> bool:
    """True if an API key is configured (live mode)."""
    return config.is_configured()


def explain(system: str, user: str, fallback: str) -> str:
    """Return a natural-language string from DeepSeek, or `fallback` offline.

    Low temperature for stable, grounded phrasing. Any API error falls back to
    the deterministic template so the agent never crashes on LLM issues
    (requirements doc: "agents must fail safely").
    """
    if not available():
        return fallback
    try:
        resp = _get_client().chat.completions.create(
            model=config.get_model(),
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0.2,
            max_tokens=600,
        )
        content = resp.choices[0].message.content
        return content.strip() if content else fallback
    except Exception:
        return fallback


def explain_map(system: str, user: str, fallback: dict[str, str]) -> dict[str, str]:
    """One LLM call returning a JSON object {key: text}.

    Used to batch many small explanations into a single request. Offline or on
    any error/parse failure, returns `fallback` unchanged (deterministic).
    The returned map is filtered to the keys present in `fallback`, and any
    missing key falls back to its template value.
    """
    if not available():
        return fallback
    import json

    try:
        resp = _get_client().chat.completions.create(
            model=config.get_model(),
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0.2,
            max_tokens=900,
            response_format={"type": "json_object"},
        )
        content = resp.choices[0].message.content
        data = json.loads(content) if content else {}
    except Exception:
        return fallback
    if not isinstance(data, dict):
        return fallback
    return {k: (data.get(k) or fallback[k]) for k in fallback}
