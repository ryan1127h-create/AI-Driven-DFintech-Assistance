"""#5 Tracker Agent entry point.

Returns application status (translated), a status timeline, an estimated next
date, milestone reminders (preference-aware), and — when documents are required
— the specific outstanding items from the #4 checklist engine.
"""
from __future__ import annotations

from datetime import date

from common.envelope import AgentResponse
from common.profile import NotificationChannel, NotificationFrequency, StatusCode, UserProfile

from .reminders import _MILESTONES, build_reminders, due_now
from .statemachine import (
    build_timeline,
    estimated_next_date,
    latest_status_date,
    next_states,
    translate,
)


def _outstanding_documents(profile: UserProfile) -> list[dict]:
    """When docs are required, ask the #4 engine which items still need action."""
    from agents.checklist.engine import build_checklist

    result = build_checklist(profile)
    return [
        {"key": it.key, "label": it.label, "status": it.status}
        for it in result.items
        if it.status in ("missing", "rejected")
    ]


def _material_completion_from_profile(profile: UserProfile) -> dict:
    """Summarise submitted/missing/rejected documents for the UI action centre."""
    from agents.checklist.engine import build_checklist

    result = build_checklist(profile)
    required = [it for it in result.items if it.required]
    submitted = [it for it in required if it.status in ("submitted", "under_review", "verified")]
    missing = [it for it in required if it.status == "missing"]
    rejected = [it for it in required if it.status == "rejected"]
    return {
        "required_total": len(required),
        "submitted_required": len(submitted),
        "missing_required": [{"key": it.key, "label": it.label} for it in missing],
        "rejected_required": [{"key": it.key, "label": it.label} for it in rejected],
        "is_complete": len(required) > 0 and not missing and not rejected,
    }


def _demo_milestones(profile: UserProfile) -> list[dict]:
    """MVP timeline: separates our material check from mock official status."""
    app = profile.application
    status = app.status_code if app else StatusCode.DRAFT
    completion = _material_completion_from_profile(profile) if app else {"is_complete": False}
    order = [
        ("profile", "填写个人资料"),
        ("documents", "上传申请材料"),
        ("completeness", "材料完整性检查"),
        ("review", "正式学术审核"),
        ("decision", "录取结果"),
    ]
    active_index = 0
    if app:
        active_index = 1 if not completion["is_complete"] else 2
        if status == StatusCode.UNDER_REVIEW:
            active_index = 3
        elif status in (StatusCode.OFFER, StatusCode.WAITLIST, StatusCode.REJECTED, StatusCode.ACCEPTED):
            active_index = 4
        elif status == StatusCode.DOCS_REQUIRED:
            active_index = 1
        elif status == StatusCode.SUBMITTED:
            active_index = 2
    out = []
    for idx, (key, label) in enumerate(order):
        state = "done" if idx < active_index else "current" if idx == active_index else "pending"
        out.append({"key": key, "label": label, "state": state})
    return out


def _escalation_packet(profile: UserProfile, next_step: str, outstanding_docs: list[dict]) -> dict:
    """Structured case summary for human hand-off in the MVP."""
    app = profile.application
    reason = "补充/核验申请材料" if outstanding_docs else "申请状态或政策问题需要人工确认"
    return {
        "case_type": "admissions_support",
        "suggested_team": "NUS SoC MSc DFinTech Admissions / Programme Office",
        "reason": reason,
        "application_id": app.application_id if app else None,
        "current_status": app.status_code.value if app else "NO_APPLICATION",
        "outstanding_documents": outstanding_docs,
        "summary": next_step,
        "official_enquiry_url": "https://cloud.hello.nus.edu.sg/pg-enquiry?acquisition_source_id=B2C_WEBFORM_PG_SOC&programme_code=0300DFTCWK",
        "graduate_admission_system_url": "https://gradapp.nus.edu.sg/",
    }


def handle(profile: UserProfile, slots: dict | None = None) -> AgentResponse:
    slots = slots or {}
    if profile.application is None:
        return AgentResponse.needs(
            ["application"],
            "你还没有提交申请,暂时没有可追踪的状态。",
        )

    app = profile.application
    t = translate(app.status_code)
    today = date.fromisoformat(slots["today"]) if slots.get("today") else None

    timeline = build_timeline(app)
    eta_date = estimated_next_date(app.status_code, latest_status_date(app))
    reminders = build_reminders(profile, today=today)
    due = due_now(profile, today=today)  # preview only; does NOT write the log
    due_data = [
        {"kind": n.kind, "channels": n.channels, "date": n.date, "subject": n.subject,
         "message": n.message, "urgency": n.urgency, "reminder_keys": n.reminder_keys}
        for n in due
    ]

    # Link to #4: surface the specific docs blocking the application.
    outstanding_docs: list[dict] = []
    next_step = t["next_step"]
    if app.status_code == StatusCode.DOCS_REQUIRED:
        outstanding_docs = _outstanding_documents(profile)
        if outstanding_docs:
            labels = "、".join(d["label"] for d in outstanding_docs)
            next_step = f"请尽快处理以下材料:{labels}。"

    deadlines = [{"name": n, "date": d} for n, d in app.deadlines.items()]
    reminders_data = [
        {"key": r.key, "name": r.name, "date": r.date, "message": r.message,
         "urgency": r.urgency, "channels": r.channels}
        for r in reminders
    ]

    speakable = t["human_status"] + "。" + next_step
    if eta_date:
        speakable += f"(预计 {eta_date} 前有进展)"
    if reminders:
        speakable += " 另外:" + reminders[0].message

    return AgentResponse(
        status="ok",
        answer_type="official",  # status is sourced from the (mock) system
        speakable=speakable,
        data={
            "status_code": app.status_code.value,
            "human_status": t["human_status"],
            "next_step": next_step,
            "estimated_next_date": eta_date,
            "timeline": timeline,
            "outstanding_documents": outstanding_docs,
            "deadlines": deadlines,
            "reminders": reminders_data,
            "possible_next_states": next_states(app.status_code),
            "material_completion": _material_completion_from_profile(profile),
            "demo_milestones": _demo_milestones(profile),
            "demo_disclaimer": "Demo / Mock Status: 真实官方申请状态必须来自 NUS Graduate Admission System；本系统目前使用 mock admissions database。",
            "escalation_packet": _escalation_packet(profile, next_step, outstanding_docs),
            "due_now": due_data,
            "notification_prefs": _prefs_dict(profile),
        },
        sources=["application_system_mock"],
    )


def _prefs_dict(profile: UserProfile) -> dict:
    p = profile.notification_prefs
    return {
        "channels": [c.value for c in p.channels],
        "frequency": p.frequency.value,
        "muted_milestones": list(p.muted_milestones),
    }


def configure(profile: UserProfile, slots: dict | None = None) -> AgentResponse:
    """Update notification preferences (channels / frequency / per-milestone mute).

    Validates against the controlled vocabularies; invalid input returns
    need_clarification rather than silently dropping the change."""
    slots = slots or {}
    invalid: list[str] = []

    new_channels = profile.notification_prefs.channels
    if "channels" in slots:
        try:
            new_channels = [NotificationChannel(c) for c in slots["channels"]]
        except ValueError:
            invalid.append("channels")

    new_freq = profile.notification_prefs.frequency
    if "frequency" in slots:
        try:
            new_freq = NotificationFrequency(slots["frequency"])
        except ValueError:
            invalid.append("frequency")

    known = set(_MILESTONES.keys())
    mute = list(slots.get("mute", []))
    unmute = list(slots.get("unmute", []))
    if any(m not in known for m in (*mute, *unmute)):
        invalid.append("milestone")

    if invalid:
        return AgentResponse.needs(
            invalid,
            "有无法识别的通知设置项,请检查后重试:" + "、".join(invalid),
        )

    muted = [m for m in profile.notification_prefs.muted_milestones if m not in unmute]
    for m in mute:
        if m not in muted:
            muted.append(m)

    profile.notification_prefs.channels = new_channels
    profile.notification_prefs.frequency = new_freq
    profile.notification_prefs.muted_milestones = muted

    prefs = _prefs_dict(profile)
    speakable = (
        f"已更新通知设置:渠道 {', '.join(prefs['channels'])};"
        f"频率 {prefs['frequency']}"
        + (f";已静音 {', '.join(prefs['muted_milestones'])}" if prefs["muted_milestones"] else "")
        + "。"
    )
    return AgentResponse(
        status="ok",
        answer_type="advisory",
        speakable=speakable,
        data={"notification_prefs": prefs},
    )
