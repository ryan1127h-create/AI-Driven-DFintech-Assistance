"""#6 Comparator Agent entry point.

Produces an objective comparison table plus a goal-tied narrative. Compliance
hard constraints (contract §4 #6):
  - rows come ONLY from the curated dataset
  - the LLM narrative must not produce rankings or "X is better than Y"
  - a disclaimer is always attached
"""
from __future__ import annotations

from common import llm
from common.envelope import AgentResponse
from common.profile import UserProfile

from .engine import compare, violates_ranking

_SYSTEM = (
    "You write a brief, balanced 'fit' summary comparing graduate programmes "
    "for one applicant. STRICT RULES: only use the facts provided; never rank "
    "programmes or say one is better than another; frame everything as fit to "
    "the applicant's stated goals; 2-3 sentences; no new facts."
)


def _narrative(comp, target_roles) -> str:
    role_text = "、".join(r.value for r in target_roles) if target_roles else "你的目标"
    fallback = (
        f"结合你的目标({role_text}),"
        + (f"{comp.best_for_you} 在相关方向的契合度较高。" if comp.best_for_you
           else "各项目各有侧重,建议按你的具体目标权衡。")
        + " 以下对比仅供参考。"
    )
    if not llm.available():
        return fallback
    facts = "\n".join(
        f"- {r.program}: "
        + "; ".join(f"{d}={c.text}" for d, c in r.facts.items() if c.kind == "verified")
        + f" (matches your goals on: {', '.join(r.synthesis.matched_roles) or 'none'})"
        for r in comp.rows
    )
    user = (
        f"Applicant goals: {role_text}\n"
        f"Best fit by overlap: {comp.best_for_you or 'n/a'}\n"
        f"Programmes:\n{facts}"
    )
    out = llm.explain(_SYSTEM, user, fallback)
    # Deterministic compliance guard: reject any cross-programme ranking claim.
    return fallback if violates_ranking(out) else out


def _facts_table(comp) -> dict:
    return {
        "rows": [
            {
                "program": r.program,
                "is_target": r.is_target,
                "facts": {
                    d: {"text": c.text, "kind": c.kind,
                        "source_url": c.source_url, "fetched_at": c.fetched_at}
                    for d, c in r.facts.items()
                },
            }
            for r in comp.rows
        ]
    }


def _synthesis(comp, narrative: str) -> dict:
    return {
        "rows": [
            {
                "program": r.program,
                "matched_roles": r.synthesis.matched_roles,
                "role_reasons": r.synthesis.role_reasons,
                "weighted_score": r.synthesis.weighted_score,
                "score_breakdown": r.synthesis.score_breakdown,
            }
            for r in comp.rows
        ],
        "best_for_you": comp.best_for_you,
        "narrative": narrative,
        "weights": comp.weights,
    }


def handle(profile: UserProfile, slots: dict | None = None) -> AgentResponse:
    slots = slots or {}
    priorities = slots.get("priorities")
    comp = compare(profile.target_roles, priorities)

    # consent gate (design doc 13 §5): opt-out -> objective facts only, the
    # entire personalised synthesis zone (scores + best_for_you + narrative) is
    # suppressed.
    personalized = profile.consent_flags.personalization
    if personalized:
        narrative = _narrative(comp, profile.target_roles)
        synthesis = _synthesis(comp, narrative)
        speakable = narrative
    else:
        synthesis = None
        speakable = ("以下是各项目的客观对比(已关闭个性化)。请按你的具体目标自行权衡;"
                     "对比基于公开整理数据,不构成排名。")
    if not profile.target_roles:
        speakable = ("你还没有设定目标岗位,以下是各项目的客观对比,"
                     "设定目标后我可以给出更贴合你的建议。")

    return AgentResponse(
        status="ok",
        answer_type="advisory",  # synthesis, not official policy
        speakable=speakable,
        data={
            "dimensions": comp.dimensions,
            "facts_table": _facts_table(comp),
            "synthesis": synthesis,                 # None when opted out
            "disclaimer": comp.disclaimer,          # always present (compliance)
            "personalized": personalized,
        },
        sources=["programs_dataset"],
    )
