"""#7 Navigator Agent entry point.

Recommends modules for a target role and surfaces skill gaps. The rule engine
decides modules and gaps; the LLM only writes the `explanation` of why.
"""
from __future__ import annotations

from common import llm
from common.envelope import AgentResponse
from common.profile import UserProfile

from .engine import (
    build_candidates, guide_for_role, pick_primary_role, select_modules,
    unrecognized_completed,
)
from .planner import graduation_progress, prereq_warnings, what_if_pathways

_SYSTEM = (
    "You advise a Master's student on module choices for a target job role. "
    "Explain in 2-3 plain sentences why the selected modules fit and which gap "
    "to prioritise. Do not invent modules."
)


def handle(profile: UserProfile, slots: dict | None = None) -> AgentResponse:
    slots = slots or {}
    role = pick_primary_role(profile, slots)
    if role is None:
        return AgentResponse.needs(
            ["target_roles"],
            "请告诉我你的目标岗位(例如金融科技产品经理、量化风险等),我才能推荐合适的模块。",
        )

    g = guide_for_role(profile, role)
    personalized = profile.consent_flags.personalization
    skill_gaps_labels = g.skill_gap_labels if personalized else []

    candidates = build_candidates(profile, role)
    selected, rationale, source = select_modules(
        candidates, g.skill_gaps, n=4, personalized=personalized
    )
    selected_codes = [m["code"] for m in selected]

    warnings = [
        {"code": w.code, "missing": w.missing}
        for w in prereq_warnings(selected_codes, profile.completed_modules)
        if not w.satisfied
    ]
    progress = graduation_progress(profile.completed_modules, selected_codes)
    plans = what_if_pathways(selected_codes)
    unknown = unrecognized_completed(profile.completed_modules)

    module_names = "、".join(m["name"] for m in selected) or "(暂无可推荐模块)"
    gap_text = "、".join(skill_gaps_labels) if skill_gaps_labels else "无明显技能缺口"
    fallback = (
        f"针对「{g.title}」,建议优先选修:{module_names}。"
        f"你当前需要补强的方向:{gap_text}。"
    )
    if source == "llm":
        explanation = rationale
    else:
        explanation = llm.explain(
            _SYSTEM,
            f"Target role: {g.title}\nSelected modules: {module_names}\n"
            f"Skill gaps: {', '.join(skill_gaps_labels) or 'none'}",
            fallback,
        )
    speakable = explanation
    if warnings:
        speakable += f" 注意:有 {len(warnings)} 门模块的先修课你尚未修读。"
    if unknown:
        speakable += f" 另外:有 {len(unknown)} 个已修代码无法识别,请核对。"

    return AgentResponse(
        status="ok",
        answer_type="recommendation",
        speakable=speakable,
        data={
            "target_role": g.role,
            "recommended": selected,
            "already_completed": g.already_completed,
            "candidate_count": len(candidates),
            "skill_gaps": skill_gaps_labels,
            "personalized": personalized,
            "explanation": explanation,
            "selection_source": source,
            "prereq_warnings": warnings,
            "graduation_progress": progress,
            "study_plans": plans,
            "unrecognized_completed": unknown,
        },
        sources=["role_module_map", "module_skills", "module_catalog"],
    )


_CAREER_SYSTEM = (
    "You give a Master's student career-path guidance for a target role. In 2-3 "
    "plain sentences: name the role's key skills, what they already have, the gap "
    "to prioritise, and which modules help close it. Do not invent modules."
)


def career(profile: UserProfile, slots: dict | None = None) -> AgentResponse:
    slots = slots or {}
    role = pick_primary_role(profile, slots)
    if role is None:
        return AgentResponse.needs(
            ["target_roles"],
            "请告诉我你的目标岗位,我才能给出职业路径与技能建议。",
        )

    g = guide_for_role(profile, role)
    personalized = profile.consent_flags.personalization
    gap_labels = g.skill_gap_labels if personalized else []

    candidates = build_candidates(profile, role)
    gap_closing = [c for c in candidates if c["closes_gaps"]] if personalized else []
    selected, rationale, source = select_modules(
        gap_closing or candidates, g.skill_gaps, n=4, personalized=personalized
    )
    unknown = unrecognized_completed(profile.completed_modules)

    names = "、".join(m["name"] for m in selected) or "(暂无)"
    gap_text = "、".join(gap_labels) if gap_labels else "无明显技能缺口"
    fallback = (
        f"目标「{g.title}」的关键技能:{'、'.join(g.required_skills)}。"
        f"你需优先补强:{gap_text};可通过选修 {names} 来补足。"
    )
    explanation = rationale if source == "llm" else llm.explain(
        _CAREER_SYSTEM,
        f"Role: {g.title}\nRequired: {', '.join(g.required_skills)}\n"
        f"Has: {', '.join(g.matched_skills) or 'few'}\nGaps: {', '.join(gap_labels) or 'none'}\n"
        f"Gap-closing modules: {names}",
        fallback,
    )

    return AgentResponse(
        status="ok",
        answer_type="recommendation",
        speakable=explanation,
        data={
            "target_role": g.role,
            "required_skills": g.required_skills,
            "matched_skills": g.matched_skills,
            "skills_from_courses": g.skills_from_courses,
            "skill_gaps": gap_labels,
            "gap_closing_modules": selected,
            "personalized": personalized,
            "explanation": explanation,
            "selection_source": source,
            "unrecognized_completed": unknown,
        },
        sources=["role_module_map", "module_skills"],
    )
