@echo off
chcp 65001 >nul
cd /d "%~dp0"
title MSc DFT Assistant Launcher

rem Prefer the Windows py launcher. Fall back to python if py is unavailable.
set "PY=py"
%PY% -V >nul 2>&1
if errorlevel 1 set "PY=python"
%PY% -V >nul 2>&1
if errorlevel 1 (
    echo Python was not found. Please install Python 3.9+ and tick "Add Python to PATH".
    pause
    exit /b 1
)

:menu
cls
echo ============================================
echo    MSc DFT Assistant - Launcher
echo ============================================
echo.
echo   1. Install dependencies (first run)
echo   2. Run agent demo            (no API key)
echo   3. Student Web UI            (set key in browser /settings)
echo   4. Admin: edit data - CLI    (needs API key)
echo   5. Admin: edit data - Web UI (set key in browser /settings)
echo   6. Refresh data (catalog)    (no API key)
echo   7. Run tests
echo   0. Exit
echo.
set /p choice="Select an option: "

if "%choice%"=="1" goto deps
if "%choice%"=="2" goto demo
if "%choice%"=="3" goto student
if "%choice%"=="4" goto cli
if "%choice%"=="5" goto web
if "%choice%"=="6" goto refresh
if "%choice%"=="7" goto tests
if "%choice%"=="0" goto end
echo Invalid choice.
pause
goto menu

:deps
echo.
echo Installing dependencies with %PY% ...
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
echo.
echo Done.
pause
goto menu

:demo
echo.
%PY% run.py --list-profiles
echo.
set /p cmd="Command (checklist/status/reminders/compare/courses/career): "
set /p pid="Profile id (1/2/3/4/5): "
echo.
%PY% run.py %cmd% --profile %pid%
echo.
pause
goto menu

:student
echo.
echo Checking student web app dependencies...
%PY% -c "import flask, docx, pdfplumber; from student.webapp import app; print('Student Web UI is ready.')"
if errorlevel 1 (
    echo.
    echo Student Web UI failed to start. Please choose option 1 to install dependencies first.
    echo If it still fails, copy the error message above.
    pause
    goto menu
)
echo.
echo Starting student app at http://127.0.0.1:5001
echo Do NOT close this window while using the browser page.
echo Press Ctrl+C in this window to stop the server.
echo.
start "" "http://127.0.0.1:5001"
%PY% -m student.webapp
echo.
echo Student app stopped.
pause
goto menu

:cli
call :checkkey
echo.
%PY% -m admin.author --list
echo.
set /p tgt="Target (status_translations/admissions_rules): "
set /p adm="Your name (for audit): "
set /p ins="Instruction (natural language): "
%PY% -m admin.author %tgt% --admin "%adm%" --instruction "%ins%"
echo.
pause
goto menu

:web
echo.
echo Checking admin web app dependencies...
%PY% -c "import flask; from admin.webapp import app; print('Admin Web UI is ready.')"
if errorlevel 1 (
    echo.
    echo Admin Web UI failed to start. Please choose option 1 to install dependencies first.
    pause
    goto menu
)
echo.
echo Starting admin web server at http://127.0.0.1:5000
echo Do NOT close this window while using the browser page.
echo Press Ctrl+C in this window to stop the server.
echo.
start "" "http://127.0.0.1:5000"
%PY% -m admin.webapp
echo.
echo Admin app stopped.
pause
goto menu

:refresh
echo.
%PY% -m refresh.run module_catalog
echo.
echo (Items needing review: %PY% -m refresh.run --list-pending)
echo.
pause
goto menu

:tests
echo.
%PY% -m pytest tests/ -q
echo.
pause
goto menu

:checkkey
if "%DEEPSEEK_API_KEY%"=="" (
    set /p DEEPSEEK_API_KEY="Enter your DeepSeek API key: "
)
if "%DEEPSEEK_MODEL%"=="" set DEEPSEEK_MODEL=deepseek-v4-pro
exit /b

:end
echo Bye.
