# 变更历史 / Changelog

> 本项目(MSc DFT Assistant 模块 #4–#7)所有显著变动都记录在此,**倒序排列**(最新在上)。
> 每条格式:`YYYY-MM-DD · 范围 · 摘要`。范围标签:`#4/#5/#6/#7`(对应 agent)、`A/B/C/D`(研究方向)、`infra`(基础设施/文档/工具)。
> 配套权威总览见 [docs/00-project-overview.md](docs/00-project-overview.md)。每次变动请同步更新总览受影响小节。

格式参考 [Keep a Changelog](https://keepachangelog.com/);本项目尚未发布版本号,按日期累积。

---

## [Unreleased]

### 2026-06-08 (8)
- **#7 · Navigator 代码审查修复**:最终整体审查(opus,审校验护栏/降级/consent-公平性)。审查确认护栏拦得住编造(无绕过)、降级安全离线、公平性 OK;修了一个 **IMPORTANT consent 泄露**:opt-out 时原始技能缺口仍会进入 LLM 选课 prompt 发往外部端点(输出已脱敏但 prompt 未脱敏)→ `select_modules` 加 `personalized` 参数,opt-out 时**完全不调 LLM**(走规则,缺口不出系统);`career` 同步在 opt-out 时不按缺口过滤。补测试:opt-out 时原始缺口 `product` 绝不出现在任何 LLM prompt、opt-in 时出现(证明门控非空操作)。MINOR:`_parse_selected_codes` 兼容 `;`/标点包裹的 code;`prereq_warnings` 已修代码大小写归一(与其余路径一致)。全套 267 passed;eval 12/12。

### 2026-06-08 (7)
- **#7 · Navigator 进度感知 + LLM 受约束选课(已落地)**:新增 `data/module_skills.json`(模块→技能,一份两用)。`guide_for_role` 用已修课程缩小技能缺口 + 标注已修(A/D);`build_candidates`(岗位课 ∪ 按缺口纳入,排除已修)+ `rank_candidates`(确定性)+ `select_modules`(**LLM 只在候选内挑选/排序,编造代码丢弃,无 key/离线/全无效走规则兜底,`selection_source` 透出;永不输出不存在的模块**)(F);`graduation_progress` 不重复计已修、课表只排待修(B);新 `career` handler + supervisor 路由 `recommend_career_path`(C);已修代码软校验 `unrecognized_completed`(E);在读学生 demo profile 6;学生页渲染待修/已修/未识别 + 推荐方式。契约 §4#7 + 设计 10 更新。全套 266 passed;eval.runner 12/12。

### 2026-06-08 (6)
- **#7/C · SkillMatcher 优雅降级修复**:`EmbeddingSkillMatcher` 之前在推理时(`infer_user_skills`/`recommend_modules`)直接调 embedding 端点、端点不可达就抛 `APIConnectionError`,导致 `run.py courses/career` 等所有用 `get_skill_matcher()` 的路径崩溃(违背项目「离线可跑」原则)。改为:缓存构建失败→空缓存;推理时 embed 失败或无缓存→自动降级到 `RuleSkillMatcher`。补 monkeypatch 降级测试。全套 266 passed。

### 2026-06-08 (5)
- **infra · README 补「配置 SMTP 真发邮件」**:面向队友的 SMTP 配置说明(env / `data/.smtp.json`、465-SSL vs 587-STARTTLS 规则、163/QQ/Gmail/Outlook 对照表、个人 outlook.com 已禁用基础认证的提醒、一行验证命令)。
- **#5 · `run.py smtp-test` 子命令**:一键发测试邮件验证 SMTP(默认发给配置的 from 地址,`--to` 可指定收件人);未配置时给出友好提示并指向 README,不报错。`SENT: True/False` + 失败排查提示。实测 163/465 SENT: True。
- **#5 · Notifier 加隐式 SSL(465)支持**:`SmtpEmailNotifier` 现按端口分流——`465` 用 `smtplib.SMTP_SSL`(隐式 SSL,不调 starttls),其余端口(如 587)仍 plain SMTP + STARTTLS。为接 163/QQ 等只开 465 SSL 的服务商所需(Outlook 个人账户已禁用 SMTP 基础认证,改用 163)。补 monkeypatch 测试覆盖 465 路径。全套 247 passed + 1 skipped。

### 2026-06-08 (4)
- **#5 · Tracker 通知引擎(已落地,真发邮件)**:把 #5 做成真正的主动通知引擎。
  - **配置偏好** `configure_reminders` intent:改 channels/frequency/按里程碑静音(mute/unmute),非法值打回 `need_clarification`;supervisor 路由该 intent → `tracker.configure`。
  - **投递模型**:`due_now`(按 reminder key 去重 vs `notification_log` + 频率分支 off/immediate/`daily_digest` 合并)+ `dispatch_due`(真发 + 写 log,digest 记子 key→跨频率只发一次,失败标 `delivered=False` 不断流程)。`handle` 加只读 `due_now` 预览(不写 log)。
  - **真发邮件**:可插拔 `common/notifier.py`(`RecordingNotifier` 离线默认 + `SmtpEmailNotifier` stdlib smtplib + `get_notifier()` 按 `config.smtp_configured()` 选);SMTP 凭据走 `common/config.py`(env > `data/.smtp.json`,已 gitignore);conftest 隔离 SMTP 凭据 → 测试始终离线(monkeypatch `smtplib.SMTP`)。
  - **schema**:`UserProfile.email`/`notification_log`/`NotificationPrefs.muted_milestones`/`NotificationRecord`。mock_data 给 profile 4/5 加 email;`run.py notify` 演示(预览→投递→去重为空)。
  - 契约 §4#5 更新(due_now + configure_reminders);设计 08 标注 v3。全套 **246 passed + 1 skipped**;eval.runner 12/12。spec [link](docs/superpowers/specs/2026-06-08-tracker-notification-engine-design.md) · plan [link](docs/superpowers/plans/2026-06-08-tracker-notification-engine.md)。

### 2026-06-08 (3)
- **D · #6 Comparator v3 代码审查修复**:最终整体代码审查(opus)发现并修复:① **防排名护栏 plural 绕过**(`engine.py` `_RANKING_PATTERNS`:`best (?:program|programme|option|choice|school)` 因尾随 `\b` 漏掉 `programmes`/`programs` 等复数;`top (?:program|programme)` 同理)→ 改为可选 `s?`,补复数测试用例;② **`更好` 误伤**(`更好地契合/更好地规划` 等贴合表述被错误拦截)→ 改 `更好(?!地)`,补允许用例。文档准确性:`facts_table` 含全部展示维度(每格带 `kind`,synthesis 不带来源)——同步 spec §5.1 与契约 §4#6 措辞。MINOR:`admin/schemas.py` `role_strengths` 标注为 legacy/引擎不读;学生页权重从原始 dict 改为百分比展示。全套 220 passed + 1 skipped。

### 2026-06-08 (2)
- **D · #6 Comparator v3(已落地)**:三态 cell(`verified`/`unknown`/`synthesis`)+ `_normalize_cell`/`_row_facts`/`_verified_text` 规范化(裸字符串=verified 继承行级来源;unknown/synthesis 不带来源;非法 kind 降级 verified)。展示维度扩到 11(含 PDF 的 `typical_profile`/`industry_orientation`/`technical_depth`/`career_pathways`,NTU 费用/intake/奖学金 + HKUST gmat_gre 标 unknown)。`compare()` 每行结构两分 `facts`↔`synthesis`,**评分只读 verified 的 3 信号**(role_fit/cost/duration),主观维度不打分。`violates_ranking` 确定性防排名护栏(narrative 命中即回退安全模板)。envelope 两区 `data.facts_table` + `data.synthesis`(opt-out 时 synthesis=`null`),`disclaimer` 恒在。学生页两区渲染(每格带 kind 标记 + 来源链接 + 独立「AI 综合分析」块)。schema(`admin/schemas.py`)接受三态 cell;契约 §4#6 更新;`09` 标注被 v3 取代。回归:supervisor/student 调用方已对齐新形状。全套 **220 passed + 1 skipped**;eval.runner 12/12。spec [link](docs/superpowers/specs/2026-06-08-comparator-fact-synthesis-design.md) · plan [link](docs/superpowers/plans/2026-06-08-comparator-fact-synthesis.md)。

### 2026-06-08
- **infra · 文档体系**:新增唯一权威入口 [docs/00-project-overview.md](docs/00-project-overview.md)(汇总 #4–#7 全貌、架构、数据资产、A/B/C/D 状态、运行方式、文档地图)与本 `CHANGELOG.md`;配 `.claude/settings.json` PostToolUse hook,改动源码目录后提醒更新两份文档。
- **D · #6 Comparator v3(设计)**:brainstorm 定稿,写入 [spec](docs/superpowers/specs/2026-06-08-comparator-fact-synthesis-design.md)。方向:展示维度扩到 PDF 8 维;每格 cell 三态 `verified/unknown/synthesis`;评分维度保持 3 个可辩护信号(role_fit/cost/duration),主观维度不打数值分;engine 输出结构上分离 facts↔synthesis;新增确定性防排名护栏。**尚未实现代码**。

### 2026-06-07
- **C · 个性化 taxonomy + 公平性(已落地,7 子任务)**:`data/skill_taxonomy.json`(9 技能,ESCO/O*NET)+ `common/skill_matcher.py`(`SkillMatcher` 接口 + `RuleSkillMatcher` + `EmbeddingSkillMatcher` 指纹缓存 + 工厂);`eval/skill_calibrate.py` 实证背景→技能 规则 f1=1.0 vs embedding 0.685;`data/match_thresholds.json` 按后端;navigator 接入 matcher + consent gate + 公平性(排除 country)不变量;comparator 加 consent gate + 文档。全套 205 passed + 1 skipped。设计 [13](docs/13-personalization-fairness-design.md)。
- **A · RAG 检索 + 阈值校准(接真 embedding)**:winget 装 Ollama + `nomic-embed-text`(768 维本地);embedding 配置与 chat 解耦;BM25 vs embedding 对比(n=13:BM25 acc 1.0 / embedding 0.92);`data/thresholds.json` 按后端两套阈值,`supervisor` 按 retriever 类型自动选,政策类安全转人工。
- **A · RAG 检索 + 阈值校准(底座)**:`common/knowledge.py` + `data/knowledge/*.jsonl`(curated KB);`common/retriever.py`(`Retriever` 接口 + `BM25Retriever` IDF 加权覆盖度 + `EmbeddingRetriever` + 工厂);`eval/calibrate.py` 网格校准写 `data/thresholds.json`;`confidence.decide` 读取。设计 [12](docs/12-rag-calibration-design.md)。
- **B · 质量评估框架(已落地最小版)**:`eval/metrics.py`(集合 P/R/F1)+ `eval/runner.py`(读 cases→跑确定性引擎→记分卡,`python -m eval.runner [--json]`)+ `eval/cases/{checklist,navigator}.json`(金标按规则独立推断)。基线 12/12 作为回归门。

---

## 历史基线(本 changelog 建立前已存在)

工程层已完整:四个 agent(确定性规则引擎 + LLM 叙述)、统一 `UserProfile`/`AgentResponse` 契约、RAG 置信门控、admin 自然语言录入(校验/归档/审计/回滚)、分级刷新管线(NUSMods 真实数据)、学生端/管理端 Web。详见 [docs/00-project-overview.md](docs/00-project-overview.md) 与各分设计文档 01–10。
