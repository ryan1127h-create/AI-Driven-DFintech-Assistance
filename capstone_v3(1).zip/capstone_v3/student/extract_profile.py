"""Extract applicant profile fields from natural language or an uploaded CV.

Two steps:
  parse_file()    .docx / .pdf bytes -> plain text
  extract_fields() free text -> form-field dict via DeepSeek (values constrained
                   to the same enums the form uses; invalid values dropped)

The extracted dict pre-fills the review form; the student confirms/edits before
agents run. DeepSeek is required for this path (raises if no API key).
"""
from __future__ import annotations

import io
import json
import os

from common import config
from common.profile import (
    ApplicationType,
    DegreeLevel,
    FieldOfStudy,
    LifecycleStage,
    Proficiency,
    TargetRole,
)
from .profile_form import COMMON_DOCS

ALLOWED_EXTENSIONS = {".docx", ".pdf"}
MAX_BYTES = 5 * 1024 * 1024  # 5 MB

# Allowed values per field (single-value unless noted as list).
_ALLOWED = {
    "lifecycle_stage": {"applicant", "current"},
    "degree_level": {e.value for e in DegreeLevel},
    "field_of_study": {e.value for e in FieldOfStudy},
    "technical_proficiency": {e.value for e in Proficiency},
    "finance_knowledge": {e.value for e in Proficiency},
    "application_type": {e.value for e in ApplicationType},
}
_ALLOWED_LIST = {
    "target_roles": {e.value for e in TargetRole},
    "submitted_documents": set(COMMON_DOCS),
}


class ProfileExtractionError(RuntimeError):
    pass


# ---------- file parsing ----------
def parse_file(filename: str, data: bytes) -> str:
    """Extract plain text from an uploaded .docx or .pdf. Raises on bad input."""
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ProfileExtractionError(f"不支持的文件类型: {ext}(仅支持 .docx / .pdf)")
    if len(data) > MAX_BYTES:
        raise ProfileExtractionError("文件过大(上限 5MB)")

    if ext == ".docx":
        from docx import Document

        doc = Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())

    # .pdf
    import pdfplumber

    with pdfplumber.open(io.BytesIO(data)) as pdf:
        pages = [(p.extract_text() or "") for p in pdf.pages]
    return "\n".join(pages).strip()


# ---------- LLM extraction ----------
_SYSTEM = (
    "You extract a graduate-school applicant's profile from free text or a CV. "
    "Return ONLY a JSON object with these keys (omit a key if unknown):\n"
    "lifecycle_stage (applicant|current), degree_level "
    "(high_school|bachelor|master|phd), field_of_study (computer_science|finance|"
    "economics|engineering|mathematics|business|other), work_years (integer), "
    "country (ISO 3166-1 alpha-2, e.g. SG), technical_proficiency/finance_knowledge "
    "(none|basic|intermediate|advanced), target_roles (array of: fintech_pm|"
    "quant_risk|digital_banking|payments|compliance_regtech|data_analytics), "
    "application_type (full_time|part_time), submitted_documents (array of valid "
    "application material keys such as personal_statement|cv|proof_of_residence|"
    "degree_certificate|transcript). Use ONLY the allowed "
    "values. Do not invent facts. Output valid JSON only."
)


def _client():
    if not config.is_configured():
        raise ProfileExtractionError(
            "DeepSeek API key 未配置。请在 /settings 页面填写,或设置环境变量 "
            "DEEPSEEK_API_KEY。"
        )
    from openai import OpenAI

    return OpenAI(api_key=config.get_api_key(), base_url=config.get_base_url())


def coerce_fields(raw: dict) -> dict:
    """Keep only known fields with allowed values; coerce types. Pure function."""
    out: dict = {}
    for key, allowed in _ALLOWED.items():
        val = raw.get(key)
        if isinstance(val, str) and val in allowed:
            out[key] = val
    for key, allowed in _ALLOWED_LIST.items():
        vals = raw.get(key)
        if isinstance(vals, list):
            kept = [v for v in vals if isinstance(v, str) and v in allowed]
            if kept:
                out[key] = kept
    wy = raw.get("work_years")
    if isinstance(wy, int) and wy >= 0:
        out["work_years"] = wy
    elif isinstance(wy, str) and wy.strip().isdigit():
        out["work_years"] = int(wy.strip())
    country = raw.get("country")
    if isinstance(country, str) and len(country.strip()) == 2:
        out["country"] = country.strip().upper()
    return out


def extract_fields(text: str) -> dict:
    """Free text -> validated form-field dict via DeepSeek."""
    if not text or not text.strip():
        raise ProfileExtractionError("没有可提取的内容(文本为空)。")
    model = config.get_model()
    client = _client()
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": _SYSTEM},
                {"role": "user", "content": text[:8000]},
            ],
            temperature=0.0,
            response_format={"type": "json_object"},
        )
        content = resp.choices[0].message.content
    except Exception as e:
        raise ProfileExtractionError(f"DeepSeek 调用失败: {e}") from e
    if not content:
        raise ProfileExtractionError("DeepSeek 返回空内容")
    try:
        raw = json.loads(content)
    except json.JSONDecodeError as e:
        raise ProfileExtractionError(f"DeepSeek 返回的不是合法 JSON: {e}") from e
    return coerce_fields(raw)
