"""Build a UserProfile from student web-form input.

The student UI intentionally supports only two visible flows for the MVP:
applicant and current student.  Other lifecycle stages remain in the backend
schema for future teammates, but they are not shown in the student-facing form.

For applicants, uploaded application materials are converted into the
Application.submitted_documents/document_status fields so the #4/#5 agents can
make decisions from actual uploads rather than checkboxes.
"""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path
from uuid import uuid4
from dataclasses import dataclass
from typing import Mapping

from werkzeug.utils import secure_filename

from common.profile import (
    AcademicBackground,
    Application,
    ApplicationType,
    ConsentFlags,
    DegreeLevel,
    DocStatus,
    FieldOfStudy,
    LifecycleStage,
    Proficiency,
    StatusCode,
    TargetRole,
    UserProfile,
)

# Field metadata for rendering the form (label + options).
DEGREE_LEVELS = [e.value for e in DegreeLevel]
FIELDS_OF_STUDY = [e.value for e in FieldOfStudy]
PROFICIENCIES = [e.value for e in Proficiency]
APPLICATION_TYPES = [e.value for e in ApplicationType]
# Keep only the two flows requested for the student-facing MVP.
LIFECYCLE_STAGES = [LifecycleStage.applicant.value, LifecycleStage.current.value]
TARGET_ROLES = [e.value for e in TargetRole]

# Based on NUS MSc DFinTech online submission checklist.  The demo accepts Word
# and images in addition to PDF to make upload testing convenient, but the UI
# reminds applicants that the real Graduate Admission System requires PDF files.
APPLICATION_MATERIALS: list[dict[str, str]] = [
    {
        "key": "personal_statement",
        "label": "Personal Statement",
        "hint": "说明申请原因、准备情况、职业计划和相关背景。",
        "required": "required",
    },
    {
        "key": "cv",
        "label": "Curriculum Vitae / CV",
        "hint": "教育、实习/工作、项目、成就和技能摘要。",
        "required": "required",
    },
    {
        "key": "proof_of_residence",
        "label": "Proof of Residence / Passport / NRIC",
        "hint": "SC/PR 上传 NRIC 正反面；国际申请者上传护照及相关准证。",
        "required": "required",
    },
    {
        "key": "degree_certificate",
        "label": "Official Degree Certificate / Expected Graduation Letter",
        "hint": "已毕业者上传学位证；未毕业者上传预计毕业或完成证明。",
        "required": "required",
    },
    {
        "key": "transcript",
        "label": "Official Transcript(s)",
        "hint": "完整成绩单，需包含所有课程成绩；如有交换成绩单也应提供。",
        "required": "required",
    },
    {
        "key": "english_proficiency",
        "label": "TOEFL / IELTS Score Report",
        "hint": "如果本科/过往大学教育主要授课语言不是英语，则需要。",
        "required": "conditional",
    },
    {
        "key": "standardised_test_scores",
        "label": "GRE / GMAT / GATE Score Report",
        "hint": "官方资料说明 GMAT/GRE 不是强制项；如有成绩可作为支持材料上传。",
        "required": "supporting",
    },
    {
        "key": "referee_reports",
        "label": "Two Referee Reports / Referee Submission Evidence",
        "hint": "真实系统中填写推荐人邮箱，推荐人在线提交；这里可上传确认截图或说明。",
        "required": "required",
    },
    {
        "key": "financial_support",
        "label": "Financial Support Document",
        "hint": "银行流水、工资单或 sponsor letter；作为经济支持材料。",
        "required": "supporting",
    },
    {
        "key": "application_fee",
        "label": "Application Fee Payment Proof",
        "hint": "S$109 申请费付款截图或收据；真实系统以付款状态为准。",
        "required": "required",
    },
    {
        "key": "other_supporting_documents",
        "label": "Other Supporting Documents",
        "hint": "奖项、专业证书等，如适用。",
        "required": "supporting",
    },
]
COMMON_DOCS = [m["key"] for m in APPLICATION_MATERIALS]

MATERIAL_PREFIX = "material_"
ALLOWED_MATERIAL_EXTENSIONS = {".pdf", ".doc", ".docx", ".png", ".jpg", ".jpeg"}
MAX_MATERIAL_BYTES = 10 * 1024 * 1024
DEFAULT_APPLICATION_DEADLINE = "2026-01-31"


@dataclass
class UploadedMaterial:
    key: str
    label: str
    filename: str | None
    status: str  # submitted | missing | rejected
    reason: str
    size_bytes: int = 0
    view_url: str | None = None
    required: str = "required"


def _enum_or_none(enum_cls, raw: str):
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return enum_cls(raw)
    except ValueError:
        return None


def _int_or_none(raw: str):
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


def _getlist(form, key: str) -> list[str]:
    getlist = getattr(form, "getlist", lambda k: [])
    v = getlist(key)
    return v if isinstance(v, list) else [v]


def normalize_stage(raw: str | None) -> LifecycleStage:
    """Only applicant/current are exposed by the UI; default to applicant."""
    stage = _enum_or_none(LifecycleStage, raw or "")
    if stage == LifecycleStage.current:
        return LifecycleStage.current
    return LifecycleStage.applicant


def material_name(key: str) -> str:
    return f"{MATERIAL_PREFIX}{key}"


def analyse_uploaded_materials(files, stage: LifecycleStage, save_dir: str | Path | None = None,
                               token: str | None = None) -> list[UploadedMaterial]:
    """Turn material file inputs into evidence objects and optionally persist them.

    The MVP checks presence, extension and size.  Saved files are exposed through
    /uploads/<token>/<filename> so applicants can click and review what they uploaded.
    """
    if stage != LifecycleStage.applicant:
        return []
    files = files or {}
    results: list[UploadedMaterial] = []
    base = Path(save_dir) if save_dir else None
    if base and token:
        (base / token).mkdir(parents=True, exist_ok=True)
    for spec in APPLICATION_MATERIALS:
        key = spec["key"]
        label = spec["label"]
        required = spec.get("required", "required")
        upload = files.get(material_name(key)) if hasattr(files, "get") else None
        filename = getattr(upload, "filename", "") or ""
        if not filename:
            results.append(UploadedMaterial(key, label, None, "missing", "未上传", required=required))
            continue
        _, ext = os.path.splitext(filename.lower())
        if ext not in ALLOWED_MATERIAL_EXTENSIONS:
            results.append(
                UploadedMaterial(key, label, filename, "rejected", f"文件格式 {ext or '(无扩展名)'} 不支持", required=required)
            )
            continue
        size = 0
        stream = getattr(upload, "stream", None)
        if stream is not None:
            pos = stream.tell()
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(pos)
        if size > MAX_MATERIAL_BYTES:
            results.append(
                UploadedMaterial(key, label, filename, "rejected", "文件超过 10MB", required=required)
            )
            continue
        view_url = None
        if base and token:
            safe = secure_filename(filename) or f"{key}{ext}"
            stored_name = f"{key}__{safe}"
            target = base / token / stored_name
            try:
                if stream is not None:
                    stream.seek(0)
                upload.save(target)
                if stream is not None:
                    stream.seek(0)
                view_url = f"/uploads/{token}/{stored_name}"
            except Exception as exc:  # keep the UI honest if persistence fails
                results.append(UploadedMaterial(key, label, filename, "rejected", f"文件保存失败: {exc}", size, required=required))
                continue
        results.append(UploadedMaterial(key, label, filename, "submitted", "已上传，可点击查看", size, view_url=view_url, required=required))
    return results


def required_material_keys() -> set[str]:
    return {m["key"] for m in APPLICATION_MATERIALS if m.get("required") == "required"}


def material_summary(materials: list[UploadedMaterial]) -> dict:
    required = [m for m in materials if m.required == "required"]
    submitted = [m for m in required if m.status == "submitted"]
    missing = [m for m in required if m.status == "missing"]
    rejected = [m for m in required if m.status == "rejected"]
    return {
        "required_total": len(required),
        "submitted_required": len(submitted),
        "missing_required": len(missing),
        "rejected_required": len(rejected),
        "is_complete": bool(required) and not missing and not rejected,
    }


def build_profile(form, files=None, material_results: list[UploadedMaterial] | None = None) -> UserProfile:
    """form: Flask request.form-like mapping. files: optional request.files."""
    stage = normalize_stage(form.get("lifecycle_stage", ""))

    degree = _enum_or_none(DegreeLevel, form.get("degree_level", ""))
    field = _enum_or_none(FieldOfStudy, form.get("field_of_study", ""))
    academic = None
    if degree and field:
        academic = AcademicBackground(degree_level=degree, field_of_study=field)

    roles = []
    for r in _getlist(form, "target_roles"):
        role = _enum_or_none(TargetRole, r)
        if role:
            roles.append(role)

    completed_modules_raw = form.get("completed_modules", "") or ""
    completed_modules = [
        code.strip().upper()
        for code in completed_modules_raw.replace(";", ",").split(",")
        if code.strip()
    ]

    # Applicants: uploaded files are the source of truth for submitted materials.
    # Backward-compatible checkbox support is retained for tests/CLI demos.
    application = None
    if stage == LifecycleStage.applicant:
        material_results = material_results if material_results is not None else analyse_uploaded_materials(files, stage)
        uploaded = [m.key for m in material_results if m.status == "submitted"]
        rejected = [m.key for m in material_results if m.status == "rejected"]
        legacy_submitted = [d for d in _getlist(form, "submitted_documents") if d in COMMON_DOCS]
        submitted = sorted(set(uploaded + legacy_submitted))
        doc_status = {d: DocStatus.submitted for d in submitted}
        doc_status.update({d: DocStatus.rejected for d in rejected})
        required_keys = required_material_keys()
        required_ok = required_keys.issubset(set(submitted)) and not (required_keys & set(rejected))
        status_code = StatusCode.SUBMITTED if required_ok else StatusCode.DOCS_REQUIRED
        # Always create a mock application for the applicant web flow so #5 can
        # explain the status and outstanding items.  This is not the real NUS
        # Graduate Admission System status.
        application = Application(
            application_id="student_web_mock",
            status_code=status_code,
            submitted_documents=submitted,
            document_status=doc_status,
            deadlines={"application_deadline": DEFAULT_APPLICATION_DEADLINE},
            status_history=[
                {"status_code": StatusCode.SUBMITTED, "date": date.today().isoformat(), "note": "Demo submission created from uploaded materials"},
                {"status_code": status_code, "date": date.today().isoformat(), "note": "Mock admissions status generated by the capstone demo"},
            ],
        )

    return UserProfile(
        user_id="student_web",
        lifecycle_stage=stage,
        authenticated=True,
        academic_background=academic,
        # Current students do not need these fields for #7, so ignore if posted.
        work_years=_int_or_none(form.get("work_years", "")) if stage == LifecycleStage.applicant else None,
        country=(form.get("country", "").strip().upper() or None) if stage == LifecycleStage.applicant else None,
        technical_proficiency=_enum_or_none(Proficiency, form.get("technical_proficiency", "")),
        finance_knowledge=_enum_or_none(Proficiency, form.get("finance_knowledge", "")),
        target_roles=roles,
        application_type=_enum_or_none(ApplicationType, form.get("application_type", "")) if stage == LifecycleStage.applicant else None,
        completed_modules=completed_modules,
        application=application,
        consent_flags=ConsentFlags(personalization=True, reminders=True),
    )
