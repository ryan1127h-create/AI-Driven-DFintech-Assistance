#!/usr/bin/env bash
# PostToolUse(Write|Edit) hook — non-blocking reminder.
# When a source file under a tracked dir (agents/ common/ data/ refresh/ admin/
# student/ eval/) is modified, nudge to update CHANGELOG.md and the project
# overview. Editing docs/ or CHANGELOG.md itself does NOT trigger (avoids loops).
input=$(cat)

# Extract tool_input.file_path (first JSON "file_path":"..." occurrence).
fp=$(printf '%s' "$input" \
  | grep -oE '"file_path"[[:space:]]*:[[:space:]]*"[^"]*"' \
  | head -1 \
  | sed -E 's/.*:[[:space:]]*"//; s/"$//')
[ -z "$fp" ] && exit 0

# Normalize Windows backslashes (JSON-escaped \\ and bare \) to forward slashes.
norm=$(printf '%s' "$fp" | sed 's#\\\\#/#g; s#\\#/#g')

case "$norm" in
  */agents/*|*/common/*|*/data/*|*/refresh/*|*/admin/*|*/student/*|*/eval/*)
    cat <<'JSON'
{"systemMessage":"📝 源码已改:记得更新 CHANGELOG.md 与 docs/00-project-overview.md","hookSpecificOutput":{"hookEventName":"PostToolUse","additionalContext":"A project source file under agents/common/data/refresh/admin/student/eval was just modified. Per this project's convention, before finishing the task: (1) append a dated entry to CHANGELOG.md, and (2) update the affected section(s) of docs/00-project-overview.md (especially the §4 agent status table and §6 A/B/C/D status)."}}
JSON
    ;;
  *)
    exit 0
    ;;
esac
