"""CLI demo entry point.

Examples:
    python run.py checklist --profile 1
    python run.py status --profile 1
    python run.py compare --profile 2
    python run.py courses --profile 1
    python run.py notify --profile 5
    python run.py smtp-test               # send a real test email (needs SMTP configured)
    python run.py smtp-test --to you@example.com
    python run.py --list-profiles
"""
from __future__ import annotations

import argparse
import json
import sys

from common import mock_data

# command -> intent (contract §1.2)
_COMMANDS = {
    "checklist": "generate_application_checklist",
    "status": "get_application_status",
    "reminders": "configure_reminders",
    "compare": "compare_programs",
    "courses": "recommend_courses",
    "career": "recommend_career_path",
    "notify": None,  # direct demo — not routed through supervisor
    "smtp-test": None,  # send a real test email to verify SMTP config
}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="MSc DFT assistant — agent demo")
    parser.add_argument("command", nargs="?", choices=_COMMANDS, help="which agent to run")
    parser.add_argument("--profile", default="1", help="mock profile id (see --list-profiles)")
    parser.add_argument("--to", default=None, help="smtp-test recipient (default: configured from address)")
    parser.add_argument("--list-profiles", action="store_true")
    args = parser.parse_args(argv)

    if args.list_profiles or not args.command:
        print("Available mock profiles:")
        for pid in mock_data.all_profile_ids():
            p = mock_data.get_profile(pid)
            roles = ", ".join(r.value for r in p.target_roles)
            print(f"  {pid}: {p.lifecycle_stage.value:10s} roles=[{roles}]")
        if not args.command:
            print("\nUsage: python run.py <command> --profile <id>")
            print("commands:", ", ".join(_COMMANDS))
        return 0

    if args.command == "notify":
        from datetime import date
        from agents.tracker.reminders import due_now, dispatch_due

        profile = mock_data.get_profile(args.profile)
        today = date(2026, 6, 5)
        print("== 待发提醒(预览)==")
        for n in due_now(profile, today=today):
            print(f"[{n.urgency}] {n.subject} -> {n.channels}: {n.message}")
        print("== 投递(未配 SMTP 时为 record-only)==")
        sent = dispatch_due(profile, today=today)
        print(f"已投递 {len(sent)} 条;notification_log 现有 {len(profile.notification_log)} 条记录")
        print("== 再次预览(投递+去重后应为空)==")
        remaining = due_now(profile, today=today)
        print(remaining if remaining else "（无,已全部发送并去重）")
        return 0

    if args.command == "smtp-test":
        from common import config
        from common.notifier import SmtpEmailNotifier

        if not config.smtp_configured():
            print("SMTP 未配置(当前为 record-only,不会真发)。")
            print("请设置 SMTP_HOST / SMTP_USERNAME / SMTP_PASSWORD(环境变量或 data/.smtp.json)。")
            print("配置方法见 README「配置 SMTP 真发邮件」。")
            return 1
        to = args.to or config.get_smtp_from() or config.get_smtp_username()
        print(f"发送测试邮件 -> {to}  (host={config.get_smtp_host()} port={config.get_smtp_port()}) ...")
        ok = SmtpEmailNotifier().send(
            to, "MSc DFT 助手 - SMTP 测试", "这是一封测试邮件,收到即表示真发邮件已打通。"
        )
        print("SENT:", ok)
        if not ok:
            print("发送失败:检查授权码/host/端口(163/QQ 用 465;Gmail/Outlook 企业版用 587)。详见 README。")
        return 0 if ok else 1

    from supervisor import route

    profile = mock_data.get_profile(args.profile)
    resp = route(_COMMANDS[args.command], profile)

    print(f"\n=== {args.command} | profile {args.profile} ===")
    print("speakable:", resp.speakable)
    print("status:", resp.status, "| answer_type:", resp.answer_type)
    print("data:", json.dumps(resp.data, ensure_ascii=False, indent=2))
    if resp.escalation:
        print("escalation:", resp.escalation.model_dump_json(indent=2))
    if resp.missing_fields:
        print("missing_fields:", resp.missing_fields)
    return 0


if __name__ == "__main__":
    sys.exit(main())
