# React UI version

This folder contains a React/Vite conversion of the student and admin UI. It is written in JSX components and uses the same design system CSS as the Flask version.

## Run locally

```bash
cd frontend_react
npm install
npm run dev
```

## Notes

- The existing Flask/Jinja templates were also translated to English, so `python -m student.webapp` and `python -m admin.webapp` still work.
- This React layer is frontend-ready and uses sample data for result rendering. To make it fully API-driven, expose JSON endpoints from the Flask backend for `/extract`, `/advise`, `/generate`, `/apply`, `/history`, and `/settings`, then replace the local sample data calls in `src/App.jsx` with `fetch()`.
- Forms keep the original backend route names as comments/intent references so integration remains straightforward.
