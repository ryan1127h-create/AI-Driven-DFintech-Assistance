import { Panel } from "../components/Shell.jsx";

export function AdminDashboard() {
  return (
    <>
      <div className="page-head reveal"><h1>Edit data using natural language</h1><p>Describe the data change. The assistant generates a draft, validates it, and writes only after staff confirmation.</p></div>
      <form className="panel reveal"><label>Select data to edit</label><select><option>status_translations — risk low</option><option>admissions_rules — risk high</option></select><label>Operator name</label><input type="text" placeholder="e.g. alice" /><label>Natural-language edit instruction</label><textarea placeholder="Example: Change the next step for OFFER status to ‘Please confirm acceptance within 7 days.’" /><div style={{ marginTop: 18 }}><button type="button" className="btn">Generate draft →</button></div></form>
      <Panel><div className="panel__head"><span className="muted">View change history or roll back to an older version</span><a href="#/admin/history">History / rollback →</a></div></Panel>
    </>
  );
}

export function AdminHistory() {
  return (
    <><div className="page-head reveal"><h1>Version rollback</h1><p>Restore archived data versions and keep a clear audit trail.</p></div><Panel title="Archived versions by data file"><ul className="items"><li className="item"><div className="item__row" style={{ justifyContent: "space-between" }}><span>status_translations · 2026-05-31 05:22</span><button className="btn btn--ghost">Roll back to this version</button></div></li></ul></Panel><Panel title="Audit log"><pre>2026-06-01 [edit] status_translations by alice ✓</pre></Panel></>
  );
}
