import { Steps } from "../components/Shell.jsx";

export function StudentResults({ data, onEdit }) {
  const p = data.progress;
  const completedPct = Math.round((p.completed / p.required) * 100);
  const totalPct = Math.min(100, Math.round(((p.completed + p.planned) / p.required) * 100));
  const plannedPct = Math.max(0, totalPct - completedPct);
  const isStudent = data.profileType === "current";
  return (
    <>
      <Steps current={3} />
      <div className="page-head reveal"><h1>{isStudent ? "Current student analysis results" : "Applicant analysis results"}</h1><p>The system generated guidance from the submitted profile and materials in this session.</p></div>
      <button type="button" className="backlink" onClick={onEdit}>← Edit information and regenerate</button>
      <div className="results-layout">
        <nav className="anchor-nav" aria-label="Result sections">
          {!isStudent && <a href="#materials">📎 Material analysis</a>}
          {!isStudent && <a href="#checklist">📋 Application checklist</a>}
          {!isStudent && <a href="#compare">⚖️ Programme comparison</a>}
          <a href="#courses">🎓 Courses and pathway</a>
        </nav>
        <div>
          {!isStudent && <section id="materials" className="panel reveal"><div className="panel__head"><h2 className="panel__title">📎 Current material analysis</h2></div><div className="summary-strip"><div><strong>{data.materialSummary.submittedRequired} / {data.materialSummary.requiredTotal}</strong><span>required materials uploaded</span></div><div><strong>{data.materialSummary.missingRequired}</strong><span>missing</span></div><div><strong>{data.materialSummary.rejectedRequired}</strong><span>invalid format/size</span></div><div><strong>{data.materialSummary.isComplete ? "Complete" : "Incomplete"}</strong><span>system material check</span></div></div><ul className="items">{data.materials.map((m) => <li className="item" key={m.key}><div className="item__row"><span className="item__label">{m.label}</span><span className={`pill ${m.status === "uploaded" ? "pill--ok" : "pill--mute"}`}>{m.status}</span></div><div className="why">{m.reason}</div></li>)}</ul></section>}
          {!isStudent && <section id="checklist" className="panel reveal"><div className="panel__head"><h2 className="panel__title">📋 Application checklist</h2></div><ul className="items">{data.checklist.map((item) => <li className="item" key={item.label}><div className="item__row"><span className="item__label">{item.label}</span><span className="pill pill--danger">{item.required ? "Required" : "Supporting"}</span><span className="pill pill--mute">{item.status}</span></div><div className="why">{item.why}</div></li>)}</ul></section>}
          {!isStudent && <section id="compare" className="panel reveal"><div className="panel__head"><h2 className="panel__title">⚖️ Programme comparison</h2></div><div className="table-scroll"><table><thead><tr><th>Programme</th><th>Duration</th><th>Fees</th><th>Format</th><th>Source</th></tr></thead><tbody>{data.comparison.map((row) => <tr className={row.is_target ? "is-target-row" : ""} key={row.program}><td className={row.is_target ? "is-target" : ""}>{row.program}{row.is_target ? " ★" : ""}</td><td>{row.duration}</td><td>{row.fees}</td><td>{row.format}</td><td><a href={row.source_url} target="_blank" rel="noopener">Official page ↗</a><br /><span className="why">As of {row.fetched_at}</span></td></tr>)}</tbody></table></div><div className="note" style={{ marginTop: 12 }}>Official source links are shown per programme. The comparison is a decision-support view, not a ranking.</div></section>}
          {!isStudent && <section id="tracker" className="panel reveal"><div className="panel__head"><h2 className="panel__title">🔎 Application status</h2><span className="pill pill--warn">Demo / Mock Status</span></div><label>Application timeline</label><ol className="timeline">{data.timeline.map((step) => <li className={`timeline__item timeline__item--${step.state}`} key={step.label}><span className="timeline__dot" /><span>{step.label}</span><em>{step.state}</em></li>)}</ol></section>}
          <section id="courses" className="panel reveal"><div className="panel__head"><h2 className="panel__title">🎓 Course and skill direction advice</h2></div>{data.completedCodes.length ? <p className="why">Completed modules detected: {data.completedCodes.join(", ")}</p> : <p className="why">No completed modules were entered, so the plan starts from 0 completed Units.</p>}<label>Recommended modules</label><ul className="items">{data.recommended.map((mod) => <li className="item" key={mod.code}><div className="item__row"><span className="item__label"><strong>{mod.code}</strong> {mod.name}</span><span className="pill pill--mute">{mod.credits} Units</span>{mod.source_url && <a href={mod.source_url} target="_blank" rel="noopener" className="why">Course source ↗</a>}</div></li>)}</ul><label>Skills to strengthen</label><div className="checks">{data.skillGaps.map((gap) => <span className="pill pill--warn" key={gap}>{gap}</span>)}</div><label>Graduation credit progress <span className="muted">{p.completed} / {p.required} Units completed</span></label><div className="progress progress--stack"><div className="progress__bar progress__bar--completed" style={{ width: `${completedPct}%` }} /><div className="progress__bar progress__bar--planned" style={{ width: `${plannedPct}%` }} /></div><div className="progress-legend"><span><i className="legend-dot legend-dot--completed" />Completed: {p.completed} Units</span><span><i className="legend-dot legend-dot--planned" />Recommended plan: +{p.planned} Units</span><span>Remaining after plan: {p.remaining} Units</span></div><div className="why">The headline progress only counts completed credits. The green segment shows recommended future modules for planning.</div></section>
        </div>
      </div>
    </>
  );
}
