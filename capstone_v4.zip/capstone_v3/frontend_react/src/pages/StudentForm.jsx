import { applicationTypes, degreeLevels, fields, materials, proficiencies, roles } from "../data/options.js";
import { Panel, Steps } from "../components/Shell.jsx";

export function StudentForm({ profileType = "applicant", prefill = {}, onSubmit }) {
  const isStudent = profileType === "current";
  const hasExtracted = Object.keys(prefill).some((key) => !key.startsWith("_") && prefill[key]);
  return (
    <>
      <Steps current={2} />
      <div className="page-head reveal">
        <h1>{isStudent ? "Current student profile confirmation" : "Applicant profile confirmation"}</h1>
        <p>{isStudent ? "Application fields and material uploads are locked. Add background, completed modules, and career goals." : "Confirm your background, goals, and actual uploaded materials. Missing items are checked from files, not checkbox assumptions."}</p>
      </div>
      <Panel title="Extracted profile review">
        {prefill._cv_name && <div className="note" style={{ marginBottom: 10 }}>CV selected in Step 1: <strong>{prefill._cv_name}</strong>. The standalone React preview keeps the filename; the Flask app performs full PDF/Word parsing.</div>}
        {hasExtracted ? (
          <>
            <div className="note note--info">Detected fields were copied into the editable form below. Please review them before generating the analysis.</div>
            <div className="summary-strip summary-strip--wrap" style={{ marginTop: 12 }}>
              {prefill.degree_level && <Metric value={prefill.degree_level} label="Highest degree" />}
              {prefill.field_of_study && <Metric value={prefill.field_of_study} label="Academic background" />}
              {prefill.work_years && <Metric value={prefill.work_years} label="Years of work experience" />}
              {prefill.country && <Metric value={prefill.country} label="Country/region" />}
              {prefill.technical_proficiency && <Metric value={prefill.technical_proficiency} label="Technical proficiency" />}
              {prefill.finance_knowledge && <Metric value={prefill.finance_knowledge} label="Finance knowledge" />}
              {prefill.completed_modules && <Metric value={prefill.completed_modules} label="Completed modules" />}
            </div>
            {prefill.target_roles?.length ? <><label>Detected target roles</label><div className="checks">{prefill.target_roles.map((r) => <span className="pill pill--ok" key={r}>{r}</span>)}</div></> : null}
          </>
        ) : <div className="note">No confident fields were detected. Fill in or edit the form manually.</div>}
      </Panel>
      <form className="flow-form" onSubmit={(e) => { e.preventDefault(); onSubmit?.(e.currentTarget); }}>
        <input type="hidden" name="lifecycle_stage" value={profileType} />
        <Panel title="Identity"><div className="note note--info">Current flow: <strong>{isStudent ? "Current Student" : "Applicant"}</strong></div></Panel>
        <Panel title="Basic background">
          <div className="grid-2">
            <Select label="Application type" name="application_type" options={applicationTypes} disabled={isStudent} empty="Undecided" value={prefill.application_type} />
            <Select label="Highest degree" name="degree_level" options={degreeLevels} empty="Select" value={prefill.degree_level} />
            <Select label="Undergraduate major / prior academic background" name="field_of_study" options={fields} empty="Select" value={prefill.field_of_study} />
            <Input label="Years of work experience" name="work_years" type="number" placeholder="e.g. 2" disabled={isStudent} defaultValue={prefill.work_years || ""} />
            <Input label="Country/region" name="country" placeholder="SG" disabled={isStudent} defaultValue={prefill.country || ""} />
          </div>
        </Panel>
        <Panel title="Skills and goals">
          <div className="grid-2">
            <Select label="Technical proficiency" name="technical_proficiency" options={proficiencies} empty="Select" value={prefill.technical_proficiency} />
            <Select label="Finance knowledge" name="finance_knowledge" options={proficiencies} empty="Select" value={prefill.finance_knowledge} />
          </div>
          <label>Target roles</label>
          <div className="checks">{roles.map((role) => <label key={role}><input type="checkbox" name="target_roles" value={role} defaultChecked={prefill.target_roles?.includes(role)} /> {role}</label>)}</div>
        </Panel>
        {!isStudent && <MaterialUpload />}
        <Panel title="Completed modules"><div className="note">Enter completed module codes. Example: BMD5301, IT5003, FT5010.</div><label>Completed modules</label><input type="text" name="completed_modules" placeholder="BMD5301, IT5003, FT5010" defaultValue={prefill.completed_modules || ""} /></Panel>
        <button type="submit" className="btn btn--lg">Generate analysis →</button>
      </form>
    </>
  );
}

function Metric({ value, label }) {
  return <div><strong>{value}</strong><span>{label}</span></div>;
}
function Select({ label, name, options, empty, disabled, value }) {
  return <div className={disabled ? "field-lock is-disabled" : ""}><label>{label}</label><select name={name} disabled={disabled} defaultValue={value || ""}><option value="">({empty})</option>{options.map((x) => <option key={x} value={x}>{x}</option>)}</select></div>;
}
function Input({ label, ...props }) { return <div><label>{label}</label><input {...props} /></div>; }
function MaterialUpload() {
  return <Panel title="Application material upload"><div className="note">Supports PDF / Word / image files for demo testing.</div><div className="material-grid">{materials.map((m) => <div key={m.key} className="upload-card"><div className="upload-card__head"><strong>{m.label}</strong><span className={`pill ${m.required === "required" ? "pill--danger" : m.required === "conditional" ? "pill--warn" : "pill--mute"}`}>{m.required}</span></div><div className="why">{m.hint}</div><input type="file" name={`material_${m.key}`} accept=".pdf,.doc,.docx,.png,.jpg,.jpeg" /></div>)}</div></Panel>;
}
