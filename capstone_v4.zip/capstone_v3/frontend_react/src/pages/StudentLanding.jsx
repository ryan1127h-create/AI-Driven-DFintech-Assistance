import { Panel, Steps } from "../components/Shell.jsx";

export function StudentLanding({ onNext }) {
  return (
    <>
      <div className="page-head reveal">
        <h1>Select your profile type and get tailored guidance</h1>
        <p>This MVP supports applicant and current-student flows. Applicants get material checks, status, programme comparison, and course/career advice. Current students get course planning, skill-gap, and career-path advice only.</p>
      </div>
      <Steps current={1} />
      <form onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        const cv = fd.get("cv");
        onNext?.({
          profileType: fd.get("lifecycle_stage") || "applicant",
          text: fd.get("text") || "",
          cvName: cv && cv.name ? cv.name : "",
        });
      }}>
        <Panel title="1. Choose user type">
          <div className="role-cards" role="radiogroup" aria-label="User type">
            <label className="role-card"><input type="radio" name="lifecycle_stage" value="applicant" defaultChecked /><span className="role-card__title">Applicant</span><span className="role-card__desc">Upload materials, identify missing items, track status, compare programmes, and get course/career guidance.</span></label>
            <label className="role-card"><input type="radio" name="lifecycle_stage" value="current" /><span className="role-card__title">Current Student</span><span className="role-card__desc">Skip application materials and generate course recommendations, skill strengthening, and career direction.</span></label>
          </div>
        </Panel>
        <Panel title="2. Enter your information or upload a CV">
          <div className="note">The React preview now carries your typed information into Step 2. For full PDF/Word text extraction, use the Flask web app because browser-only preview cannot parse CV content without a backend parser.</div>
          <label htmlFor="text">Profile summary</label>
          <textarea id="text" name="text" rows="6" placeholder="Example: I majored in Computer Science, worked in banking for 2 years, completed IT5003 and FT5010, and want to become a fintech product manager." />
          <label htmlFor="cv">CV file name for this preview</label>
          <input type="file" id="cv" name="cv" accept=".docx,.pdf" />
        </Panel>
        <button type="submit" className="btn btn--lg">Next: confirm profile →</button>
      </form>
    </>
  );
}
