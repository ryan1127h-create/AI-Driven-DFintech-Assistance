export function Settings() {
  return (
    <><div className="page-head reveal"><h1>Credential settings</h1><p>Configure the DeepSeek API key to enable extraction and draft generation.</p></div><div className="panel reveal"><div className="note">Current status: <span style={{ color: "var(--danger)" }}>Not configured</span></div><form><label>API Key</label><input type="password" placeholder="sk-... (leave blank to keep current value)" /><label>Model</label><input type="text" defaultValue="deepseek-v4-pro" /><div style={{ display: "flex", gap: 10, marginTop: 18 }}><button type="button" className="btn">Save</button><button type="button" className="btn btn--ghost">Test connection</button></div></form><p className="disc">The key is stored locally by the backend. Environment variables should take priority in production.</p></div></>
  );
}
