import { useEffect, useState } from "react";
import { Shell } from "./components/Shell.jsx";
import { StudentLanding } from "./pages/StudentLanding.jsx";
import { StudentForm } from "./pages/StudentForm.jsx";
import { StudentResults } from "./pages/StudentResults.jsx";
import { AdminDashboard, AdminHistory } from "./pages/AdminPages.jsx";
import { Settings } from "./pages/Settings.jsx";
import { materials, sampleComparison } from "./data/options.js";

function includesAny(text, words) {
  return words.some((word) => text.includes(word));
}

function extractProfileFromText(text = "") {
  const lower = text.toLowerCase();
  const out = {};

  if (includesAny(lower, ["phd", "doctor of philosophy"])) out.degree_level = "phd";
  else if (includesAny(lower, ["master", "msc", "m.sc", "meng", "m.eng"])) out.degree_level = "master";
  else if (includesAny(lower, ["bachelor", "bsc", "b.sc", "undergraduate"])) out.degree_level = "bachelor";

  if (includesAny(lower, ["computer science", "software", "data science", "information systems", "network engineering", "programming"])) out.field_of_study = "computer_science";
  else if (includesAny(lower, ["financial engineering", "engineering", "electrical", "mechanical"])) out.field_of_study = "engineering";
  else if (includesAny(lower, ["finance", "banking", "investment", "securities", "trading"])) out.field_of_study = "finance";
  else if (includesAny(lower, ["economics", "econometrics"])) out.field_of_study = "economics";
  else if (includesAny(lower, ["mathematics", "statistics"])) out.field_of_study = "mathematics";
  else if (includesAny(lower, ["business", "management"])) out.field_of_study = "business";

  const years = lower.match(/(\d+)\s*(?:\+\s*)?(?:years?|yrs?|y)\b/);
  if (years) out.work_years = years[1];

  const countryMap = { singapore: "SG", sg: "SG", china: "CN", cn: "CN", india: "IN", malaysia: "MY", "hong kong": "HK" };
  Object.entries(countryMap).some(([key, value]) => {
    if (new RegExp(`\\b${key.replace(/ /g, "\\\\s+")}\\b`).test(lower)) {
      out.country = value;
      return true;
    }
    return false;
  });

  if (includesAny(lower, ["part-time", "part time", "parttime"])) out.application_type = "part_time";
  else if (includesAny(lower, ["full-time", "full time", "fulltime"])) out.application_type = "full_time";

  if (includesAny(lower, ["advanced python", "expert", "senior developer"])) out.technical_proficiency = "advanced";
  else if (includesAny(lower, ["python", "java", "c++", "sql", "machine learning", "deep learning", "react", "javascript"])) out.technical_proficiency = "intermediate";
  else if (includesAny(lower, ["basic coding", "basic programming"])) out.technical_proficiency = "basic";

  if (includesAny(lower, ["quant", "risk", "portfolio", "derivative", "trading", "investment", "securities", "bank", "fintech", "financial"])) out.finance_knowledge = "intermediate";
  else if (includesAny(lower, ["basic finance", "introductory finance"])) out.finance_knowledge = "basic";

  const roles = [];
  if (includesAny(lower, ["product manager", "product management", "fintech pm", "pm role"])) roles.push("fintech_pm");
  if (includesAny(lower, ["quant", "risk", "risk management", "trading", "financial analyst"])) roles.push("quant_risk");
  if (includesAny(lower, ["digital banking", "banking", "bank"])) roles.push("digital_banking");
  if (includesAny(lower, ["payment", "payments", "blockchain", "transaction"])) roles.push("payments");
  if (includesAny(lower, ["compliance", "regtech", "regulation", "aml"])) roles.push("compliance_regtech");
  if (includesAny(lower, ["data analyst", "data analytics", "analytics", "machine learning", "data scientist", "ai"])) roles.push("data_analytics");
  if (roles.length) out.target_roles = [...new Set(roles)];

  const modules = [...new Set((text.toUpperCase().match(/\b[A-Z]{2,4}\d{4}[A-Z]?\b/g) || []))];
  if (modules.length) out.completed_modules = modules.join(", ");

  return out;
}

function collectProfile(form) {
  const fd = new FormData(form);
  const fileNames = {};
  materials.forEach((m) => {
    const file = fd.get(`material_${m.key}`);
    if (file && file.name) fileNames[m.key] = file.name;
  });
  return {
    lifecycle_stage: fd.get("lifecycle_stage") || "applicant",
    application_type: fd.get("application_type") || "",
    degree_level: fd.get("degree_level") || "",
    field_of_study: fd.get("field_of_study") || "",
    work_years: fd.get("work_years") || "",
    country: fd.get("country") || "",
    technical_proficiency: fd.get("technical_proficiency") || "",
    finance_knowledge: fd.get("finance_knowledge") || "",
    target_roles: fd.getAll("target_roles"),
    priority: fd.get("priority") || "role_fit",
    completed_modules: fd.get("completed_modules") || "",
    uploaded_materials: fileNames,
  };
}

function buildResults(profile) {
  const completedCodes = [...new Set((profile.completed_modules || "").toUpperCase().match(/\b[A-Z]{2,4}\d{4}[A-Z]?\b/g) || [])];
  const completed = completedCodes.length * 4;
  const recommended = [
    { code: "FT5001", name: "Fintech Innovations: A Strategic Landscape", credits: 4, source_url: "https://nusmods.com/courses/FT5001" },
    { code: "FT5010", name: "Algorithmic Trading Systems Design and Deployment", credits: 4, source_url: "https://nusmods.com/courses/FT5010" },
    { code: "BT5153", name: "Applied Machine Learning for Business Analytics", credits: 4, source_url: "https://nusmods.com/courses/BT5153" },
    { code: "CS5242", name: "Neural Networks and Deep Learning", credits: 4, source_url: "https://nusmods.com/courses/CS5242" },
    { code: "BMF5358", name: "Digital Assets and Blockchain", credits: 4, source_url: "https://nusmods.com/courses/BMF5358" },
    { code: "BMD5302", name: "Financial Modelling and Analytics", credits: 4, source_url: "https://nusmods.com/courses/BMD5302" },
  ].filter((m) => !completedCodes.includes(m.code));
  const planned = recommended.reduce((sum, m) => sum + m.credits, 0);
  const required = 52;
  const requiredMaterials = materials.filter((m) => m.required === "required");
  const materialRows = materials.map((m) => {
    const uploaded = Boolean(profile.uploaded_materials?.[m.key]);
    return {
      ...m,
      status: uploaded ? "uploaded" : "missing",
      reason: uploaded ? `Uploaded: ${profile.uploaded_materials[m.key]}` : "Not uploaded",
    };
  });
  const submittedRequired = materialRows.filter((m) => m.required === "required" && m.status === "uploaded").length;

  return {
    profile,
    profileType: profile.lifecycle_stage || "applicant",
    materialSummary: {
      submittedRequired,
      requiredTotal: requiredMaterials.length,
      missingRequired: requiredMaterials.length - submittedRequired,
      rejectedRequired: 0,
      isComplete: submittedRequired === requiredMaterials.length,
    },
    materials: materialRows,
    checklist: requiredMaterials.map((m) => ({
      label: m.label,
      required: true,
      status: profile.uploaded_materials?.[m.key] ? "Submitted" : "To prepare",
      why: profile.uploaded_materials?.[m.key] ? "Detected from your upload in this session." : m.hint,
    })),
    timeline: [
      { label: "Fill in profile", state: "done" },
      { label: "Upload application materials", state: submittedRequired ? "done" : "current" },
      { label: "Material completeness check", state: submittedRequired === requiredMaterials.length ? "done" : "pending" },
      { label: "Formal academic review", state: "pending" },
      { label: "Admission decision", state: "pending" },
    ],
    comparison: sampleComparison,
    recommended,
    completedCodes,
    skillGaps: profile.technical_proficiency === "advanced" ? ["Finance knowledge", "Regulatory awareness"] : ["Programming", "Data analytics", "Finance knowledge"],
    progress: { completed, planned, required, remaining: Math.max(0, required - completed - planned) },
  };
}

export default function App() {
  const [page, setPage] = useState(window.location.hash.replace("#/", "") || "");
  const [profileType, setProfileType] = useState("applicant");
  const [prefill, setPrefill] = useState({});
  const [resultsData, setResultsData] = useState(null);

  useEffect(() => {
    const onHash = () => setPage(window.location.hash.replace("#/", "") || "");
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  if (page.startsWith("admin/history")) return <Shell app="admin" active="history"><AdminHistory /></Shell>;
  if (page.startsWith("admin")) return <Shell app="admin" active="home"><AdminDashboard /></Shell>;
  if (page.startsWith("settings")) return <Shell active="settings"><Settings /></Shell>;
  if (page === "form") {
    return <Shell><StudentForm profileType={profileType} prefill={prefill} onSubmit={(form) => { const profile = collectProfile(form); setResultsData(buildResults(profile)); window.location.hash = "#/results"; }} /></Shell>;
  }
  if (page === "results") return <Shell><StudentResults data={resultsData || buildResults({ lifecycle_stage: profileType, uploaded_materials: {}, target_roles: [] })} onEdit={() => { window.location.hash = "#/form"; }} /></Shell>;
  return <Shell active="home"><StudentLanding onNext={({ profileType: nextType, text, cvName }) => { setProfileType(nextType); setPrefill({ ...extractProfileFromText(text), _profile_text: text, _cv_name: cvName, _extraction_method: text ? "local_preview" : "manual" }); window.location.hash = "#/form"; }} /></Shell>;
}
