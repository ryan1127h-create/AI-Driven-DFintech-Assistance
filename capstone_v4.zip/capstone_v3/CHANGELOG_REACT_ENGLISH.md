# React + English UI update

## What changed

- Added a React/Vite frontend under `frontend_react/` with JSX components for:
  - student landing page
  - student profile confirmation form
  - student results dashboard
  - admin data editing dashboard
  - admin history / rollback page
  - credential settings page
- Translated the existing Flask/Jinja student and admin web templates to English so the original apps still run:
  - `python -m student.webapp`
  - `python -m admin.webapp`
- Translated web-facing Python messages and demo data used by the UI, including:
  - uploaded-material status messages
  - application checklist/status messages
  - tracker timeline labels and reminders
  - programme comparison disclaimer and synthesis labels
  - navigator skill labels, role titles, and course recommendation text
- Kept backend rule engines and route names intact.

## React run command

```bash
cd frontend_react
npm install
npm run dev
```

## Integration note

The React version currently uses sample data for the results page. To make it fully backend-driven, add JSON API endpoints to Flask and replace the sample data imports in `frontend_react/src/App.jsx` / page components with `fetch()` calls.
